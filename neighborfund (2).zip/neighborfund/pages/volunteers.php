<?php
$pageTitle = 'Volunteer';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$volunteerObj = new Volunteer();
$projObj = new Project();
$projects = $projObj->getAllProjects('approved');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assign'])) {
        $volunteerObj->assignVolunteer($currentUser->id, $_POST['project_id'], $_POST['task'], $_POST['hours']);
    } elseif (isset($_POST['track'])) {
        $volunteerObj->trackHours($currentUser->id, $_POST['project_id'], $_POST['hours']);
    }
    echo '<script>window.location.href = "volunteers.php";</script>';

    exit;
}
$myVol = $volunteerObj->getUserVolunteer($currentUser->id);
?>

<style>
    .volunteer-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .volunteer-card {
        background: white;
        border-radius: 24px;
        padding: 1.8rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .volunteer-title {
        font-size: 1.6rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #1e2a3e;
    }
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        align-items: end;
    }
    .form-group {
        display: flex;
        flex-direction: column;
    }
    .form-group label {
        font-weight: 600;
        margin-bottom: 0.4rem;
        font-size: 0.85rem;
        color: #2c3e50;
    }
    .form-control, .form-select {
        padding: 10px 12px;
        border: 1px solid #ccc;
        border-radius: 16px;
        font-size: 0.9rem;
        width: 100%;
    }
    .btn-primary-custom {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        white-space: nowrap;
    }
    .btn-success-custom {
        background: #28a745;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .volunteer-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 20px;
        overflow: hidden;
    }
    .volunteer-table th, .volunteer-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #e2e8f0;
    }
    .volunteer-table th {
        background: #f8fafc;
        font-weight: 700;
        font-size: 0.85rem;
        text-transform: uppercase;
        color: #4a5568;
    }
    .track-form {
        display: flex;
        gap: 0.5rem;
        align-items: center;
        flex-wrap: wrap;
    }
    .track-input {
        width: 100px;
        padding: 6px 8px;
        border: 1px solid #ccc;
        border-radius: 30px;
    }
    @media (max-width: 768px) {
        .form-grid {
            grid-template-columns: 1fr;
        }
        .volunteer-table thead {
            display: none;
        }
        .volunteer-table tr {
            display: block;
            margin-bottom: 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 20px;
            padding: 0.5rem;
        }
        .volunteer-table td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            border-bottom: none;
        }
        .volunteer-table td:before {
            content: attr(data-label);
            font-weight: 700;
            width: 40%;
        }
        .track-form {
            justify-content: flex-end;
        }
    }
    .alert-info {
        background: #e2e8f0;
        color: #1e2a3e;
        padding: 1rem;
        border-radius: 20px;
        text-align: center;
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Volunteer Opportunities</h1>
        <p>Support local projects with your time and skills</p>
    </div>
</div>

<div class="volunteer-container">
    <!-- نموذج التسجيل في فرصة تطوعية -->
    <div class="volunteer-card">
        <h2 class="volunteer-title">Sign up for a task</h2>
        <form method="POST">
            <div class="form-grid">
                <div class="form-group">
                    <label>Project</label>
                    <select name="project_id" class="form-select" required>
                        <?php foreach ($projects as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Task description</label>
                    <input type="text" name="task" class="form-control" placeholder="e.g., Planting trees" required>
                </div>
                <div class="form-group">
                    <label>Hours committed</label>
                    <input type="number" name="hours" class="form-control" placeholder="Hours" required>
                </div>
                <div>
                    <button type="submit" name="assign" class="btn-primary-custom">Sign Up</button>
                </div>
            </div>
        </form>
    </div>

    <!-- جدول تطوعاتي -->
    <div class="volunteer-card">
        <h2 class="volunteer-title">My Volunteering</h2>
        <?php if (empty($myVol)): ?>
            <div class="alert-info">You haven't signed up for any volunteer tasks yet.</div>
        <?php else: ?>
            <table class="volunteer-table">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Task</th>
                        <th>Committed</th>
                        <th>Completed</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($myVol as $v): ?>
                        <tr>
                            <td data-label="Project"><?= htmlspecialchars($v['title']) ?></td>
                            <td data-label="Task"><?= htmlspecialchars($v['task_description']) ?></td>
                            <td data-label="Committed"><?= (int)$v['hours_committed'] ?></td>
                            <td data-label="Completed"><?= (int)$v['hours_completed'] ?></td>
                            <td data-label="Status"><?= htmlspecialchars($v['status']) ?></td>
                            <td data-label="Action">
                                <form method="POST" class="track-form">
                                    <input type="hidden" name="project_id" value="<?= $v['project_id'] ?>">
                                    <input type="number" name="hours" class="track-input" placeholder="Hours" required>
                                    <button type="submit" name="track" class="btn-success-custom">Track</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>