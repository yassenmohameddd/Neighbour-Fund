<?php
$pageTitle = 'Browse Projects';
require_once __DIR__ . '/../includes/header.php';

$db = Database::getInstance();
$status = isset($_GET['status']) ? $_GET['status'] : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';


$sql = "
    SELECT p.*, u.full_name as lead_name,
    (CASE WHEN p.funding_goal > 0 THEN (p.current_amount / p.funding_goal * 100) ELSE 0 END) as percent_funded,
    (SELECT COUNT(*) FROM donations WHERE project_id = p.id AND status IN ('confirmed', 'escrow', 'released')) as backers_count
    FROM projects p
    JOIN users u ON p.project_lead_id = u.id
    WHERE p.status IN ('live', 'funded', 'completed', 'approved')
";
$params = [];



if ($status !== '') {
    $sql .= " AND p.status = ?";
    $params[] = $status;
}



if ($category !== '') {
    $sql .= " AND p.category = ?";
    $params[] = $category;
}

$sql .= " ORDER BY 
    CASE p.status 
        WHEN 'live' THEN 1 
        WHEN 'community_vote' THEN 2 
        WHEN 'funded' THEN 3 
        WHEN 'completed' THEN 4 
        ELSE 5 
    END, p.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$projects = $stmt->fetchAll();
?>

<div class="hero" style="padding: 120px 5% 60px;">
    <div class="hero-content">
        <h1 style="font-size: 2rem;">Browse Community Projects</h1>
        <p>Discover and fund local initiatives making a real difference</p>
    </div>
</div>

<div class="section" style="padding-top: 0;">
    <div style="background: white; border-radius: 20px; padding: 1.5rem; margin-bottom: 2rem; box-shadow: var(--shadow);">
        <form method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center;">
            <select name="status" class="form-control" style="flex: 1; padding: 10px; border-radius: 10px;">
                <option value="">All Active Statuses</option>
                <option value="live" <?= $status == 'live' ? 'selected' : '' ?>>Live (Fundraising)</option>
                <!-- <option value="community_vote" <?= $status == 'community_vote' ? 'selected' : '' ?>>Community Voting</option> -->
                <option value="funded" <?= $status == 'funded' ? 'selected' : '' ?>>Funded</option>
                <option value="completed" <?= $status == 'completed' ? 'selected' : '' ?>>Completed</option>
            </select>
            <select name="category" class="form-control" style="flex: 1; padding: 10px; border-radius: 10px;">
                <option value="">All Categories</option>
                <?php foreach (['park','mural','youth_program','infrastructure','community_garden','public_art','education','other'] as $cat): ?>
                    <option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $cat))) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-primary">Filter</button>
        </form>
    </div>

    <div class="projects-grid">
        <?php if (empty($projects)): ?>
            <div class="alert alert-info">No projects found. <?php if ($status === ''): ?>Check back soon for new community projects!<?php else: ?>Try changing your filter.<?php endif; ?></div>
        <?php else: ?>
            <?php foreach ($projects as $p): ?>
                <a href="project.php?slug=<?= urlencode($p['slug']) ?>" class="project-card">
                    <div class="project-image">
                        <span>🌳</span>
                        <span class="project-badge"><?= htmlspecialchars(ucfirst($p['status'])) ?></span>
                    </div>
                    <div class="project-content">
                        <div class="project-category"><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $p['category']))) ?></div>
                        <h3 class="project-title"><?= htmlspecialchars($p['title']) ?></h3>
                        <div class="project-location"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($p['region'] ?? 'Local') ?></div>
                        <div class="progress-bar-custom">
                            <div class="progress-fill-custom" style="width: <?= min(100, max(0, round((float)$p['percent_funded']))) ?>%"></div>
                        </div>
                        <div class="project-stats">
                            <span><strong>$<?= number_format($p['current_amount'], 0) ?></strong> raised</span>
                            <span><?= round((float)$p['percent_funded']) ?>%</span>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>