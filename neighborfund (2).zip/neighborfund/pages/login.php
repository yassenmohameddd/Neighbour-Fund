<?php
$pageTitle = 'Login';
require_once __DIR__ . '/../includes/header.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {//$_SERVER بيحتوي على معلومات عن سيرفر زي URL 
    $username = trim($_POST['username'] ?? '');//حذف المسافات الزائدة trim 
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username/email and password.';
    } else {
        
        $user = Auth::login($username, $password);//:: زي ->
        
        if ($user) {
            
            $redirect = $_SESSION['redirect_after_login'] ?? BASE_URL . '/pages/dashboard.php';
            unset($_SESSION['redirect_after_login']);
            
            if (strpos($redirect, 'login.php') !== false) {
                $redirect = BASE_URL . '/pages/dashboard.php';
            }
            header("Location: $redirect");
            exit;
        } else {
            
            $error = 'Invalid username/email or password.';
        }
    }
}
?>

<div class="hero" style="padding: 120px 5% 60px;">
    <div class="hero-content" style="max-width: 500px;">
        <h1 style="font-size: 2rem;">Welcome Back</h1>
        <p>Log in to your NeighborFund account</p>
        <?php if ($error): ?>
            <div class="alert alert-danger" style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 12px; margin-bottom: 1rem;"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST" style="text-align: left; margin-top: 2rem;">
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; color: white; margin-bottom: 0.5rem;">Username or Email</label>
                <input type="text" name="username" class="form-control" style="width: 100%; padding: 12px; border-radius: 10px; border: none;" required>
            </div>
            <div class="form-group" style="margin-bottom: 1.5rem;">
                <label style="display: block; color: white; margin-bottom: 0.5rem;">Password</label>
                <input type="password" name="password" class="form-control" style="width: 100%; padding: 12px; border-radius: 10px; border: none;" required>
            </div>
            <button type="submit" class="btn-hero btn-hero-primary" style="width: 100%; justify-content: center;">Login</button>
        </form>
        <p style="margin-top: 1rem;">Don't have an account? <a href="register.php" style="color: var(--accent);">Register</a></p>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>