<?php
$pageTitle = 'Project Details';
require_once __DIR__ . '/../includes/header.php';




$slug = $_GET['slug'] ?? '';
$projectObj = new Project();
$project = $projectObj->getProjectBySlug($slug);
$organizationName = null;

if (!empty($project->organization_id)) {
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT name FROM organizations WHERE id = ?");
    $stmt->execute([$project->organization_id]);
    $organizationName = $stmt->fetchColumn();
}


if (!$project) {
    echo '<div class="hero" ...>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$originalStatus = $project->status;
$project->checkFundingDeadline();
if ($project->status !== $originalStatus) {
    $project = $projectObj->getProjectBySlug($slug);
}
// ====================== معالجة إضافة تعليق جديد ======================
$commentSuccess = '';
$commentError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_comment') {
    $project_id = (int)($_POST['project_id'] ?? 0);
    $content = trim($_POST['content'] ?? '');

    if ($project_id !== $project->id || $project_id <= 0) {
        $commentError = 'Project ID mismatch. Please try again.';
    } elseif (empty($content)) {
        $commentError = 'Comment cannot be empty.';
    } else {
        $dbCheck = Database::getInstance();
        $checkStmt = $dbCheck->prepare("SELECT id FROM projects WHERE id = ?");
        $checkStmt->execute([$project_id]);
        if (!$checkStmt->fetch()) {
            $commentError = 'Project does not exist in database.';
        } else {
            try {
                if (class_exists('Comment')) {
                    $commentObj = new Comment();
                    $result = $commentObj->addComment($currentUser->id, $project_id, $content);
                } else {
                    $db = Database::getInstance();
                    $stmt = $db->prepare("INSERT INTO comments (project_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())");
                    $result = $stmt->execute([$project_id, $currentUser->id, $content]);
                }

                if ($result) {
                    $commentSuccess = '✅ Your comment has been posted!';
                    if (class_exists('Comment')) {
                        $comments = $commentObj->getComments($project->id);
                    } else {
                        $db = Database::getInstance();
                        $stmt = $db->prepare("SELECT c.*, u.full_name FROM comments c JOIN users u ON c.user_id = u.id WHERE c.project_id = ? ORDER BY c.created_at DESC");
                        $stmt->execute([$project_id]);
                        $comments = $stmt->fetchAll();
                    }
                } else {
                    $commentError = 'Database error. Could not save comment.';
                }
            } catch (PDOException $e) {
                if ($e->getCode() == 23000 && strpos($e->getMessage(), 'foreign key constraint fails')) {
                    $commentError = 'Cannot add comment: referenced project does not exist. Please refresh and try again.';
                } else {
                    $commentError = 'Database error: ' . $e->getMessage();
                }
            } catch (Exception $e) {
                $commentError = 'Error: ' . $e->getMessage();
            }
        }
    }
}

// ====================== جلب البيانات الأخرى ======================
$donations = [];
$comments = [];
$updates = [];
$upvotes = 0;
$hasUpvoted = false;

if (class_exists('Donation')) {
    $donationObj = new Donation();
    $donations = $donationObj->getDonationsByProject($project->id);
}
if (class_exists('Comment')) {
    $commentObj = new Comment();
    if (!isset($comments) || empty($comments)) {
        $comments = $commentObj->getComments($project->id);
    }
} else {
    if (!isset($comments)) {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT c.*, u.full_name FROM comments c JOIN users u ON c.user_id = u.id WHERE c.project_id = ? ORDER BY c.created_at DESC");
        $stmt->execute([$project->id]);
        $comments = $stmt->fetchAll();
    }
}
if (class_exists('Update')) {
    $updateObj = new Update();
    $updates = $updateObj->getUpdates($project->id);
}
if (class_exists('Vote')) {
    $voteObj = new Vote();
    $upvotes = $voteObj->heatMapScore($project->id);
    if ($currentUser) {
        $hasUpvoted = $voteObj->hasUserVoted($currentUser->id, $project->id, 'project');
    }
}
//////////
$milestoneObj = new Milestone();
$allMilestones = $milestoneObj->getMilestones($project->id);
foreach ($allMilestones as $mData) {
    $m = new Milestone($mData);
    $m->checkForDelay();
}
/////////


$target = (!empty($project->stretch_goal) && $project->current_amount >= $project->funding_goal)
    ? $project->stretch_goal
    : $project->funding_goal;

$progressPercent = ($target > 0)
    ? ($project->current_amount / $target) * 100
    : 0;
?>

<style>
    .project-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .project-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 2rem;
    }
    .project-main {
        background: white;
        border-radius: 24px;
        padding: 1.8rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .project-sidebar {
        background: white;
        border-radius: 24px;
        padding: 1.8rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        position: sticky;
        top: 100px;
        align-self: start;
    }
    .project-title {
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: #1e2a3e;
    }
    .project-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1.5rem;
        font-size: 0.85rem;
        color: #fdfeff;
    }
    .badge-status {
        display: inline-block;
        padding: 0.2rem 0.8rem;
        border-radius: 30px;
        font-size: 0.75rem;
        font-weight: 600;
        background: #e2e8f0;
        color: #1e2a3e;
    }
    .badge-status.live { background: #d4edda; color: #155724; }
    .badge-status.pending { background: #fff3cd; color: #856404; }
    .badge-status.funded { background: #cce5ff; color: #004085; }
    .badge-status.completed { background: #d1ecf1; color: #0c5460; }
    .badge-status.cancelled { background: #f8d7da; color: #721c24; }
    .progress-bar-container {
        background: #e2e8f0;
        border-radius: 20px;
        height: 10px;
        margin: 1rem 0;
    }
    .progress-fill {
        background: #1D6E6F;
        width: 0%;
        height: 10px;
        border-radius: 20px;
    }
    .funding-stats {
        display: flex;
        justify-content: space-between;
        margin-bottom: 0.5rem;
        font-weight: 600;
    }
    .btn-primary-custom {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        width: 100%;
        text-align: center;
        display: inline-block;
        text-decoration: none;
    }
    .btn-outline-custom {
        background: transparent;
        border: 1px solid #1D6E6F;
        color: #1D6E6F;
        padding: 10px 18px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        width: 100%;
        text-align: center;
        display: inline-block;
        text-decoration: none;
    }
    .btn-secondary-custom {
        background: #6c757d;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 40px;
        width: 100%;
        text-align: center;
        cursor: not-allowed;
    }
    .comment-item, .update-item {
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 1rem;
        margin-bottom: 1rem;
        background: #fafcff;
    }
    .comment-header, .update-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 0.5rem;
        font-size: 0.85rem;
    }
    hr {
        margin: 1.5rem 0;
        border: none;
        border-top: 1px solid #e2e8f0;
    }
    @media (max-width: 768px) {
        .project-grid {
            grid-template-columns: 1fr;
        }
        .project-sidebar {
            position: static;
        }
    }
    .alert-danger, .alert-success, .alert-warning {
        padding: 0.75rem 1.2rem;
        border-radius: 20px;
        margin-bottom: 1rem;
    }
    .alert-danger { background: #f8d7da; color: #721c24; }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-warning { background: #fff3cd; color: #856404; }
    textarea.form-control {
        width: 100%;
        padding: 0.7rem 1rem;
        border: 1px solid #ccc;
        border-radius: 20px;
        font-family: inherit;
    }
    .milestone-vote-card {
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 1rem;
        margin-bottom: 1rem;
        background: #fafcff;
    }
    .btn-success-custom {
        background: #28a745;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
    }
    .btn-danger-custom {
        background: #dc3545;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
    }
    .btn-group {
        display: flex;
        gap: 0.8rem;
        flex-wrap: wrap;
        margin-top: 0.5rem;
    }
</style>


<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;"><?= htmlspecialchars($project->title) ?></h1>
        <div class="project-meta">
            
            <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($project->region) ?></span>
            <span class="badge-status <?= htmlspecialchars($project->status) ?>"><?= ucfirst(htmlspecialchars($project->status)) ?></span>
            <span><i class="fas fa-clock"></i> Deadline: <?= date('M d, Y', strtotime($project->deadline)) ?></span>
        </div>
    </div>
</div>

<div class="project-container">
    <div class="project-grid">
        <!-- العمود الرئيسي -->
        <div class="project-main">
            <div class="progress-bar-container">
                <div class="progress-fill" style="width: <?= round($progressPercent) ?>%;"></div>
            </div>
           <div class="funding-stats">
    <span>
        <strong>$<?= number_format($project->current_amount, 0) ?></strong> raised
    </span>

    <span>
        <?php if (!empty($project->stretch_goal) && $project->current_amount >= $project->funding_goal): ?>
            of $<?= number_format($project->stretch_goal, 0) ?> stretch goal
        <?php else: ?>
            of $<?= number_format($project->funding_goal, 0) ?> goal
        <?php endif; ?>
    </span>

    <span><?= round($progressPercent) ?>%</span>
</div>

            <hr>
            <h2>About this project</h2>
            <div style="line-height: 1.6; margin-top: 1rem;">
                <?= nl2br(htmlspecialchars($project->description)) ?>
            </div>

            <?php if (!empty($updates)): ?>
                <hr>
                <h3>📢 Updates</h3>
                <?php foreach ($updates as $u): ?>
                    <div class="update-item">
                        <div class="update-header">
                            <strong><?= htmlspecialchars($u['title']) ?></strong>
                            <small><?= htmlspecialchars($u['created_at']) ?></small>
                        </div>
                        <div><?= nl2br(htmlspecialchars($u['content'])) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <hr>
            <h3>💬 Comments</h3>
            
            <?php if ($commentSuccess): ?>
                <div class="alert alert-success"><?= htmlspecialchars($commentSuccess) ?></div>
            <?php elseif ($commentError): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($commentError) ?></div>
            <?php endif; ?>

            <?php foreach ($comments as $c): ?>
                <div class="comment-item">
                    <div class="comment-header">
                        <strong><?= htmlspecialchars($c['full_name'] ?? 'Anonymous') ?></strong>
                        <small><?= htmlspecialchars($c['created_at']) ?></small>
                    </div>
                    <div><?= nl2br(htmlspecialchars($c['content'])) ?></div>
                    <?php if ($currentUser): ?>
        <div style="margin-top: 8px;">
            <a href="disputes.php?comment_id=<?= $c['id'] ?>" class="small-link" style="color:#dc3545;">🚩 Report</a>
        </div>
    <?php endif; ?>
                </div>
            <?php endforeach; ?>

            <?php if ($currentUser): ?>
                <form method="POST" action="" style="margin-top: 1.5rem;">
                    <input type="hidden" name="action" value="add_comment">
                    <input type="hidden" name="project_id" value="<?= $project->id ?>">
                    <textarea name="content" class="form-control" rows="2" placeholder="Write a comment..." required></textarea>
                    <button type="submit" class="btn-primary-custom" style="margin-top: 0.8rem;">Post Comment</button>
                </form>
            <?php else: ?>
                <div class="alert alert-info">Please <a href="login.php">login</a> to leave a comment.</div>
            <?php endif; ?>
            <?php if ($currentUser && $currentUser->role === 'admin'): ?>
            <hr>
            <h4>Revision History</h4>
            <?php
            $revObj = new Revision();
            $history = $revObj->getHistory($project->id);
            foreach ($history as $h) {
                echo "<small>Version {$h['version_number']} on {$h['created_at']}</small><br>";
            }
            ?>
            <?php endif; ?>

            <!-- ========== قسم التصويت على الميليستونات ========== -->
            <?php
            $dbVote = Database::getInstance();
            $milestonesStmt = $dbVote->prepare("SELECT * FROM milestones WHERE project_id = ? AND status = 'submitted' ORDER BY sequence_order ASC");
            $milestonesStmt->execute([$project->id]);
            $votableMilestones = $milestonesStmt->fetchAll();

            if (!empty($votableMilestones) && $currentUser):
                // التحقق إذا كان المستخدم داعماً (له تبرع في هذا المشروع)
                $donorCheck = $dbVote->prepare("SELECT COUNT(*) FROM donations WHERE user_id = ? AND project_id = ? AND status IN ('escrow', 'released')");
                $donorCheck->execute([$currentUser->id, $project->id]);
                $isBacker = $donorCheck->fetchColumn() > 0;
                
                if ($isBacker):
            ?>
                <hr>
                <h3>🗳️ Milestones Waiting for Your Vote</h3>
                <?php foreach ($votableMilestones as $m):
                    $voteCheck = $dbVote->prepare("SELECT COUNT(*) FROM votes WHERE user_id = ? AND item_type = 'milestone' AND item_id = ?");
                    $voteCheck->execute([$currentUser->id, $m['id']]);
                    $alreadyVoted = $voteCheck->fetchColumn() > 0;
                ?>
                    <div class="milestone-vote-card">
                        <h4><?= htmlspecialchars($m['title']) ?></h4>
                        <p><?= nl2br(htmlspecialchars($m['description'])) ?></p>
                        <p><strong>Allocated amount:</strong> $<?= number_format($m['allocated_amount'], 2) ?></p>
                        <?php if ($alreadyVoted): ?>
                            <p><em>You have already voted on this milestone.</em></p>
                        <?php else: ?>
                            <div class="btn-group">
                                <a href="vote-milestone.php?milestone=<?= $m['id'] ?>&vote=approve" class="btn-success-custom">👍 Approve</a>
                                <a href="vote-milestone.php?milestone=<?= $m['id'] ?>&vote=reject" class="btn-danger-custom">👎 Reject</a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php 
                endif;
            endif; 
            ?>
        </div>

        <!-- العمود الجانبي -->
        <div class="project-sidebar">
            <?php if ($project->status === 'live'): ?>
                <a href="donate.php?project_id=<?= $project->id ?>" class="btn-primary-custom" style="display: block; margin-bottom: 1rem;">💖 Donate Now</a>
            <?php else: ?>
                <div class="btn-secondary-custom" style="margin-bottom: 1rem;">Not yet accepting donations</div>
            <?php endif; ?>
                    <?php if ($currentUser && $project->project_lead_id == $currentUser->id): ?>
            <a href="milestones.php?project=<?= $project->id ?>" class="btn-outline-custom">Manage Milestones</a>
        <?php endif; ?><br><br>

            <?php if ($currentUser && !$hasUpvoted && $project->status !== 'cancelled'): ?>
                <a href="upvote.php?project=<?= $project->id ?>" class="btn-outline-custom" style="display: block; margin-bottom: 0.5rem;">👍 Upvote (<?= (int)$upvotes ?>)</a>
            <?php else: ?>
                <p style="text-align: center; font-weight: bold;">👍 <?= (int)$upvotes ?> upvotes</p>
            <?php endif; ?>
            
            <?php
            $rewardObj = new Reward();
            $rewards = $rewardObj->getByProject($project->id);
            if ($rewards): ?>
            <div class="project-sidebar" style="margin-top:1rem;">
                <h4>🎁 Available Rewards</h4>
                <?php foreach ($rewards as $r): ?>
                    <div class="reward-item">
                        <strong><?= htmlspecialchars($r['tier_name']) ?></strong> - min $<?= $r['min_donation'] ?>
                        <p><?= htmlspecialchars($r['description']) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <hr>
         <p><strong>Project Lead:</strong> <?= htmlspecialchars($project->lead_name) ?></p>
         <?php if ($organizationName): ?>
    <p><strong>Organization:</strong> <?= htmlspecialchars($organizationName) ?></p>
<?php endif; ?>
            <?php $completionRate = $project->getLeadCompletionRate(); ?>
            <p><strong>Lead Credibility:</strong>
            <?php if ($project->sustainability_score > 0): ?>
    <p><strong>Sustainability Score:</strong> <?= $project->sustainability_score ?>/5</p>
    <?php if (!empty($project->sustainability_notes)): ?>
        <p><small><?= nl2br(htmlspecialchars($project->sustainability_notes)) ?></small></p>
    <?php endif; ?>
<?php endif; ?>
            <?= $completionRate ?>% milestones completed</p>
            <p><strong>Deadline:</strong> <?= date('M d, Y', strtotime($project->deadline)) ?></p>
            <p><strong>Created:</strong> <?= date('M d, Y', strtotime($project->created_at ?? 'now')) ?></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>