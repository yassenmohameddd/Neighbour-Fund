<?php
// ============================================
// معالجة POST أولاً (قبل أي ناتج HTML)
// ============================================
session_start();

define('BASE_URL', '/neighborfund');
define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'] . BASE_URL);

require_once BASE_PATH . '/config/database.php';

// دالة توليد slug
function generateSlug($title) {
    $db = Database::getInstance();
    $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($title));
    $slug = trim($slug, '-');
    $original = $slug;
    $counter = 1;
    while (true) {
        $stmt = $db->prepare("SELECT id FROM projects WHERE slug = ?");
        $stmt->execute([$slug]);
        if (!$stmt->fetch()) break;
        $slug = $original . '-' . $counter++;
    }
    return $slug;
}

$db = Database::getInstance();
$currentUser = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $data = $stmt->fetch();
    if ($data) $currentUser = (object) $data;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$currentUser) {
        echo '<script>window.location.href = "login.php";</script>';
        exit;
    }
    try {
        // التحقق من تطابق البلدية
        if ((int)$_POST['municipality_id'] != ($currentUser->municipality_id ?? 0)) {
            throw new Exception("You can only create projects in your own municipality.");
        }
        
        $slug = generateSlug($_POST['title']);
        $organization_id = !empty($_POST['organization_id']) ? (int)$_POST['organization_id'] : null;
      $stmt = $db->prepare("
INSERT INTO projects 
(title, slug, description, short_description, category, project_lead_id,
funding_goal, stretch_goal, region, deadline, status, created_at,
organization_id, municipality_id)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', NOW(), ?, ?)
");
       $stmt->execute([
    $_POST['title'],
    $slug,
    $_POST['description'],
    substr($_POST['description'], 0, 500),
    $_POST['category'],
    $currentUser->id,
    (float)$_POST['funding_goal'],

    // ✅ NEW
    !empty($_POST['stretch_goal']) ? (float)$_POST['stretch_goal'] : null,

    $currentUser->region ?? 'General',
    $_POST['deadline'],
    $organization_id,
    $_POST['municipality_id']
]);
        $projectId = $db->lastInsertId();
        // تحويل اليوزر إلى project_lead
        $db->prepare("UPDATE users SET is_project_lead = 1 WHERE id = ?")
        ->execute([$currentUser->id]);

        // تحديث السيشن عشان التغيير يظهر فوراً
          $_SESSION['user_role'] = 'project_lead';
          $currentUser->role = 'project_lead';
        
        if (isset($_POST['budget_items'])) {
            $bStmt = $db->prepare("INSERT INTO budget_items (project_id, item_name, estimated_cost) VALUES (?, ?, ?)");
            foreach ($_POST['budget_items'] as $item) {
                if (!empty($item['name']) && !empty($item['cost'])) {
                    $bStmt->execute([$projectId, $item['name'], (float)$item['cost']]);
                }
            }
        }
        
        header("Location: milestones.php?project=" . $projectId);
        exit;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$pageTitle = 'Create Project';
require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/auth_check.php';

// جلب مؤسسات المستخدم الموثقة
$userOrgs = [];
if ($currentUser) {
    $stmt = $db->prepare("SELECT id, name FROM organizations WHERE user_id = ? AND verified = 1");
    $stmt->execute([$currentUser->id]);
    $userOrgs = $stmt->fetchAll();
}
?>

<style>
    /* تنسيق الصفحة (كما هو دون تغيير) */
    .form-container {
        max-width: 800px;
        margin: 2rem auto;
        background: white;
        border-radius: 28px;
        padding: 2rem;
        box-shadow: 0 8px 24px rgba(0,0,0,0.05);
    }
    .form-title {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: #1e2a3e;
    }
    .form-subtitle {
        color: #4a5568;
        margin-bottom: 1.8rem;
        font-size: 0.9rem;
        border-bottom: 1px solid #e2e8f0;
        padding-bottom: 0.75rem;
    }
    .form-group {
        margin-bottom: 1.2rem;
    }
    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 0.4rem;
        font-size: 0.85rem;
        color: #2c3e50;
    }
    .form-control, .form-select {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 20px;
        font-size: 0.9rem;
        transition: 0.2s;
        background: white;
    }
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #1D6E6F;
        box-shadow: 0 0 0 3px rgba(29,110,111,0.2);
    }
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }
    .budget-row {
        display: grid;
        grid-template-columns: 4fr 2fr 1fr 0.5fr;
        gap: 0.5rem;
        align-items: center;
        margin-bottom: 0.5rem;
    }
    .btn-primary {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        width: 100%;
        transition: 0.2s;
    }
    .btn-primary:hover {
        background: #0e4f50;
    }
    .btn-outline-custom {
        background: transparent;
        border: 1px solid #1D6E6F;
        color: #1D6E6F;
        padding: 8px 16px;
        border-radius: 40px;
        cursor: pointer;
        margin-top: 0.5rem;
    }
    .btn-danger {
        background: #dc3545;
        color: white;
        border: none;
        padding: 6px 0;
        border-radius: 30px;
        cursor: pointer;
        width: 100%;
        text-align: center;
    }
    .alert-danger {
        background: #f8d7da;
        color: #721c24;
        padding: 0.75rem 1.2rem;
        border-radius: 20px;
        margin-bottom: 1rem;
    }
    hr {
        margin: 1.5rem 0;
        border: none;
        border-top: 1px solid #e2e8f0;
    }
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
        }
        .budget-row {
            grid-template-columns: 1fr;
            gap: 0.5rem;
        }
        .form-container {
            margin: 1rem;
            padding: 1.5rem;
        }
        .btn-danger {
            width: auto;
        }
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Start a Community Project</h1>
        <p>Fill in the details below to create your project draft</p>
    </div>
</div>

<div class="form-container">
    <?php if ($error): ?>
        <div class="alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <form method="POST" id="projectForm">
        <div class="form-group">
            <label>Project Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label>Category</label>
            <select name="category" class="form-select" required>
                <option value="">Select category...</option>
                <?php foreach (['park','mural','youth_program','infrastructure','community_garden','public_art','education','other'] as $cat): ?>
                    <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $cat))) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="6" required></textarea>
            <small style="font-size:0.75rem; color:#6c757d;">Explain the problem, your solution, why it benefits the community, and how you'll execute it.</small>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>Funding Goal ($)</label>
                <input type="number" name="funding_goal" class="form-control" min="100" step="0.01" required>
            </div>
            <div class="form-group">
                <label>Deadline</label>
                <input type="date" name="deadline" class="form-control" min="<?= date('Y-m-d', strtotime('+30 days')) ?>" required>
            </div>
        </div>
        
        <?php if (!empty($userOrgs)): ?>
        <div class="form-group">
            <label>Link to Organization (optional)</label>
            <select name="organization_id" class="form-select">
                <option value="">None</option>
                <?php foreach ($userOrgs as $org): ?>
                    <option value="<?= $org['id'] ?>"><?= htmlspecialchars($org['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        
        <div class="form-group">
            <label>Your Municipality</label>
            <select name="municipality_id" class="form-select" required>
                <option value="">Select your municipality</option>
                <?php
                $municipalities = $db->query("SELECT id, name FROM municipalities ORDER BY name");
                foreach ($municipalities as $mun) {
                    $selected = ($currentUser && $currentUser->municipality_id == $mun['id']) ? 'selected' : '';
                    echo '<option value="' . $mun['id'] . '" ' . $selected . '>' . htmlspecialchars($mun['name']) . '</option>';
                }
                ?>
            </select>
            <small>You can only create projects in your registered municipality.</small>
        </div>
        
        <hr>
        <h4 style="margin-bottom: 1rem;">Budget Breakdown (Optional)</h4>
        <div id="budgetItems">
            <div class="budget-row">
                <input type="text" name="budget_items[0][name]" class="form-control" placeholder="Item name">
                <input type="text" name="budget_items[0][vendor]" class="form-control" placeholder="Vendor">
                <input type="number" name="budget_items[0][cost]" class="form-control" placeholder="Cost" step="0.01">
                <button type="button" class="btn-danger remove-row">✕</button>
            </div>
        </div>
        <button type="button" class="btn-outline-custom" id="addBudgetRow">+ Add Item</button>
        <div class="form-group">
    <label>Stretch Goal ($) (optional)</label>
    <input type="number" name="stretch_goal" class="form-control" step="0.01">
</div>
        
        <div class="mt-4" style="margin-top: 1.5rem;">
            <button type="submit" class="btn-primary">Create Project Draft</button>
        </div>
    </form>
</div>
<script>
let clickTimeout = false;
document.getElementById('addBudgetRow').addEventListener('click', function(e) {
    e.stopImmediatePropagation();
    clickTimeout = true;
    
    const budgetContainer = document.getElementById('budgetItems');
    let rowCount = budgetContainer.querySelectorAll('.budget-row').length;
    const newRow = document.createElement('div');
    newRow.className = 'budget-row';
    newRow.innerHTML = `<input type="text" name="budget_items[${rowCount}][name]" class="form-control" placeholder="Item name">
        <input type="text" name="budget_items[${rowCount}][vendor]" class="form-control" placeholder="Vendor">
        <input type="number" name="budget_items[${rowCount}][cost]" class="form-control" placeholder="Cost" step="0.01">
        <button type="button" class="btn-danger remove-row">✕</button>`;
    budgetContainer.appendChild(newRow);
    
    setTimeout(() => { clickTimeout = false; }, 300);
});
</script>

<?php require_once BASE_PATH . '/includes/footer.php'; ?>