<?php
$pageTitle = 'Manage Organization Members';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$org_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($org_id <= 0) {
    header('/../pages/dashboard.php');
    exit;
}

$db = Database::getInstance();
$orgObj = new Organization();
$org = $orgObj->getOrganization($org_id);
if (!$org || ($org['user_id'] != $currentUser->id && $currentUser->role !== 'admin')) {
    $_SESSION['error'] = 'You are not authorized to manage this organization.';
    header('Location: organization.php');
    exit;
}

// معالجة إضافة عضو
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
    $username = trim($_POST['username'] ?? '');
    if ($username) {
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        if ($user) {
            if ($orgObj->isMember($org_id, $user['id'])) {
                $error = "User is already a member.";
            } else {
                $orgObj->addMember($org_id, $user['id'], 'member');
                $success = "Member added successfully.";
            }
        } else {
            $error = "User not found.";
        }
    } else {
        $error = "Please enter a username or email.";
    }
}

// معالجة إزالة عضو
if (isset($_GET['remove'])) {
    $user_id = (int)$_GET['remove'];
    if ($orgObj->isAdmin($org_id, $currentUser->id) || $currentUser->role === 'admin') {
        $orgObj->removeMember($org_id, $user_id);
        $_SESSION['success'] = "Member removed.";
    } else {
        $_SESSION['error'] = "Only organization admin can remove members.";
    }
    header("Location: manage_organization.php?id=$org_id");
    exit;
}

// معالجة الموافقة على طلب ربط مشروع
if (isset($_GET['approve_request'])) {
    $req_id = (int)$_GET['approve_request'];
    $stmt = $db->prepare("SELECT * FROM organization_project_requests WHERE id = ?");
    $stmt->execute([$req_id]);
    $req = $stmt->fetch();
    if ($req && $req['organization_id'] == $org_id && $req['status'] == 'pending') {
        // تحديث حالة الطلب
        $db->prepare("UPDATE organization_project_requests SET status = 'approved', responded_at = NOW() WHERE id = ?")->execute([$req_id]);
        // ربط المشروع بالمنظمة
        $db->prepare("UPDATE projects SET organization_id = ? WHERE id = ?")->execute([$org_id, $req['project_id']]);
        // إضافة المستخدم كعضو (اختياري)
        if (!$orgObj->isMember($org_id, $req['requester_id'])) {
            $orgObj->addMember($org_id, $req['requester_id'], 'member');
        }
        $_SESSION['success'] = "Project request approved and linked.";
    } else {
        $_SESSION['error'] = "Invalid request or already processed.";
    }
    header("Location: manage_organization.php?id=$org_id");
    exit;
}

// معالجة رفض طلب ربط مشروع
if (isset($_GET['reject_request'])) {
    $req_id = (int)$_GET['reject_request'];
    $db->prepare("UPDATE organization_project_requests SET status = 'rejected', responded_at = NOW() WHERE id = ?")->execute([$req_id]);
    $_SESSION['success'] = "Project request rejected.";
    header("Location: manage_organization.php?id=$org_id");
    exit;
}

$members = $orgObj->getMembers($org_id);


?>

<style>
    .org-manager-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .org-manager-card {
        background: white;
        border-radius: 24px;
        padding: 1.8rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .org-manager-title {
        font-size: 1.6rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #1e2a3e;
        border-bottom: 2px solid #e2e8f0;
        padding-bottom: 0.5rem;
    }
    .form-group {
        margin-bottom: 1.2rem;
    }
    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 0.4rem;
        font-size: 0.85rem;
        color: #2c3e50;
    }
    .form-control {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 20px;
        font-size: 0.9rem;
    }
    .btn-primary-custom {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        display: inline-block;
        text-decoration: none;
    }
    .btn-secondary-custom {
        background: #6c757d;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
    }
    .alert {
        padding: 0.75rem 1.2rem;
        border-radius: 20px;
        margin-bottom: 1rem;
    }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-danger { background: #f8d7da; color: #721c24; }
    .members-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 16px;
        overflow: hidden;
        margin-top: 1rem;
    }
    .members-table th {
        background: #f8fafc;
        padding: 12px;
        text-align: left;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        color: #7f8c8d;
        border-bottom: 1px solid #e2e8f0;
    }
    .members-table td {
        padding: 12px;
        border-bottom: 1px solid #edf2f7;
        font-size: 0.85rem;
    }
    .request-item {
        background: #f1f5f9;
        border-radius: 16px;
        padding: 1rem;
        margin-bottom: 1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
    }
    .request-actions a {
        margin-left: 1rem;
        text-decoration: none;
        font-weight: 600;
    }
    .remove-link { color: #dc3545; }
    @media (max-width: 768px) {
        .members-table thead { display: none; }
        .members-table tr { display: block; margin-bottom: 1rem; border: 1px solid #e2e8f0; border-radius: 12px; }
        .members-table td { display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; }
        .members-table td:before { content: attr(data-label); font-weight: 700; width: 40%; }
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Manage Organization</h1>
        <p><?= htmlspecialchars($org['name']) ?></p>
    </div>
</div>

<div class="org-manager-container">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>


    <!-- إضافة عضو جديد -->
    <div class="org-manager-card">
        <h2 class="org-manager-title">➕ Add New Member</h2>
        <form method="POST">
            <div class="form-group">
                <label>Username or Email</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username or email" required>
            </div>
            <button type="submit" name="add_member" class="btn-primary-custom">Add Member</button>
        </form>
    </div>

    <!-- قائمة الأعضاء الحاليين -->
    <div class="org-manager-card">
        <h2 class="org-manager-title">📋 Current Members</h2>
        <?php if (empty($members)): ?>
            <div class="alert alert-info">No members yet. Add the first member above.</div>
        <?php else: ?>
            <table class="members-table">
                <thead>
                    <tr><th>Username</th><th>Full Name</th><th>Email</th><th>Role</th><th>Joined At</th><th>Action</th></tr></thead>
                <tbody>
                    <?php foreach ($members as $m): ?>
                    <tr>
                        <td data-label="Username"><?= htmlspecialchars($m['username']) ?></td>
                        <td data-label="Full Name"><?= htmlspecialchars($m['full_name']) ?></td>
                        <td data-label="Email"><?= htmlspecialchars($m['email']) ?></td>
                        <td data-label="Role"><?= htmlspecialchars($m['role']) ?></td>
                        <td data-label="Joined At"><?= htmlspecialchars($m['joined_at']) ?></td>
                        <td data-label="Action">
                           <?php if ($m['id'] != $org['user_id'] && ($orgObj->isAdmin($org_id, $currentUser->id) || $currentUser->role === 'admin')): ?>
                                <a href="?id=<?= $org_id ?>&remove=<?= $m['id'] ?>" class="remove-link" onclick="return confirm('Remove this member?')">Remove</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div style="text-align: center; margin-top: 1rem;">
        <a href="organization.php" class="btn-secondary-custom">← Back to Organizations</a>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>