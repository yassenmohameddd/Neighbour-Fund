<?php
$pageTitle = 'My Dashboard';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

if (!$currentUser || !isset($currentUser->id)) {
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}



$db = Database::getInstance();


if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger">' . htmlspecialchars($_SESSION['error']) . '</div>';
    unset($_SESSION['error']);
}
if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
    unset($_SESSION['success']);
}



$myProjects = [];
try {
    $stmt = $db->prepare("
        SELECT * 
        FROM projects 
        WHERE project_lead_id = ? 
        ORDER BY created_at DESC
    ");
    $stmt->execute([$currentUser->id]);
    $myProjects = $stmt->fetchAll();

    foreach ($myProjects as $index => $p) {
        $projObj = new Project();
        $proj = $projObj->getProjectById($p['id']);
        if ($proj) {
            $proj->checkFundingDeadline();
            $myProjects[$index]['status'] = $proj->status;
        }
    }

} catch (PDOException $e) {
    $myProjects = [];
}



$myDonations = [];
$totalDonated = 0;
try {
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE user_id = ? AND status IN ('completed', 'released')");
    $stmt->execute([$currentUser->id]);
    $totalDonated = $stmt->fetchColumn();
    
    $stmt = $db->prepare("SELECT d.*, p.title, p.slug FROM donations d JOIN projects p ON d.project_id = p.id WHERE d.user_id = ? ORDER BY d.created_at DESC");
    $stmt->execute([$currentUser->id]);
    $myDonations = $stmt->fetchAll();
} catch (PDOException $e) {
    $totalDonated = 0;
    $myDonations = [];
}



$volunteering = [];
try {
    $volunteering = $db->prepare("SELECT v.*, p.title, p.slug FROM volunteers v JOIN projects p ON v.project_id = p.id WHERE v.user_id = ?");
    $volunteering->execute([$currentUser->id]);
    $volunteering = $volunteering->fetchAll();
} catch (PDOException $e) {
    $volunteering = [];
}



$champion = null;
if (class_exists('ChampionPledge')) {
    try {
        $champion = ChampionPledge::getActiveForUser($currentUser->id);
    } catch (Exception $e) {}
}

$karmaScore = $currentUser->karma_score ?? 0;
$volunteerHours = $currentUser->volunteer_hours ?? 0;
?>

<div class="hero" style="padding: 120px 5% 60px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Dashboard</h1>
        <p>Welcome back, <?= htmlspecialchars($currentUser->full_name ?? $currentUser->username ?? 'User') ?>!</p>
    </div>
</div>

<div class="section" style="padding-top: 0;">
    <div class="stats-grid" style="margin-top: -30px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem;">
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 20px; text-align: center;">
            <div class="stat-number" style="font-size: 2rem; font-weight: bold; color: #1D6E6F;"><?= count($myProjects) ?></div>
            <div class="stat-label">My Projects</div>
        </div>
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 20px; text-align: center;">
            <div class="stat-number" style="font-size: 2rem; font-weight: bold; color: #1D6E6F;">$<?= number_format($totalDonated, 0) ?></div>
            <div class="stat-label">Total Donated</div>
        </div>
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 20px; text-align: center;">
            <div class="stat-number" style="font-size: 2rem; font-weight: bold; color: #1D6E6F;"><?= (int)$karmaScore ?></div>
            <div class="stat-label">Karma Points</div>
        </div>
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 20px; text-align: center;">
            <div class="stat-number" style="font-size: 2rem; font-weight: bold; color: #1D6E6F;"><?= (int)$volunteerHours ?></div>
            <div class="stat-label">Volunteer Hours</div>
        </div>
    </div>
</div>

<div class="section" style="padding-top: 0;">
    <div class="section-header" style="text-align: left;">
        <div class="section-tag">My Activity</div>
        <h2 class="section-title">Projects I've Started</h2>
    </div>
    <?php if (empty($myProjects)): ?>
        <div style="text-align: center; padding: 3rem; background: white; border-radius: 20px;">
            <p>No projects yet. <a href="create-project.php" style="color: var(--primary-light);">Start your first project →</a></p>
        </div>
    <?php else: ?>
        <?php foreach ($myProjects as $p): ?>
            <div style="background: white; border-radius: 20px; padding: 1.5rem; margin-bottom: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <div>
                        <h3 style="font-size: 1.2rem;"><?= htmlspecialchars($p['title']) ?></h3>
                        <span class="badge" style="background: <?= $p['status'] == 'live' ? '#27ae60' : '#7f8c8d' ?>; color: white; padding: 4px 12px; border-radius: 20px;"><?= htmlspecialchars(ucfirst($p['status'])) ?></span>
                        <span style="margin-left: 1rem;">$<?= number_format($p['current_amount'], 0) ?> / $<?= number_format($p['funding_goal'], 0) ?></span>
                        <?php
                        // عرض المبلغ المحرر (released) للمشروع
                        $releasedStmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) as total_released FROM donations WHERE project_id = ? AND status = 'released'");
                        $releasedStmt->execute([$p['id']]);
                        $released = $releasedStmt->fetchColumn();
                        if ($released > 0): ?>
                            <div style="margin-top: 0.5rem; font-size: 0.85rem; color: #28a745;">
                                <strong>Released:</strong> $<?= number_format($released, 2) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <a href="project.php?slug=<?= urlencode($p['slug']) ?>" class="btn-outline-custom" style="padding: 8px 20px; border: 1px solid #1D6E6F; border-radius: 40px; text-decoration: none;">View</a>
                        <a href="project-updates.php?project_id=<?= $p['id'] ?>" class="btn-outline-custom" style="margin-left: 10px;">📢 Updates</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>