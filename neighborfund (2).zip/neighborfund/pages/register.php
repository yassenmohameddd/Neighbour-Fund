
<?php
session_start();

define('BASE_URL', '/neighborfund');
define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'] . BASE_URL);

require_once BASE_PATH . '/config/database.php';

$db = Database::getInstance(); 

$pageTitle = 'Register';
require_once __DIR__ . '/../includes/header.php';

if (Auth::isLoggedIn()) {
    echo '<script>window.location.href = "dashboard.php";</script>';
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $municipality_id = trim($_POST['municipality_id'] ?? '');

    if (empty($username) || empty($email) || empty($password) || empty($full_name) || empty($municipality_id)) {
        $error = 'All required fields must be filled.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        try {

            // Check if username or email exists
            $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);

            if ($stmt->fetch()) {
                $error = 'Username or email already exists.';
            } else {

                $hashed = password_hash($password, PASSWORD_BCRYPT);

                $stmt = $db->prepare("
                    INSERT INTO users 
                    (username, email, password_hash, full_name, phone, address, municipality_id, role, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'user', NOW())
                ");

                $stmt->execute([
                    $username,
                    $email,
                    $hashed,
                    $full_name,
                    $phone,
                    $address,
                    $municipality_id
                ]);

                $success = 'Registration successful! You can now login.';
                $_POST = [];
            }

        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="hero" style="padding: 120px 5% 60px;">
    <div class="hero-content" style="text-align: left; max-width: 500px; margin: 0 auto;">
        <h1 style="font-size: 2rem;">Create an Account</h1>
        <p>Join NeighborFund to support local projects.</p>
    </div>
</div>

<div class="section" style="padding-top: 0;">
    <div style="max-width: 500px; margin: 0 auto; background: linear-gradient(135deg, var(--primary), var(--primary-light)); border-radius: 24px; padding: 2rem; box-shadow: 0 4px 12px rgba(0,0,0,0.08); color: #ffffff;">

        <?php if ($error): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 12px; margin-bottom: 1rem;">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div style="background: #d4edda; color: #155724; padding: 10px; border-radius: 12px; margin-bottom: 1rem;">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Username *</label>
                <input type="text" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Email *</label>
                <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Full Name *</label>
                <input type="text" name="full_name" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Password *</label>
                <input type="password" name="password" required>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Confirm Password *</label>
                <input type="password" name="confirm_password" required>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Phone</label>
                <input type="tel" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Address</label>
                <textarea name="address"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Your Municipality *</label>
                <select name="municipality_id" required>
                    <option value="">Select your municipality</option>

                    <?php
                    $municipalities = $db->query("SELECT id, name FROM municipalities ORDER BY name");

                    foreach ($municipalities as $mun) {
                        $selected = (($_POST['municipality_id'] ?? '') == $mun['id']) ? 'selected' : '';
                        echo '<option value="' . $mun['id'] . '" ' . $selected . '>' . htmlspecialchars($mun['name']) . '</option>';
                    }
                    ?>

                </select>
            </div>

            <button type="submit" style="background: #1D6E6F; color: white; padding: 12px; border: none; border-radius: 40px; width: 100%; cursor: pointer;">
                Register
            </button>

        </form>

        <p style="text-align: center; margin-top: 1rem;">
            Already have an account? <a href="login.php" style="color: #ed943b;">Login</a>
        </p>

    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

