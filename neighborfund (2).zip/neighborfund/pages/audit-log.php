<?php
$pageTitle = 'Audit Log';
require_once '../includes/header.php';
if (!Auth::checkRole('admin')) {
    echo '<script>window.location.href = "index.php";</script>';
      exit; }
$logs = Audit::getLogs(200);
?>
<h2>System Audit Trail</h2>
<table class="table table-striped">
    <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>IP</th></tr></thead>
    <tbody>
    <?php foreach ($logs as $log): ?>
        <tr><td><?= $log['created_at'] ?></td><td><?= htmlspecialchars($log['username'] ?? 'System') ?></td><td><?= htmlspecialchars($log['action']) ?></td><td><?= $log['entity_type'] ?> #<?= $log['entity_id'] ?></td><td><?= $log['ip_address'] ?></td></tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php require_once '../includes/footer.php'; ?>