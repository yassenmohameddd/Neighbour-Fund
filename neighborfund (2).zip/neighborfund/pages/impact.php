<?php
$pageTitle = 'Global Impact Dashboard';
require_once __DIR__ . '/../includes/header.php';

$db = Database::getInstance();



$totalProjects = $db->query("SELECT COUNT(*) FROM projects WHERE status IN ('live','funded','completed')")->fetchColumn();
$totalRaised = $db->query("SELECT SUM(current_amount) FROM projects")->fetchColumn();
$totalBackers = $db->query("SELECT COUNT(DISTINCT user_id) FROM donations WHERE status IN ('escrow','released')")->fetchColumn();
$totalVolunteerHours = $db->query("SELECT SUM(hours_completed) FROM volunteers WHERE status='approved'")->fetchColumn();

// التبرعات الشهرية لآخر 12 شهراً (للرسم البياني)
$monthly = $db->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as total
    FROM donations
    WHERE status IN ('escrow','released')
    GROUP BY month
    ORDER BY month DESC
    LIMIT 12
")->fetchAll();
$months = array_column(array_reverse($monthly), 'month');
$totals = array_column(array_reverse($monthly), 'total');
?>

<style>
    .impact-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }
    .impact-card {
        background: white;
        border-radius: 24px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .impact-number {
        font-size: 2.5rem;
        font-weight: 800;
        color: #1D6E6F;
    }
    .impact-label {
        font-size: 0.8rem;
        text-transform: uppercase;
        color: #4a5568;
    }
    .impact-chart {
        background: white;
        border-radius: 24px;
        padding: 1.5rem;
        margin-top: 1rem;
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Global Impact Dashboard</h1>
        <p>See how NeighborFund is changing communities</p>
    </div>
</div>

<div class="impact-stats">
    <div class="impact-card">
        <div class="impact-number"><?= number_format($totalProjects) ?></div>
        <div class="impact-label">Projects Funded</div>
    </div>
    <div class="impact-card">
        <div class="impact-number">$<?= number_format($totalRaised, 0) ?></div>
        <div class="impact-label">Total Raised</div>
    </div>
    <div class="impact-card">
        <div class="impact-number"><?= number_format($totalBackers) ?></div>
        <div class="impact-label">Community Backers</div>
    </div>
    <div class="impact-card">
        <div class="impact-number"><?= number_format($totalVolunteerHours) ?></div>
        <div class="impact-label">Volunteer Hours</div>
    </div>
</div>

<div class="impact-chart">
    <h3>Monthly Donations (Last 12 months)</h3>
    <canvas id="donationTrendChart" width="800" height="400"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('donationTrendChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($months) ?>,
            datasets: [{
                label: 'Donations (USD)',
                data: <?= json_encode($totals) ?>,
                borderColor: '#1D6E6F',
                backgroundColor: 'rgba(29, 110, 111, 0.1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                tooltip: { callbacks: { label: (ctx) => `$${ctx.raw.toFixed(2)}` } }
            },
            scales: {
                y: { beginAtZero: true, ticks: { callback: (value) => '$' + value } }
            }
        }
    });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>