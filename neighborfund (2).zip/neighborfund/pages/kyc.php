<?php
$pageTitle = 'Identity Verification';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = Database::getInstance();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // محاكاة رفع مستند
    $stmt = $db->prepare("INSERT INTO kyc_documents (user_id, document_path, status) VALUES (?, ?, 'pending')");
    $stmt->execute([$currentUser->id, 'uploaded_' . time()]);
    $success = "Your KYC request has been submitted. Waiting for admin review.";
}
$stmt = $db->prepare("SELECT * FROM kyc_documents WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$currentUser->id]);
$kyc = $stmt->fetch();
?>
<div class="hero" style="padding:80px 5% 30px;"><div class="hero-content"><h1>Verify Your Identity</h1></div></div>
<div class="section" style="max-width:600px; margin:0 auto;">
    <?php if ($kyc && $kyc['status'] == 'verified'): ?>
        <div class="alert alert-success">✅ Your identity is verified. You can now create projects.</div>
    <?php elseif ($kyc && $kyc['status'] == 'pending'): ?>
        <div class="alert alert-warning">⏳ Your documents are under review.</div>
    <?php else: ?>
        <form method="POST">
            <div class="form-group"><label>Upload ID (simulated)</label><input type="file" class="form-control" disabled><small>In demo, just click submit.</small></div>
            <button type="submit" class="btn-primary">Submit for Verification</button>
        </form>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>