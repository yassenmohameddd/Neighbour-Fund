<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$pageTitle = 'Home';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance();


$featured = $db->query("
    SELECT p.*, u.full_name as lead_name,
    (p.current_amount / p.funding_goal * 100) as percent_funded,
    (SELECT COUNT(*) FROM donations WHERE project_id = p.id AND status IN ('confirmed','escrow','released')) as backers_count
    FROM projects p
    JOIN users u ON p.project_lead_id = u.id
    WHERE p.status = 'live'
    ORDER BY p.current_amount DESC
    LIMIT 6
")->fetchAll();


$stats = $db->query("
    SELECT 
        COUNT(*) as total_projects,
        SUM(current_amount) as total_raised,
        COUNT(DISTINCT project_lead_id) as total_leads,
        (SELECT COUNT(*) FROM users WHERE role = 'user') as total_residents
    FROM projects
    WHERE status IN ('live', 'funded', 'completed')
")->fetch();
?>


<section class="hero">
    <div class="hero-content">
        <h1>Fund Your Neighborhood</h1>
        <p>Hyper-local crowdfunding for parks, murals, youth programs & more. Make a difference in your community today.</p>
        <div>
            <a href="<?= BASE_URL ?>/pages/projects.php" class="btn-hero btn-hero-primary"><i class="fas fa-rocket"></i> Explore Projects</a>
            <a href="<?= BASE_URL ?>/pages/create-project.php" class="btn-hero btn-hero-outline"><i class="fas fa-plus-circle"></i> Start a Project</a>
        </div>
    </div>
</section>


<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_projects'] ?? 0) ?></div>
        <div class="stat-label">Total Projects</div>
    </div>
    <div class="stat-card">
        <div class="stat-number">$<?= number_format($stats['total_raised'] ?? 0, 0) ?></div>
        <div class="stat-label">Total Raised</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_leads'] ?? 0) ?></div>
        <div class="stat-label">Project Leads</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_residents'] ?? 0) ?></div>
        <div class="stat-label">Active Residents</div>
    </div>
</div>


<section class="section">
    <div class="section-header">
        <div class="section-tag">Community Picks</div>
        <h2 class="section-title">Featured Projects</h2>
    </div>
    <div class="projects-grid">
        <?php foreach ($featured as $p): ?>
        <a href="project.php?slug=<?= $p['slug'] ?>" class="project-card">
            <div class="project-image">
                <span>🌳</span>
                <span class="project-badge">Live</span>
            </div>
            <div class="project-content">
                <div class="project-category"><?= ucfirst($p['category']) ?></div>
                <h3 class="project-title"><?= htmlspecialchars($p['title']) ?></h3>
                <div class="project-location"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($p['region'] ?? 'Local') ?></div>
                <div class="progress-bar-custom">
                    <div class="progress-fill-custom" style="width: <?= min(100, $p['percent_funded']) ?>%"></div>
                </div>
                <div class="project-stats">
                    <span><strong>$<?= number_format($p['current_amount'], 0) ?></strong> raised</span>
                    <span><?= round($p['percent_funded']) ?>%</span>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>