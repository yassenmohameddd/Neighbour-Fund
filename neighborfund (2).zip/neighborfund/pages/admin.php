<?php
$pageTitle = 'Admin Panel';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

if ($currentUser->role !== 'admin') {
    http_response_code(403);
    echo '<div class="hero" style="padding: 120px 5% 60px;"><div class="hero-content"><div class="alert alert-danger">Access Denied.</div></div></div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$db = Database::getInstance();
$section = $_GET['section'] ?? 'overview';
$success = '';
$error = '';


if ($section === 'users' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_ban'])) {
    $userId = (int)$_POST['user_id'];
    $stmt = $db->prepare("SELECT is_banned FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if ($user) {
        $newBanStatus = !$user['is_banned'];
        $reason = $newBanStatus ? ($_POST['ban_reason'] ?? 'Violation of terms') : null;
        $updateStmt = $db->prepare("UPDATE users SET is_banned = ?, ban_reason = ? WHERE id = ?");
        $updateStmt->execute([$newBanStatus, $reason, $userId]);
        // Log
        $db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)")
           ->execute([$currentUser->id, $newBanStatus ? 'user_banned' : 'user_unbanned', 'user', $userId, json_encode(['is_banned' => !$newBanStatus]), json_encode(['is_banned' => $newBanStatus]), $_SERVER['REMOTE_ADDR'] ?? '']);
        $success = "User " . ($newBanStatus ? "banned" : "unbanned") . " successfully.";
    }
}


if ($section === 'pending_projects' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_project_pending'])) {
    $projectId = (int)$_POST['project_id'];
    // الموافقة المبدئية لا تحتاج أصواتاً
    $db->prepare("UPDATE projects SET status = 'approved' WHERE id = ?")->execute([$projectId]);
    Audit::logAction($currentUser->id, 'project_approved', 'project', $projectId, ['status'=>'pending'], ['status'=>'approved']);
    $success = "Project approved. It now needs 5 community upvotes to go live.";
}



if ($section === 'users' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_user'])) {
    $userId = (int)$_POST['verify_user_id'];
    $db->prepare("UPDATE users SET id_verified = 1 WHERE id = ?")->execute([$userId]);
    $db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)")
       ->execute([$currentUser->id, 'user_verified', 'user', $userId, json_encode(['id_verified' => 0]), json_encode(['id_verified' => 1]), $_SERVER['REMOTE_ADDR'] ?? '']);
    $success = "User verified successfully.";
}



if ($section === 'vetting' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_project'])) {
    $projectId = (int)$_POST['project_id'];
    
    // جلب عدد upvotes للمشروع
    $stmt = $db->prepare("SELECT COUNT(*) as upvotes FROM votes WHERE item_type='project' AND item_id = ? AND vote_value = 1");
    $stmt->execute([$projectId]);
    $upvotes = $stmt->fetchColumn();
    $minUpvotes = (int)(count($db->query("SELECT id FROM users")->fetchAll())/2); // يمكن جعلها من جدول settings لاحقاً/////////////////////////////////////////////////
    
    if ($upvotes < $minUpvotes) {
        $error = "Project needs at least $minUpvotes community upvotes before going live. Current upvotes: $upvotes";
    } else {
        $db->prepare("UPDATE projects SET status = 'live' WHERE id = ? AND status = 'approved'")->execute([$projectId]);
        Audit::logAction($currentUser->id, 'project_live', 'project', $projectId, ['status'=>'approved'], ['status'=>'live']);
        $success = "Project is now live and accepting donations.";
    }
}



if ($section === 'vetting' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['force_live'])) {
    $projectId = (int)$_POST['project_id'];
    $update = $db->prepare("UPDATE projects SET status = 'live' WHERE id = ? AND status IN ('approved', 'community_vote')");
    $update->execute([$projectId]);
    if ($update->rowCount() > 0) {
        $db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)")
           ->execute([$currentUser->id, 'project_forced_live', 'project', $projectId, json_encode(['status' => 'unknown']), json_encode(['status' => 'live']), $_SERVER['REMOTE_ADDR'] ?? '']);
        $success = "Project is now LIVE (bypassed voting).";
    } else {
        $error = "Project not found or not eligible for force live.";
    }
}



if ($section === 'vetting' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_project'])) {
    $projectId = (int)$_POST['project_id'];
    $reason = trim($_POST['rejection_reason'] ?? 'No reason provided');
    $update = $db->prepare("UPDATE projects SET status = 'cancelled', vetting_notes = ?, completed_at = NOW() WHERE id = ? AND status = 'approved'");
    $update->execute([$reason, $projectId]);
    if ($update->rowCount() > 0) {
        $db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)")
           ->execute([$currentUser->id, 'project_rejected', 'project', $projectId, json_encode(['status' => 'under_review']), json_encode(['status' => 'cancelled', 'reason' => $reason]), $_SERVER['REMOTE_ADDR'] ?? '']);
        $success = "Project rejected.";
    } else {
        $error = "Project not found or not in under_review status.";
    }
}



if ($section === 'disputes' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve_dispute'])) {
    $disputeId = (int)$_POST['dispute_id'];
    $disputeObj = new Dispute();
    $disputeObj->resolveDispute($disputeId, $currentUser->id);
    $success = "Dispute resolved.";
}


if ($section === 'users' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    try {
        $check = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$_POST['username'], $_POST['email']]);
        if ($check->fetch()) throw new Exception("Username or email already exists.");
        $hashed = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $db->prepare("INSERT INTO users (username, email, password_hash, full_name, phone, address, municipality_id, role, id_verified, is_active) VALUES (?,?,?,?,?,?,?,?,?,?)")
           ->execute([
                $_POST['username'], $_POST['email'], $hashed, $_POST['full_name'],
                $_POST['phone'] ?? null, $_POST['address'] ?? null,
                !empty($_POST['municipality_id']) ? (int)$_POST['municipality_id'] : null,
                $_POST['role'], isset($_POST['id_verified']) ? 1 : 0, 1
           ]);
        $newUserId = $db->lastInsertId();
        $db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)")
           ->execute([$currentUser->id, 'user_created', 'user', $newUserId, json_encode([]), json_encode(['username' => $_POST['username'], 'role' => $_POST['role']]), $_SERVER['REMOTE_ADDR'] ?? '']);
        $success = "User '{$_POST['username']}' created successfully!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


if ($section === 'orgs' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_org'])) {
    $orgId = (int)$_POST['org_id'];
    $update = $db->prepare("UPDATE organizations SET verified = 1, verified_by = ?, verified_at = NOW() WHERE id = ? AND verified = 0");
    $update->execute([$currentUser->id, $orgId]);
    if ($update->rowCount() > 0) {
        $db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)")
           ->execute([$currentUser->id, 'organization_verified', 'organization', $orgId, json_encode(['verified' => 0]), json_encode(['verified' => 1]), $_SERVER['REMOTE_ADDR'] ?? '']);
        $success = "Organization verified.";
    } else {
        $error = "Org not found or already verified.";
    }
}



if ($section === 'volunteers' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_volunteer'])) {
        $volId = (int)$_POST['volunteer_id'];
        $db->prepare("UPDATE volunteers SET status = 'approved' WHERE id = ?")->execute([$volId]);
        Audit::logAction($currentUser->id, 'volunteer_approved', 'volunteer', $volId, [], []);
        $success = "Volunteer request approved.";
    } elseif (isset($_POST['reject_volunteer'])) {
        $volId = (int)$_POST['volunteer_id'];
        $db->prepare("UPDATE volunteers SET status = 'rejected' WHERE id = ?")->execute([$volId]);
        Audit::logAction($currentUser->id, 'volunteer_rejected', 'volunteer', $volId, [], []);
        $success = "Volunteer request rejected.";
    }
}


if ($section === 'vetting' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_sustainability'])) {
    $projectId = (int)$_POST['project_id'];
    $score = (int)$_POST['sustainability_score'];
    $notes = trim($_POST['sustainability_notes']);
    $db->prepare("UPDATE projects SET sustainability_score = ?, sustainability_notes = ? WHERE id = ?")->execute([$score, $notes, $projectId]);
    $success = "Sustainability assessment saved.";
    Audit::logAction($currentUser->id, 'sustainability_assessed', 'project', $projectId, [], ['score' => $score, 'notes' => $notes]);
}




$vettingProjects = [];
$pendingComments = [];
$allUsers = [];
$auditLogs = [];
$organizations = [];
$pendingProjects = [];

switch ($section) {
    case 'vetting':
        $vettingProjects = $db->query("SELECT p.*, u.full_name as lead_name, u.karma_score as credibility_rating FROM projects p JOIN users u ON p.project_lead_id = u.id WHERE p.status = 'approved' ORDER BY p.created_at DESC")->fetchAll();
        break;
    case 'pending_projects':
        $pendingProjects = $db->query("SELECT p.*, u.full_name as lead_name FROM projects p JOIN users u ON p.project_lead_id = u.id WHERE p.status = 'pending' ORDER BY p.created_at ASC")->fetchAll();
        break;
    case 'volunteers':
        $volRequests = $db->query("SELECT v.*, u.full_name, p.title as project_title FROM volunteers v JOIN users u ON v.user_id = u.id JOIN projects p ON v.project_id = p.id WHERE v.status = 'pending'")->fetchAll();
        break;
    case 'disputes':
        try {
            $disputeObj = new Dispute();
            $pendingDisputes = $disputeObj->getDisputes('pending');
        } catch (PDOException $e) {
            $pendingDisputes = [];
            $error = "Error loading disputes: " . $e->getMessage();
        }
        break;
    case 'users':
        try {
            $allUsers = $db->query("SELECT u.*, m.name as municipality_name FROM users u LEFT JOIN municipalities m ON u.municipality_id = m.id ORDER BY u.created_at DESC LIMIT 100")->fetchAll();
        } catch (PDOException $e) {
            $allUsers = $db->query("SELECT u.*, NULL as municipality_name FROM users u ORDER BY u.created_at DESC LIMIT 100")->fetchAll();
            $error = "Municipalities table missing. Some data may be incomplete.";
        }
        break;
    case 'audit':
        $auditLogs = $db->query("SELECT al.*, u.username FROM audit_log al LEFT JOIN users u ON al.user_id = u.id ORDER BY al.created_at DESC LIMIT 200")->fetchAll();
        break;
    case 'orgs':
        try {
            $organizations = $db->query("SELECT o.*, u.full_name as verified_by_name FROM organizations o LEFT JOIN users u ON o.verified_by = u.id ORDER BY o.created_at DESC")->fetchAll();
        } catch (PDOException $e) {
            $organizations = [];
            $error = "Organizations table not found. Please run the database schema.";
        }
        break;
}

$overviewStats = $db->query("SELECT (SELECT COUNT(*) FROM projects) as total_projects, (SELECT COUNT(*) FROM projects WHERE status = 'pending') as pending_vetting, (SELECT COUNT(*) FROM users WHERE id_verified = FALSE) as pending_kyc")->fetch();
?>

<style>
    .admin-stats { display: grid; grid-template-columns: repeat(3,1fr); gap:1.5rem; margin-bottom:2rem; }
    .stat-card-admin { background:white; border-radius:20px; padding:1.5rem; text-align:center; box-shadow:0 4px 12px rgba(0,0,0,0.08); }
    .stat-number-admin { font-size:2.5rem; font-weight:800; color:#1D6E6F; }
    .stat-label-admin { font-size:0.75rem; text-transform:uppercase; color:#7f8c8d; }
    .admin-tabs { display:flex; gap:0.5rem; flex-wrap:wrap; margin-bottom:2rem; border-bottom:1px solid #e2e8f0; padding-bottom:0.5rem; }
    .admin-tab { padding:0.5rem 1.2rem; border-radius:40px; text-decoration:none; font-weight:600; font-size:0.85rem; background:transparent; color:#2c3e50; transition:0.2s; }
    .admin-tab:hover { background:rgba(29,110,111,0.1); color:#1D6E6F; }
    .admin-tab-active { background:#1D6E6F; color:white; }
    .users-table { width:100%; border-collapse:collapse; background:white; border-radius:16px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.05); }
    .users-table th { background:#f8fafc; padding:12px; text-align:left; font-size:0.7rem; font-weight:700; text-transform:uppercase; color:#7f8c8d; border-bottom:1px solid #e2e8f0; }
    .users-table td { padding:12px; border-bottom:1px solid #edf2f7; font-size:0.85rem; }
    .action-buttons { display:flex; gap:6px; flex-wrap:wrap; }
    .btn-action { padding:4px 10px; border-radius:30px; font-size:0.7rem; font-weight:600; border:none; cursor:pointer; }
    .btn-ban { background:#dc3545; color:white; }
    .btn-unban { background:#28a745; color:white; }
    .btn-verify { background:#ffc107; color:#212529; }
    .btn-verified { background:#6c757d; color:white; cursor:default; }
    .btn-status-active { background:#d4edda; color:#155724; }
    .btn-status-banned { background:#f8d7da; color:#721c24; }
    .alert { padding:10px 15px; border-radius:12px; margin-bottom:1rem; }
    .alert-success { background:#d4edda; color:#155724; }
    .alert-danger { background:#f8d7da; color:#721c24; }
    @media (max-width:768px) {
        .admin-stats { grid-template-columns:1fr; }
        .users-table thead { display:none; }
        .users-table tr { display:block; margin-bottom:1rem; border:1px solid #e2e8f0; border-radius:12px; }
        .users-table td { display:flex; justify-content:space-between; align-items:center; }
        .users-table td:before { content:attr(data-label); font-weight:700; width:40%; }
    }
</style>

<div class="hero" style="padding:100px 5% 50px;">
    <div class="hero-content" style="text-align:left;">
        <h1 style="font-size:2rem;">Admin Panel</h1>
        <p>System oversight, vetting, users, organizations, audit trail</p>
    </div>
</div>

<div class="section" style="padding-top:0;">
    <div class="admin-stats">
        <div class="stat-card-admin"><div class="stat-number-admin"><?= (int)$overviewStats['total_projects'] ?></div><div class="stat-label-admin">Total Projects</div></div>
        <div class="stat-card-admin"><div class="stat-number-admin"><?= (int)$overviewStats['pending_vetting'] ?></div><div class="stat-label-admin">Pending Vetting</div></div>
        <div class="stat-card-admin"><div class="stat-number-admin"><?= (int)$overviewStats['pending_kyc'] ?></div><div class="stat-label-admin">Pending KYC</div></div>
    </div>

    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="admin-tabs">
        <a href="?section=overview" class="admin-tab <?= $section=='overview'?'admin-tab-active':'' ?>">Overview</a>
        <a href="?section=vetting" class="admin-tab <?= $section=='vetting'?'admin-tab-active':'' ?>">Vetting Queue <?= $overviewStats['pending_vetting']>0?'('.$overviewStats['pending_vetting'].')':'' ?></a>
        <a href="?section=disputes" class="admin-tab <?= $section=='disputes'?'admin-tab-active':'' ?>">Disputes</a>
        <a href="?section=users" class="admin-tab <?= $section=='users'?'admin-tab-active':'' ?>">Users & KYC</a>
        <a href="?section=volunteers" class="admin-tab">Volunteer Requests</a>
        <a href="?section=pending_projects" class="admin-tab <?= $section=='pending_projects'?'admin-tab-active':'' ?>">Pending Projects</a>
        <a href="?section=orgs" class="admin-tab <?= $section=='orgs'?'admin-tab-active':'' ?>">Organizations</a>
        <a href="?section=audit" class="admin-tab <?= $section=='audit'?'admin-tab-active':'' ?>">Audit Trail</a>
    </div>

        <?php if ($section === 'overview'): ?>
        <div class="alert alert-info">Welcome to Admin Panel. Use tabs above.</div>
        <div class="stat-card-admin" style="text-align:left; padding:1.5rem;"><h4>System Health</h4><ul><li>Database: <span style="color:#27ae60;">Connected</span></li><li>Total Users: <?= count($db->query("SELECT id FROM users")->fetchAll()) ?></li></ul></div>

    <?php elseif ($section === 'vetting'): ?>
        <h3>Projects Awaiting Vetting</h3>
        <?php if (empty($vettingProjects)): ?>
            <div class="alert alert-info">No projects pending review.</div>
        <?php else: foreach ($vettingProjects as $p): ?>
            <div style="background:white; border-radius:16px; padding:1rem; margin-bottom:1rem;">
                <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px;">
                    <div><h4><?= htmlspecialchars($p['title']) ?></h4><p>by <?= htmlspecialchars($p['lead_name']) ?> (Rating: <?= (float)$p['credibility_rating'] ?>)</p>
                        <?php if ($p['sustainability_score'] > 0): ?>
                            <div><strong>Sustainability:</strong> <?= $p['sustainability_score'] ?>/5</div>
                            <?php if (!empty($p['sustainability_notes'])) echo "<div><small>Notes: " . htmlspecialchars($p['sustainability_notes']) . "</small></div>"; ?>
                        <?php endif; ?>
                    </div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                        <form method="POST" style="display:inline-flex; gap:4px;">
                            <input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>">
                            <select name="sustainability_score" required>
                                <option value="">Rate Sustainability</option>
                                <option value="1">1 - Poor</option>
                                <option value="2">2 - Fair</option>
                                <option value="3">3 - Good</option>
                                <option value="4">4 - Very Good</option>
                                <option value="5">5 - Excellent</option>
                            </select>
                            <input type="text" name="sustainability_notes" placeholder="Notes (optional)" style="width:150px;">
                            <button type="submit" name="save_sustainability" class="btn-secondary" style="background:#6c757d;">Save Score</button>
                        </form>
                        <form method="POST"><input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>"><button type="submit" name="approve_project" class="btn-primary">Approve for Voting</button></form>
                        <form method="POST"><input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>"><button type="submit" name="force_live" class="btn-success">Force Live</button></form>
                        <form method="POST" class="reject-form" style="display:inline-flex; gap:4px;">...</form>
                    </div>
                </div>
            </div>
        <?php endforeach; endif; ?>

    <?php elseif ($section === 'disputes'): ?>
        <h3>Dispute Mediation</h3>
        <?php if (empty($pendingDisputes )): ?>
            <div class="alert alert-info">No pending disputes.</div>
        <?php else: foreach ($pendingDisputes  as $d): ?>
            <div style="background:white; border-radius:16px; padding:1rem; margin-bottom:1rem; border-left:4px solid #E2A76F;">
        <div style="display:flex; justify-content:space-between;">
            <div>
                <p><strong>Reported by:</strong> <?= htmlspecialchars($d['reporter']) ?></p>
                <p><strong>Comment:</strong> <?= nl2br(htmlspecialchars($d['content'])) ?></p>
                <p><strong>Reason:</strong> <?= nl2br(htmlspecialchars($d['reason'])) ?></p>
                <small>On: <a href="project.php?slug=<?= urlencode($d['slug']) ?>"><?= htmlspecialchars($d['project_title']) ?></a></small>
            </div>
            <form method="POST">
                <input type="hidden" name="dispute_id" value="<?= (int)$d['id'] ?>">
                <button type="submit" name="resolve_dispute" class="btn-primary">Resolve</button>
            </form>
        </div>
    </div>
        <?php endforeach; endif; ?>

    <?php elseif ($section === 'users'): ?>
        <h3>User Management & KYC</h3>
        <table class="users-table">
            <thead><tr><th>User</th><th>Role</th><th>Municipality</th><th>Karma</th><th>ID Verified</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($allUsers as $u): ?>
                <tr>
                    <td data-label="User"><strong><?= htmlspecialchars($u['full_name']) ?></strong><br><small>@<?= htmlspecialchars($u['username']) ?></small></td>
                    <td data-label="Role"><?= ucfirst($u['role']) ?></td>
                    <td data-label="Municipality"><?= htmlspecialchars($u['municipality_name'] ?? 'N/A') ?></td>
                    <td data-label="Karma"><?= (int)$u['karma_score'] ?></td>
                    <td data-label="ID Verified"><?= $u['id_verified'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-warning">Pending</span>' ?></td>
                    <td data-label="Status"><?= $u['is_banned'] ? '<span class="badge bg-danger">Banned</span>' : '<span class="badge bg-success">Active</span>' ?></td>
                    <td data-label="Actions"><div class="action-buttons">
                        <?php if($u['is_banned']): ?><span class="btn-action btn-status-banned">Banned</span><?php else: ?><span class="btn-action btn-status-active">Active</span><?php endif; ?>
                        <form method="POST"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><button type="submit" name="toggle_ban" class="btn-action <?= $u['is_banned']?'btn-unban':'btn-ban' ?>"><?= $u['is_banned']?'Unban':'Ban' ?></button></form>
                        <form method="POST"><input type="hidden" name="verify_user_id" value="<?= (int)$u['id'] ?>"><button type="submit" name="verify_user" class="btn-action <?= $u['id_verified']?'btn-verified':'btn-verify' ?>" <?= $u['id_verified']?'disabled':'' ?>><?= $u['id_verified']?'Verified':'Verify' ?></button></form>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="create-user-card" style="background:white; border-radius:20px; padding:1.5rem; margin-top:2rem;">
            <h4>➕ Create New User</h4>
            <form method="POST">
                <input type="hidden" name="create_user" value="1">
                <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:1rem;">
                    <input type="text" name="username" class="form-control" placeholder="Username *" required>
                    <input type="email" name="email" class="form-control" placeholder="Email *" required>
                    <input type="text" name="full_name" class="form-control" placeholder="Full Name *" required>
                    <input type="text" name="password" class="form-control" value="password" placeholder="Password *" required>
                    <input type="text" name="phone" class="form-control" placeholder="Phone">
                    <input type="text" name="address" class="form-control" placeholder="Address">
                    <input type="number" name="municipality_id" class="form-control" placeholder="Municipality ID" value="1">
                    <select name="role" class="form-select"><option value="user">User</option><option value="admin">Admin</option><option value="auditor">Auditor</option></select>
                    <div class="form-check"><input type="checkbox" name="id_verified" class="form-check-input" checked> <label class="form-check-label">ID Verified</label></div>
                </div>
                <button type="submit" class="btn-primary" style="margin-top:1rem;">Create User</button>
            </form>
        </div>

    <?php elseif ($section === 'volunteers'): ?>
        <h3>Volunteer Signups</h3>
        <?php if (empty($volRequests)): ?>
            <div class="alert alert-info">No volunteer requests pending.</div>
        <?php else: foreach ($volRequests as $v): ?>
            <div class="card p-3 mb-2" style="background:white; border-radius:16px; padding:1rem;">
                <p><strong><?= htmlspecialchars($v['full_name']) ?></strong> wants to volunteer in <strong><?= htmlspecialchars($v['project_title']) ?></strong></p>
                <p>Task: <?= htmlspecialchars($v['task_description']) ?> | Hours: <?= $v['hours_committed'] ?></p>
                <form method="POST">
                    <input type="hidden" name="volunteer_id" value="<?= $v['id'] ?>">
                    <button type="submit" name="approve_volunteer" class="btn-primary">Approve</button>
                    <button type="submit" name="reject_volunteer" class="btn-danger">Reject</button>
                </form>
            </div>
        <?php endforeach; endif; ?>

    <?php elseif ($section === 'pending_projects'): ?>
        <h3>Projects Awaiting Approval</h3>
        <?php if (empty($pendingProjects)): ?>
            <div class="alert alert-info">No pending projects.</div>
        <?php else: foreach ($pendingProjects as $p): ?>
            <div class="card p-3 mb-2" style="background:white; border-radius:16px; padding:1rem;">
                <h4><?= htmlspecialchars($p['title']) ?></h4>
                <p>By: <?= htmlspecialchars($p['lead_name']) ?></p>
                <p>Goal: $<?= number_format($p['funding_goal'],2) ?></p>
                <form method="POST">
                    <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
                    <button type="submit" name="approve_project_pending" class="btn-primary">Approve</button>
                </form>
            </div>
        <?php endforeach; endif; ?>

    <?php elseif ($section === 'orgs'): ?>
        <h3>Organization Verification</h3>
        <?php if(empty($organizations)): ?>
            <div class="alert alert-info">No organizations registered.</div>
        <?php else: ?>
        <table class="users-table">
            <thead><tr><th>Name</th><th>Reg. Number</th><th>Verified</th><th>Verified By</th><th>Action</th><td></thead>
            <tbody>
            <?php foreach($organizations as $org): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($org['name']) ?></strong></td>
                    <td><?= htmlspecialchars($org['registration_number']??'—') ?></td>
                    <td><?= $org['verified']?'<span class="badge bg-success">Yes</span>':'<span class="badge bg-warning">No</span>' ?></td>
                    <td><?= htmlspecialchars($org['verified_by_name']??'—') ?></td>
                    <td><?php if(!$org['verified']): ?>
                        <form method="POST">
                            <input type="hidden" name="org_id" value="<?= (int)$org['id'] ?>">
                            <button type="submit" name="verify_org" class="btn-action btn-verify">Verify</button>
                        </form>
                    <?php else: ?>
                        <span class="btn-action btn-verified">Verified</span>
                    <?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

    <?php elseif ($section === 'audit'): ?>
        <h3>Audit Trail</h3>
        <div style="overflow-x:auto;">
            <table class="users-table">
                <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr></thead>
                <tbody>
                <?php foreach($auditLogs as $log): ?>
                    <tr>
                        <td data-label="Time"><?= date('Y-m-d H:i:s',strtotime($log['created_at'])) ?></td>
                        <td data-label="User"><?= htmlspecialchars($log['username']??'System') ?></td>
                        <td data-label="Action"><?= htmlspecialchars($log['action']) ?></td>
                        <td data-label="Entity"><?= htmlspecialchars($log['entity_type']) ?> #<?= (int)$log['entity_id'] ?></td>
                        <td data-label="Details">
                            <?php
                            $new = json_decode($log['new_values'] ?? '{}', true);
                            if (!empty($new)) {
                                foreach ($new as $k => $v) {
                                    if ($k === 'password_hash') continue;
                                    echo '<span class="text-muted">' . htmlspecialchars($k) . ':</span> ' . (is_array($v) ? json_encode($v) : htmlspecialchars((string)$v)) . '<br>';
                                }
                            }
                            ?>
                        </td>
                        <td data-label="IP"><?= htmlspecialchars($log['ip_address']??'N/A') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>