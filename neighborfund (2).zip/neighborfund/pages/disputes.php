<?php
$pageTitle = 'Disputes';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';



if (!$currentUser || !isset($currentUser->id)) {
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}

$db = Database::getInstance();
$disputeObj = new Dispute();



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        $comment_id = (int)($_POST['comment_id'] ?? 0);
        $reason = trim($_POST['reason'] ?? '');
        if ($comment_id && !empty($reason)) {
            $disputeObj->createDispute($currentUser->id, $comment_id, $reason);
            $_SESSION['success'] = 'Dispute reported. Admin will review.';
        } else {
            $_SESSION['error'] = 'Please select a comment and provide a reason.';
        }
        echo '<script>window.location.href = "disputes.php";</script>';
        
        exit;
    } 
    elseif (isset($_POST['resolve']) && ($currentUser->role ?? '') === 'admin') {
        $dispute_id = (int)($_POST['dispute_id'] ?? 0);
        if ($dispute_id) {
            $disputeObj->resolveDispute($dispute_id, $currentUser->id);
            $_SESSION['success'] = 'Dispute resolved.';
        }
        echo '<script>window.location.href = "disputes.php";</script>';
        
        exit;
    } 
    elseif (isset($_POST['dismiss']) && ($currentUser->role ?? '') === 'admin') {
        $dispute_id = (int)($_POST['dispute_id'] ?? 0);
        if ($dispute_id) {
            $disputeObj->dismissDispute($dispute_id);
            $_SESSION['success'] = 'Dispute dismissed.';
        }
        echo '<script>window.location.href = "disputes.php";</script>';
        exit;
    }
}

// جلب النزاعات حسب نوع المستخدم
$userRole = $currentUser->role ?? 'user';
if ($userRole === 'admin') {
    $disputes = $disputeObj->getDisputes('pending');
} else {
    $disputes = $disputeObj->getUserDisputes($currentUser->id);
}

// جلب جميع التعليقات لعرضها في قائمة الاختيار (للمستخدم العادي)
$commentObj = new Comment();
$comments = $commentObj->getAllComments(100); // تمرير حد أقصى لتفادي التحميل الزائد
?>

<style>
    .disputes-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .disputes-card {
        background: white;
        border-radius: 28px;
        padding: 1.8rem;
        margin-bottom: 2rem;
        box-shadow: 0 8px 20px rgba(0,0,0,0.05);
    }
    .disputes-title {
        font-size: 1.6rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #1e2a3e;
    }
    .subtitle {
        font-size: 1.2rem;
        font-weight: 600;
        margin: 1.5rem 0 1rem;
        color: #2c3e50;
    }
    .form-group {
        margin-bottom: 1.2rem;
    }
    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 0.4rem;
        font-size: 0.85rem;
        color: #2c3e50;
    }
    .form-control, .form-select {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 20px;
        font-size: 0.9rem;
        background: white;
        transition: 0.2s;
    }
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #1D6E6F;
        box-shadow: 0 0 0 3px rgba(29,110,111,0.2);
    }
    .btn-primary-custom {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s;
    }
    .btn-primary-custom:hover {
        background: #0e4f50;
    }
    .btn-success-custom {
        background: #28a745;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .btn-secondary-custom {
        background: #6c757d;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .btn-danger-custom {
        background: #dc3545;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .dispute-item {
        background: #fafcff;
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 1.2rem;
        margin-bottom: 1.2rem;
    }
    .dispute-header {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        flex-wrap: wrap;
        margin-bottom: 0.8rem;
    }
    .dispute-reason {
        font-weight: 700;
        color: #c0392b;
    }
    .dispute-status {
        font-size: 0.75rem;
        padding: 0.2rem 0.8rem;
        border-radius: 30px;
        background: #e2e8f0;
        color: #2c3e50;
    }
    .dispute-status.resolved { background: #d4edda; color: #155724; }
    .dispute-status.pending { background: #fff3cd; color: #856404; }
    .dispute-status.dismissed { background: #f8d7da; color: #721c24; }
    .btn-group {
        display: flex;
        gap: 0.8rem;
        margin-top: 1rem;
        flex-wrap: wrap;
    }
    .alert {
        padding: 0.75rem 1.2rem;
        border-radius: 20px;
        margin-bottom: 1rem;
    }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-info { background: #e2e8f0; color: #1e2a3e; }
    .alert-danger { background: #f8d7da; color: #721c24; }
    hr {
        margin: 1.5rem 0;
        border: none;
        border-top: 1px solid #e2e8f0;
    }
    @media (max-width: 768px) {
        .disputes-container {
            padding: 0 1rem;
        }
        .btn-group {
            flex-direction: column;
        }
        .dispute-header {
            flex-direction: column;
            gap: 0.5rem;
        }
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Dispute Resolution</h1>
        <p>Report inappropriate comments or track disputes</p>
    </div>
</div>

<div class="disputes-container">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <?php if (($currentUser->role ?? '') === 'admin'): ?>
        <!-- قسم الأدمن: النزاعات المعلقة -->
        <div class="disputes-card">
            <h2 class="disputes-title">Pending Disputes</h2>
            <?php if (empty($disputes)): ?>
                <div class="alert alert-info">No pending disputes.</div>
            <?php else: ?>
                <?php foreach ($disputes as $d): ?>
                    <div class="dispute-item">
                        <div class="dispute-header">
                            <div><strong>Reported by:</strong> <?= htmlspecialchars($d['reporter']) ?></div>
                            <div class="dispute-status pending">Pending</div>
                        </div>
                        <p><strong>Comment:</strong> <?= nl2br(htmlspecialchars($d['content'])) ?></p>
                        <p><strong>Reason:</strong> <?= nl2br(htmlspecialchars($d['reason'])) ?></p>
                        <p><strong>Project:</strong> <a href="project.php?slug=<?= urlencode($d['slug']) ?>" style="color:#1D6E6F;"><?= htmlspecialchars($d['project_title']) ?></a></p>
                        <div class="btn-group">
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="dispute_id" value="<?= $d['id'] ?>">
                                <button type="submit" name="resolve" class="btn-success-custom">Resolve</button>
                            </form>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="dispute_id" value="<?= $d['id'] ?>">
                                <button type="submit" name="dismiss" class="btn-secondary-custom">Dismiss</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    <?php else: ?>
        <!-- قسم المستخدم العادي: تقديم نزاع جديد -->
        <div class="disputes-card">
            <h2 class="disputes-title">Report a Comment</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Select comment</label>
                    <select name="comment_id" class="form-select" required>
                        <option value="">Select comment</option>
                        <?php foreach ($comments as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= substr(htmlspecialchars($c['content']), 0, 50) ?>...</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Reason for dispute</label>
                    <textarea name="reason" class="form-control" rows="3" required></textarea>
                </div>
                <button type="submit" name="create" class="btn-primary-custom">Submit Report</button>
            </form>
        </div>

        <!-- قائمة نزاعات المستخدم -->
        <div class="disputes-card">
            <h2 class="disputes-title">My Disputes</h2>
            <?php if (empty($disputes)): ?>
                <div class="alert alert-info">No disputes filed.</div>
            <?php else: ?>
                <?php foreach ($disputes as $d): ?>
                    <div class="dispute-item">
                        <div class="dispute-header">
                            <strong>Reason:</strong> <?= htmlspecialchars($d['reason']) ?>
                            <span class="dispute-status <?= htmlspecialchars($d['status']) ?>"><?= ucfirst($d['status']) ?></span>
                        </div>
                        <p><strong>Comment:</strong> <?= nl2br(htmlspecialchars($d['content'])) ?></p>
                        <p><strong>Project:</strong> <?= htmlspecialchars($d['project_title']) ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>