<?php
$pageTitle = 'Community Engagement Analytics';
require_once __DIR__ . '/../includes/header.php';


if (!Auth::checkRole('admin')) {
    echo '<script>window.location.href = "index.php";</script>';
    exit;
}

$db = Database::getInstance();



$totalProjectVotes = $db->query("SELECT COUNT(*) FROM votes WHERE item_type='project'")->fetchColumn();

// متوسط التصويتات لكل مشروع
$avgVotes = $db->query("SELECT AVG(vote_count) FROM (SELECT COUNT(*) as vote_count FROM votes WHERE item_type='project' GROUP BY item_id) as t")->fetchColumn();

// إجمالي التعليقات
$totalComments = $db->query("SELECT COUNT(*) FROM comments")->fetchColumn();

// أكثر المشاريع تعليقاً
$topCommented = $db->query("
    SELECT p.title, COUNT(c.id) as comments 
    FROM projects p 
    LEFT JOIN comments c ON p.id = c.project_id 
    GROUP BY p.id 
    ORDER BY comments DESC 
    LIMIT 5
")->fetchAll();

// عدد المستخدمين النشطين (من لديهم تبرع أو تعليق أو تصويت)
$activeUsers = $db->query("
    SELECT COUNT(DISTINCT user_id) FROM (
        SELECT user_id FROM donations UNION
        SELECT user_id FROM comments UNION
        SELECT user_id FROM votes
    ) as active
")->fetchColumn();

// نسبة التصويتات الإيجابية على المراحل
$milestoneVotes = $db->query("
    SELECT 
        SUM(CASE WHEN vote_value = 1 THEN 1 ELSE 0 END) as approves,
        SUM(CASE WHEN vote_value = -1 THEN 1 ELSE 0 END) as rejects,
        COUNT(*) as total
    FROM votes WHERE item_type='milestone'
")->fetch();
$approvePercent = ($milestoneVotes['total'] > 0) ? round($milestoneVotes['approves'] / $milestoneVotes['total'] * 100, 1) : 0;
?>

<style>
    .analytics-container {
        max-width: 1000px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }
    .stat-card {
        background: white;
        border-radius: 24px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .stat-number {
        font-size: 2.5rem;
        font-weight: 800;
        color: #1D6E6F;
    }
    .stat-label {
        font-size: 0.8rem;
        text-transform: uppercase;
        color: #4a5568;
    }
    .top-list {
        background: white;
        border-radius: 24px;
        padding: 1.5rem;
        margin-top: 1rem;
    }
    .top-list li {
        padding: 0.5rem 0;
        border-bottom: 1px solid #e2e8f0;
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Community Engagement Analytics</h1>
        <p>Measure community participation and interaction</p>
    </div>
</div>

<div class="analytics-container">
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?= number_format($totalProjectVotes) ?></div>
            <div class="stat-label">Total Project Upvotes</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= round($avgVotes, 1) ?></div>
            <div class="stat-label">Avg Upvotes per Project</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= number_format($totalComments) ?></div>
            <div class="stat-label">Total Comments</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= number_format($activeUsers) ?></div>
            <div class="stat-label">Active Users</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $approvePercent ?>%</div>
            <div class="stat-label">Milestone Approval Rate</div>
        </div>
    </div>

    <div class="top-list">
        <h3>📝 Top 5 Most Commented Projects</h3>
        <?php if (empty($topCommented)): ?>
            <p>No comments yet.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($topCommented as $t): ?>
                    <li><strong><?= htmlspecialchars($t['title']) ?></strong> – <?= $t['comments'] ?> comments</li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>