<?php
$pageTitle = 'Organization Profile';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = Database::getInstance();
$error = '';
$success = '';

$stmt = $db->prepare("SELECT * FROM organizations WHERE user_id = ?");
$stmt->execute([$currentUser->id]);
$org = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $reg = trim($_POST['registration_number']);
    if ($org) {
        $stmt = $db->prepare("UPDATE organizations SET name = ?, registration_number = ? WHERE user_id = ?");
        $stmt->execute([$name, $reg, $currentUser->id]);
    } else {
        $stmt = $db->prepare("INSERT INTO organizations (user_id, name, registration_number) VALUES (?,?,?)");
        $stmt->execute([$currentUser->id, $name, $reg]);
    }
    $success = "Organization saved. Awaiting admin verification.";
}
?>
<style>
    .btn-secondary {
    display: inline-block;
    background-color: #1D6E6F;
    color: white;
    padding: 8px 16px;
    border-radius: 40px;
    text-decoration: none;
    font-weight: 600;
    transition: 0.2s;
}
.btn-secondary:hover {
    background-color: #1D6E6F;
}
</style>
<div class="hero" style="padding:80px 5% 30px;"><div class="hero-content"><h1>Organization Profile</h1></div></div>
        <div class="section" style="max-width:600px; margin:0 auto;">
            <?php if (!$org): ?>
            <form method="POST">
                <div class="form-group">
                    <label>Organization Name</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($org['name'] ?? '') ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Registration Number</label>
                    <input type="text" name="registration_number" class="form-control" value="<?= htmlspecialchars($org['registration_number'] ?? '') ?>">
                </div>

                <br>
                
                <button type="submit" class="btn-primary">Save</button>
            </form>
        <?php else: ?>
            <div class="alert alert-info">
                <strong>You already have an organization:</strong> <?= htmlspecialchars($org['name']) ?>
                <?php if ($org['verified']): ?>
                    <span class="badge bg-success">Verified</span>
                <?php else: ?>
                    <span class="badge bg-warning">Pending verification</span>
                <?php endif; ?>
                <br><br>
                <?php if ($org['user_id'] == $currentUser->id || $currentUser->role === 'admin'): ?>
                    <a href="manage_organization.php?id=<?= $org['id'] ?>" class="btn-secondary">Manage Members</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>