<?php
$pageTitle = 'Project Updates';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

// ✅ التأكد من وجود المستخدم الحالي وصلاحياته
if (!$currentUser || !isset($currentUser->id)) {
    $_SESSION['error'] = 'You must be logged in to access this page.';
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}

$db = Database::getInstance();
$project_id = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;

if ($project_id <= 0) {
    $_SESSION['error'] = 'Invalid project ID.';
    echo '<script>window.location.href = "dashboard.php";</script>';
    exit;
}

$projObj = new Project();
$project = $projObj->getProjectById($project_id);

if (!$project) {
    $_SESSION['error'] = 'Project not found.';
    echo '<script>window.location.href = "dashboard.php";</script>';
    
    exit;
}



if ($project->project_lead_id != $currentUser->id) {
    $_SESSION['error'] = 'You are not authorized to update this project.';
    echo '<script>window.location.href = "dashboard.php";</script>';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    if (empty($title) || empty($content)) {
        $_SESSION['error'] = 'Title and content are required.';
    } else {
        $stmt = $db->prepare("INSERT INTO project_updates (project_id, user_id, title, content) VALUES (?, ?, ?, ?)");
        $stmt->execute([$project_id, $currentUser->id, $title, $content]);
        $_SESSION['success'] = 'Update posted successfully!';
    }
    header("Location: project-updates.php?project_id=" . $project_id);
    exit;
}

$updates = $db->prepare("SELECT * FROM project_updates WHERE project_id = ? ORDER BY created_at DESC");
$updates->execute([$project_id]);
$updates = $updates->fetchAll();
?>

<style>
    
    
    .hero { padding: 80px 5% 30px; background: #1D6E6F; color: white; text-align: center; }
    .section { max-width: 800px; margin: 0 auto; padding: 1rem; }
    .form-group { margin-bottom: 1.2rem; }
    .form-group label { display: block; font-weight: 600; margin-bottom: 0.4rem; }
    .form-control { width: 100%; padding: 8px 12px; border: 1px solid #ccc; border-radius: 8px; }
    .btn-primary { background: #1D6E6F; color: white; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; }
    .alert { padding: 10px; border-radius: 8px; margin-bottom: 1rem; }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-danger { background: #f8d7da; color: #721c24; }
    .border { border: 1px solid #ddd; padding: 1rem; margin-bottom: 1rem; border-radius: 8px; }
</style>

<div class="hero">
    <h1>Updates for <?= htmlspecialchars($project->title) ?></h1>
</div>

<div class="section">
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Content</label>
            <textarea name="content" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn-primary">Post Update</button>
    </form>

    <hr>
    <h3>Previous Updates</h3>
    <?php if (empty($updates)): ?>
        <div class="alert alert-info">No updates yet. Be the first to post.</div>
    <?php else: ?>
        <?php foreach ($updates as $u): ?>
            <div class="border">
                <strong><?= htmlspecialchars($u['title']) ?></strong>
                <small><?= htmlspecialchars($u['created_at']) ?></small>
                <p><?= nl2br(htmlspecialchars($u['content'])) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>