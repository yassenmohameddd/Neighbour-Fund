<?php
$pageTitle = 'How It Works';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="hero" style="padding: 120px 5% 60px;">
    <div class="hero-content">
        <h1 style="font-size: 2rem;">How NeighborFund Works</h1>
        <p style="max-width: 700px; margin: 0 auto;">Transparent, community-driven, and fully accountable — from idea to funded reality</p>
    </div>
</div>

<div class="section">
    <div class="section-header" style="text-align: center;">
        <div class="section-tag" style="display: inline-block;">The Process</div>
        <h2 class="section-title" style="text-align: center;">Four Simple Steps</h2>
    </div>
    <div class="steps-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-top: 2rem;">
        <div class="stat-card" style="text-align: center; padding: 1.8rem;">
            <div style="background: var(--primary-light); width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 1rem; color: white; font-size: 1.8rem; font-weight: 800;">1</div>
            <h3>Submit Your Idea</h3>
            <p class="text-muted">Create a project with detailed budget and milestones. Only verified residents can submit.</p>
        </div>
        <div class="stat-card" style="text-align: center; padding: 1.8rem;">
            <div style="background: var(--primary-light); width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 1rem; color: white; font-size: 1.8rem; font-weight: 800;">2</div>
            <h3>Community Voting</h3>
            <p class="text-muted">Local residents upvote your project. After enough votes, the committee reviews it.</p>
        </div>
        <div class="stat-card" style="text-align: center; padding: 1.8rem;">
            <div style="background: var(--primary-light); width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 1rem; color: white; font-size: 1.8rem; font-weight: 800;">3</div>
            <h3>Fundraising</h3>
            <p class="text-muted">All-or-nothing campaign. Funds held in escrow until milestones are completed.</p>
        </div>
        <div class="stat-card" style="text-align: center; padding: 1.8rem;">
            <div style="background: var(--primary-light); width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 1rem; color: white; font-size: 1.8rem; font-weight: 800;">4</div>
            <h3>Execution & Accountability</h3>
            <p class="text-muted">Submit evidence for each milestone. Backers vote to release funds.</p>
        </div>
    </div>
</div>

<div class="section" style="background: var(--white); border-radius: 40px; margin: 2rem auto; padding: 3rem;">
    <div class="section-header" style="text-align: center;">
        <div class="section-tag" style="display: inline-block;">Roles</div>
        <h2 class="section-title" style="text-align: center;">Who Can Join</h2>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; margin-top: 2rem;">
        <div class="stat-card" style="text-align: center;">
            <div style="font-size: 2.5rem;">🏗️</div>
            <h3>Project Lead</h3>
            <p>Submit projects, manage milestones, and earn karma for completions.</p>
        </div>
        <div class="stat-card" style="text-align: center;">
            <div style="font-size: 2.5rem;">💰</div>
            <h3>Backer / Donor</h3>
            <p>Support projects, vote on milestones, and get rewards.</p>
        </div>
        <div class="stat-card" style="text-align: center;">
            <div style="font-size: 2.5rem;">🔍</div>
            <h3>Community Auditor</h3>
            <p>Verify site visits and review milestone evidence.</p>
        </div>
    </div>
</div>

<div class="section" style="text-align: center;">
    <a href="create-project.php" class="btn-primary">Start a Project →</a>
    <a href="projects.php" class="btn-outline" style="margin-left: 1rem;">Browse Projects →</a>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>