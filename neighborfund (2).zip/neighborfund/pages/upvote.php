<?php
ob_start(); 


require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_once __DIR__ . '/../classes/Milestone.php';



if (!$currentUser || !isset($currentUser->id)) {
    echo '<script>window.location.href = "login.php";</script>';
    ob_end_flush();
    exit;
}

$project_id = isset($_GET['project']) ? (int)$_GET['project'] : 0;
if ($project_id <= 0) {
    echo '<script>window.location.href = "projects.php";</script>';

    ob_end_flush();
    exit;
}

$db = Database::getInstance();



$stmt = $db->prepare("INSERT INTO votes (user_id, item_type, item_id, vote_value) VALUES (?, 'project', ?, 1) ON DUPLICATE KEY UPDATE vote_value = 1");
$stmt->execute([$currentUser->id, $project_id]);



if (class_exists('Karma')) {
    try {
        $karma = new Karma();
        $karma->handleEvent('upvote', $currentUser->id);
    } catch (Exception $e) {
        
    
        error_log("Karma error: " . $e->getMessage());
    }
}



$redirect = $_SERVER['HTTP_REFERER'] ?? 'projects.php';
header("Location: $redirect");
ob_end_flush();
exit;
?>