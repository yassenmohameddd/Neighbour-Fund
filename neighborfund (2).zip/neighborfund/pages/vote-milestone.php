<?php
ob_start();

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/User.php';
require_once __DIR__ . '/../classes/Milestone.php';
require_once __DIR__ . '/../classes/Project.php';
require_once __DIR__ . '/../classes/Donation.php';
require_once __DIR__ . '/../classes/Audit.php';
require_once __DIR__ . '/../includes/auth_check.php';

define('BASE_URL', '/PHPbasics/neighborfund');

if (!$currentUser || !isset($currentUser->id)) {
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}

$milestone_id = (int)($_GET['milestone'] ?? 0);
$vote = $_GET['vote'] ?? '';

if ($milestone_id <= 0 || !in_array($vote, ['approve', 'reject'])) {
    echo '<script>window.location.href = "projects.php";</script>';
    exit;
}

$db = Database::getInstance();

$checkStmt = $db->prepare("
    SELECT p.id, p.status FROM milestones m 
    JOIN projects p ON m.project_id = p.id 
    WHERE m.id = ?
");
$checkStmt->execute([$milestone_id]);
$proj = $checkStmt->fetch();
if (!$proj) {
    die('Invalid milestone');
}

$donationStmt = $db->prepare("
    SELECT COUNT(*) FROM donations 
    WHERE project_id = ? AND user_id = ? AND status IN ('escrow', 'released')
");
$donationStmt->execute([$proj['id'], $currentUser->id]);
if ($donationStmt->fetchColumn() == 0) {
    $_SESSION['error'] = 'Only backers can vote on milestones.';
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'project.php'));
    exit;
}

$vote_value = ($vote === 'approve') ? 1 : -1;
$stmt = $db->prepare("INSERT INTO votes (user_id, item_type, item_id, vote_value) VALUES (?, 'milestone', ?, ?) ON DUPLICATE KEY UPDATE vote_value = ?");
$stmt->execute([$currentUser->id, $milestone_id, $vote_value, $vote_value]);

// حساب عدد الموافقين
$approveCount = $db->prepare("SELECT COUNT(*) FROM votes WHERE item_type='milestone' AND item_id=? AND vote_value=1");
$approveCount->execute([$milestone_id]);
$approveCount = $approveCount->fetchColumn();

// إجمالي المتبرعين للمشروع
$totalBackers = $db->prepare("
    SELECT COUNT(DISTINCT user_id) FROM donations 
    WHERE project_id = ? AND status IN ('escrow', 'released')
");
$totalBackers->execute([$proj['id']]);
$totalBackers = $totalBackers->fetchColumn();

// النسبة المطلوبة من الإعدادات (default 50)
$pctStmt = $db->prepare("SELECT value FROM settings WHERE `key` = 'milestone_approval_percentage_of_backers'");
$pctStmt->execute();
$requiredPercentage = (int)($pctStmt->fetchColumn() ?: 50);

if ($totalBackers > 0 && ($approveCount / $totalBackers * 100) > $requiredPercentage) {
    $milestoneObj = new Milestone();
    $milestoneObj->approveMilestone($milestone_id);
    
    
    $token = bin2hex(random_bytes(16));
    $expires = date('Y-m-d H:i:s', strtotime('+7 days'));
    $db->prepare("INSERT INTO site_verifications (milestone_id, token, expires_at) VALUES (?, ?, ?)")
    ->execute([$milestone_id, $token, $expires]);
    $qrLink = BASE_URL . "/pages/verify_site.php?token=$token&slug=" . $proj['slug'];
    $_SESSION['qr_link'] = $qrLink; 
    $db->prepare("UPDATE donations SET status = 'released' WHERE milestone_id = ? AND status = 'escrow'")->execute([$milestone_id]);
    $currentPercentage = round(($approveCount / $totalBackers) * 100);
    $_SESSION['success'] = "✅ Milestone approved! $approveCount out of $totalBackers backers approved ($currentPercentage% > $requiredPercentage%).";
} else {
    $currentPercentage = $totalBackers > 0 ? round(($approveCount / $totalBackers) * 100) : 0;
    $_SESSION['success'] = "🗳️ Vote recorded. Current approval: $currentPercentage% of all backers. Need more than $requiredPercentage%. ($approveCount / $totalBackers)";
}

ob_end_clean();
header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'projects.php'));
exit;
?>