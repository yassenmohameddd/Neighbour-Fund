<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

if (!$currentUser || $currentUser->role !== 'auditor') {
    die("Access denied. Only community auditors can verify sites.");
}

$token = $_GET['token'] ?? '';
if (empty($token)) die("Invalid verification link.");

$db = Database::getInstance();
$stmt = $db->prepare("SELECT milestone_id, expires_at FROM site_verifications WHERE token = ? AND used = 0");
$stmt->execute([$token]);
$ver = $stmt->fetch();
if (!$ver || strtotime($ver['expires_at']) < time()) {
    die("Link expired or invalid.");
}

$db->prepare("UPDATE site_verifications SET used = 1, verified_by = ?, verified_at = NOW() WHERE token = ?")
   ->execute([$currentUser->id, $token]);

$_SESSION['success'] = "Site verification successful!";
header("Location: project.php?slug=" . ($_GET['slug'] ?? ''));
exit;