<?php
$pageTitle = 'Fiscal Year Report';
require_once __DIR__ . '/../includes/header.php';
if (!Auth::checkRole('admin')) { echo '<script>window.location.href = "index.php";</script>'; exit; }

$db = Database::getInstance();
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$availableYears = $db->query("SELECT DISTINCT YEAR(created_at) as y FROM donations WHERE status IN ('escrow','released') ORDER BY y DESC")->fetchAll(PDO::FETCH_COLUMN);

// إحصائيات السنة
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_donations,
        SUM(amount) as total_amount,
        SUM(platform_fee) as total_fees,
        COUNT(DISTINCT user_id) as unique_donors,
        COUNT(DISTINCT project_id) as projects_supported
    FROM donations 
    WHERE YEAR(created_at) = ? AND status IN ('escrow','released')
");
$stmt->execute([$year]);
$stats = $stmt->fetch();

// التبرعات الشهرية
$monthly = $db->prepare("
    SELECT MONTH(created_at) as month, SUM(amount) as total
    FROM donations
    WHERE YEAR(created_at) = ? AND status IN ('escrow','released')
    GROUP BY MONTH(created_at)
    ORDER BY month
");
$monthly->execute([$year]);
$monthlyData = $monthly->fetchAll(PDO::FETCH_KEY_PAIR);
$months = range(1,12);
$monthlyTotals = [];
foreach ($months as $m) {
    $monthlyTotals[] = $monthlyData[$m] ?? 0;
}


?>

<style>
    .report-container { max-width: 1000px; margin: 2rem auto; padding: 0 1.5rem; }
    .report-card { background: white; border-radius: 24px; padding: 1.8rem; margin-bottom: 2rem; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px,1fr)); gap: 1.5rem; margin-bottom: 1.5rem; }
    .stat-box { text-align: center; background: #f8fafc; border-radius: 20px; padding: 1rem; }
    .stat-number { font-size: 2rem; font-weight: 800; color: #1D6E6F; }
    .stat-label { font-size: 0.8rem; text-transform: uppercase; color: #4a5568; }
    .btn-csv { background: #28a745; color: white; padding: 0.5rem 1rem; border-radius: 40px; text-decoration: none; display: inline-block; margin-top: 1rem; }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Fiscal Year Report</h1>
        <p>Annual financial summary for tax and accounting purposes</p>
    </div>
</div>

<div class="report-container">
    <form method="GET" style="margin-bottom: 1rem;">
        <label>Select Year: </label>
        <select name="year" onchange="this.form.submit()">
            <?php foreach ($availableYears as $y): ?>
                <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>><?= $y ?></option>
            <?php endforeach; ?>
        </select>
    </form>

    <div class="report-card">
        <h2>Summary for <?= $year ?></h2>
        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-number">$<?= number_format($stats['total_amount'], 2) ?></div>
                <div class="stat-label">Total Donations</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">$<?= number_format($stats['total_fees'], 2) ?></div>
                <div class="stat-label">Platform Fees</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?= number_format($stats['unique_donors']) ?></div>
                <div class="stat-label">Unique Donors</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?= number_format($stats['projects_supported']) ?></div>
                <div class="stat-label">Projects Supported</div>
            </div>
        </div>

        <canvas id="monthlyChart" width="800" height="400"></canvas>
        <br>
        
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('monthlyChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']) ?>,
            datasets: [{
                label: 'Donations (USD)',
                data: <?= json_encode($monthlyTotals) ?>,
                backgroundColor: '#1D6E6F',
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: { y: { beginAtZero: true, ticks: { callback: (value) => '$' + value } } }
        }
    });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>