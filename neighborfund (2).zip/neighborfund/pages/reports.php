<?php
$pageTitle = 'Reports';
require_once '../includes/header.php';

$db = Database::getInstance();

if (!Auth::checkRole('admin')) { 
    echo '<script>window.location.href = "index.php";</script>';

    exit; 
}

$reportObj = new Report();
$yearly = [];
for ($y = 2023; $y <= date('Y'); $y++) {
    $yearly[] = $reportObj->yearlyReport($y);
}
$community = $reportObj->communityAnalytics();

// أكثر المتطوعين نشاطاً
$topVolunteers = $db->query("SELECT u.full_name, SUM(v.hours_completed) as total_hours FROM volunteers v JOIN users u ON v.user_id = u.id WHERE v.status = 'completed' GROUP BY v.user_id ORDER BY total_hours DESC LIMIT 5")->fetchAll();
// التبرعات الشهرية
$monthlyDonations = $db->query("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as total FROM donations WHERE status='completed' GROUP BY month ORDER BY month DESC LIMIT 12")->fetchAll();
?>

<style>
    .reports-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .report-card {
        background: white;
        border-radius: 24px;
        padding: 1.5rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .report-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #1e2a3e;
        border-bottom: 2px solid #e2e8f0;
        padding-bottom: 0.5rem;
    }
    .report-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 16px;
        overflow: hidden;
        margin-bottom: 1rem;
    }
    .report-table th {
        background: #f8fafc;
        padding: 12px;
        text-align: left;
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        color: #475569;
        border-bottom: 1px solid #e2e8f0;
    }
    .report-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #edf2f7;
        font-size: 0.9rem;
    }
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }
    .stat-box {
        background: #f1f5f9;
        border-radius: 20px;
        padding: 1.2rem;
        text-align: center;
    }
    .stat-number {
        font-size: 2rem;
        font-weight: 800;
        color: #1D6E6F;
    }
    .stat-label {
        font-size: 0.8rem;
        text-transform: uppercase;
        color: #475569;
    }
    .region-list {
        list-style: none;
        padding: 0;
    }
    .region-list li {
        padding: 0.5rem 0;
        border-bottom: 1px solid #e2e8f0;
    }
    .volunteer-list {
        list-style: none;
        padding: 0;
    }
    .volunteer-list li {
        padding: 0.5rem 0;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
    }
    canvas {
        max-width: 100%;
        height: auto;
        margin-top: 1rem;
    }
    @media (max-width: 768px) {
        .reports-container {
            padding: 0 1rem;
        }
        .stats-grid {
            grid-template-columns: 1fr;
        }
        .report-table thead {
            display: none;
        }
        .report-table tr {
            display: block;
            margin-bottom: 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
        }
        .report-table td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            border-bottom: none;
        }
        .report-table td:before {
            content: attr(data-label);
            font-weight: 700;
            width: 40%;
        }
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Admin Reports</h1>
        <p>Financial overview, community analytics, and top volunteers</p>
    </div>
</div>

<div class="reports-container">
    <!-- بطاقة التقارير المالية -->
    <div class="report-card">
        <h2 class="report-title">📊 Financial Reports</h2>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Year</th>
                    <th>Total Donations</th>
                    <th>Projects Created</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($yearly as $y): ?>
                    <tr>
                        <td data-label="Year"><?= $y['year'] ?></td>
                        <td data-label="Total Donations">$<?= number_format($y['total_donations'], 2) ?></td>
                        <td data-label="Projects Created"><?= $y['total_projects'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- بطاقة إحصائيات المجتمع -->
    <div class="report-card">
        <h2 class="report-title">🌍 Community Analytics</h2>
        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-number"><?= number_format($community['active_donors']) ?></div>
                <div class="stat-label">Active Donors</div>
            </div>
        </div>
        <h4>By Region</h4>
        <ul class="region-list">
            <?php foreach ($community['regions'] as $r): ?>
                <li><strong><?= htmlspecialchars($r['region']) ?></strong>: <?= $r['projects'] ?> projects, $<?= number_format($r['raised'], 0) ?> raised</li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- بطاقة المتطوعين الأكثر نشاطاً -->
    <div class="report-card">
        <h2 class="report-title">🤝 Top Volunteers</h2>
        <ul class="volunteer-list">
            <?php foreach($topVolunteers as $tv): ?>
                <li>
                    <span><?= htmlspecialchars($tv['full_name']) ?></span>
                    <span><strong><?= $tv['total_hours'] ?></strong> hours</span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- بطاقة الرسم البياني للتبرعات الشهرية -->
    <div class="report-card">
        <h2 class="report-title">📈 Monthly Donations</h2>
        <canvas id="donationChart" width="800" height="400"></canvas>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('donationChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($monthlyDonations, 'month')) ?>,
            datasets: [{
                label: 'Monthly Donations (USD)',
                data: <?= json_encode(array_column($monthlyDonations, 'total')) ?>,
                borderColor: '#1D6E6F',
                backgroundColor: 'rgba(29, 110, 111, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top' },
                tooltip: { callbacks: { label: (ctx) => `$${ctx.raw.toFixed(2)}` } }
            },
            scales: {
                y: { beginAtZero: true, ticks: { callback: (value) => '$' + value } }
            }
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>