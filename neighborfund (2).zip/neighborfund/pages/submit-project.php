<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$project_id = (int)$_GET['project_id'];
$db = Database::getInstance();
$projectObj = new Project();
$project = $projectObj->getProjectById($project_id);

// التحقق من وجود المشروع وأن المستخدم هو قائد المشروع
if (!$project || $project->project_lead_id != $currentUser->id) {
    $_SESSION['error'] = "Project not found or you are not the lead.";
    header("Location: dashboard.php");
    exit;
}



if ($project->status != 'draft') {
    $revision = new Revision();
    $currentData = [
        'title'       => $project->title,
        'description' => $project->description,
        'funding_goal'=> $project->funding_goal,
        'deadline'    => $project->deadline,
        'category'    => $project->category
    ];
    $revision->saveVersion($project_id, $currentData);
    
    $_SESSION['success'] = "A revision has been saved. You can now edit and resubmit.";
    
    
    header("Location: milestones.php?project=" . $project_id);
    exit;
}



$milestones = $db->prepare("SELECT SUM(allocated_amount) as total FROM milestones WHERE project_id = ?");
$milestones->execute([$project_id]);
$totalMilestones = (float)$milestones->fetch()['total'];
$fundingGoal = (float)$project->funding_goal;

if (abs($totalMilestones - $fundingGoal) > 0.01) {
    $_SESSION['error'] = "Sum of milestone amounts ($totalMilestones) must equal funding goal ($fundingGoal).";
    header("Location: milestones.php?project=" . $project_id);
    exit;
}



$db->prepare("UPDATE projects SET status = 'pending', submitted_at = NOW() WHERE id = ?")->execute([$project_id]);
$_SESSION['success'] = "Project submitted for admin approval.";
header("Location: dashboard.php");
exit;
?>