<?php
$pageTitle = 'Manage Milestones';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

if (!$currentUser || !isset($currentUser->id)) {
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}

$db = Database::getInstance();
$project_id = isset($_GET['project']) ? (int)$_GET['project'] : 0;
$projObj = new Project();
$project = $projObj->getProjectById($project_id);

if (!$project || $project->project_lead_id != $currentUser->id) {
    echo '<div class="alert alert-danger">Unauthorized or project not found.</div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$milestoneObj = new Milestone();
$donationObj = new Donation();

// جلب عدد الأصوات المطلوب من الإعدادات

$settingStmt = $db->prepare("SELECT value FROM settings WHERE `key` = ?");
$settingStmt->execute(['milestone_vote_threshold']);
$threshold = (int)($settingStmt->fetchColumn() ?: 3);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $data = ['title' => $_POST['title'], 'description' => $_POST['description'], 'amount' => $_POST['amount'], 'order' => $_POST['order']];
        $milestoneObj->addMilestone($project_id, $data);
        header("Location: milestones.php?project=$project_id");
        exit;
    } 
    elseif (isset($_POST['submit_evidence'])) {
    $milestone_id = (int)$_POST['milestone_id'];
    $evidence_desc = trim($_POST['evidence_desc'] ?? '');
    
    // معالجة رفع الملف
        if (isset($_FILES['evidence']) && $_FILES['evidence']['error'] === UPLOAD_ERR_OK) {
            $targetDir = __DIR__ . '/../uploads/evidence/';
            if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
            $fileName = time() . '_' . basename($_FILES['evidence']['name']);
            $targetFile = $targetDir . $fileName;
            if (move_uploaded_file($_FILES['evidence']['tmp_name'], $targetFile)) {
                $milestoneObj->submitEvidence($milestone_id, $fileName, $evidence_desc);
                $_SESSION['success'] = "Evidence submitted. Waiting for backers' votes.";
            } else {
                $_SESSION['error'] = "Failed to upload file.";
            }
        } else {
            $_SESSION['error'] = "Please select a valid file.";
        }
        header("Location: milestones.php?project=$project_id");
        exit;
    }
    elseif (isset($_POST['vote_approve'])) {
        $mid = (int)$_POST['milestone_id'];
        // تسجيل التصويت
        $stmt = $db->prepare("INSERT INTO votes (user_id, item_type, item_id, vote_value) VALUES (?, 'milestone', ?, 1) ON DUPLICATE KEY UPDATE vote_value = 1");
        $stmt->execute([$currentUser->id, $mid]);
        
        // حساب عدد الأصوات الإيجابية باستخدام الـ threshold من الإعدادات
        $voteCountStmt = $db->prepare("SELECT COUNT(*) as cnt FROM votes WHERE item_type='milestone' AND item_id=? AND vote_value=1");
        $voteCountStmt->execute([$mid]);
        $voteCount = $voteCountStmt->fetch()['cnt'];
        
        if ($voteCount >= $threshold) {
            $milestoneObj->approveMilestone($mid);
            $db->prepare("UPDATE donations SET status = 'released' WHERE milestone_id = ?")->execute([$mid]);
        }
        header("Location: milestones.php?project=$project_id");
        exit;
    }
    header("Location: milestones.php?project=$project_id");
    exit;
}

$milestones = $milestoneObj->getMilestones($project_id);
?>


<style>
    /* ========== تنسيقات الصفحة الأساسية ========== */
    .milestone-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .milestone-card {
        background: white;
        border-radius: 24px;
        padding: 1.8rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .milestone-title {
        font-size: 1.6rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #1e2a3e;
    }
    .milestone-subtitle {
        font-size: 1.2rem;
        font-weight: 600;
        margin: 1.5rem 0 1rem;
        color: #2c3e50;
    }
    /* ========== تنسيق الفورم ========== */
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        align-items: end;
    }
    .form-group {
        display: flex;
        flex-direction: column;
    }
    .form-group label {
        font-weight: 600;
        margin-bottom: 0.4rem;
        font-size: 0.85rem;
        color: #2c3e50;
    }
    .form-control, .form-select {
        padding: 10px 12px;
        border: 1px solid #ccc;
        border-radius: 16px;
        font-size: 0.9rem;
        width: 100%;
        background: white;
        transition: 0.2s;
    }
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #1D6E6F;
        box-shadow: 0 0 0 3px rgba(29,110,111,0.2);
    }
    /* ========== تنسيق الميليستونات ========== */
    .milestone-item {
        background: #fafcff;
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 1.2rem;
        margin-bottom: 1.2rem;
        transition: 0.2s;
    }
    .milestone-item:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .milestone-header {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        align-items: baseline;
        margin-bottom: 0.8rem;
    }
    .milestone-header h5 {
        font-size: 1.2rem;
        font-weight: 700;
        margin: 0;
        color: #1e2a3e;
    }
    .milestone-status {
        display: inline-block;
        padding: 0.2rem 0.8rem;
        border-radius: 30px;
        font-size: 0.7rem;
        font-weight: 600;
        background: #e2e8f0;
        color: #1e2a3e;
    }
    .milestone-status.pending { background: #fff3cd; color: #856404; }
    .milestone-status.submitted { background: #cce5ff; color: #004085; }
    .milestone-status.approved { background: #d4edda; color: #155724; }
    .milestone-status.rejected { background: #f8d7da; color: #721c24; }
    .milestone-status.in_progress { background: #d1ecf1; color: #0c5460; }
    .milestone-amount {
        font-weight: 600;
        margin: 0.5rem 0;
        color: #4a5568;
    }
    /* ========== الأزرار ========== */
    .btn-primary-custom {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        transition: 0.2s;
        display: inline-block;
        text-decoration: none;
    }
    .btn-primary-custom:hover {
        background: #0e4f50;
    }
    .btn-outline-custom {
        background: transparent;
        border: 1px solid #1D6E6F;
        color: #1D6E6F;
        padding: 8px 16px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        display: inline-block;
        text-decoration: none;
        transition: 0.2s;
    }
    .btn-outline-custom:hover {
        background: rgba(29,110,111,0.1);
    }
    .btn-success-custom {
        background: #28a745;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .btn-danger-custom {
        background: #dc3545;
        color: white;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .btn-warning-custom {
        background: #ffc107;
        color: #212529;
        border: none;
        padding: 6px 14px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
    }
    .btn-group {
        display: flex;
        gap: 0.8rem;
        flex-wrap: wrap;
        margin-top: 1rem;
    }
    /* ========== تنسيق الأدلة ========== */
    .evidence-form {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid #e2e8f0;
        display: grid;
        grid-template-columns: 1fr 1fr auto;
        gap: 0.8rem;
        align-items: center;
    }
    .evidence-form input[type="file"] {
        border: 1px solid #ccc;
        border-radius: 30px;
        padding: 6px 12px;
    }
    /* ========== تنبيهات ========== */
    .alert {
        padding: 0.75rem 1.2rem;
        border-radius: 20px;
        margin-bottom: 1rem;
    }
    .alert-danger { background: #f8d7da; color: #721c24; }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-info { background: #e2e8f0; color: #1e2a3e; }
    /* ========== استجابة للشاشات الصغيرة ========== */
    @media (max-width: 768px) {
        .milestone-container {
            padding: 0 1rem;
        }
        .form-grid {
            grid-template-columns: 1fr;
        }
        .evidence-form {
            grid-template-columns: 1fr;
        }
        .btn-group {
            flex-direction: column;
        }
        .milestone-header {
            flex-direction: column;
            gap: 0.5rem;
        }
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">Manage Milestones</h1>
        <p><?= htmlspecialchars($project->title) ?></p>
    </div>
</div>

<div class="milestone-container">
    <!-- عرض زر تقديم المشروع إذا كان في حالة draft -->
    <?php if ($project->status == 'draft'): ?>
        <div class="alert alert-info" style="margin-bottom: 1.5rem;">
            <strong>Project is in draft.</strong> After adding milestones, submit for review.
        </div>
        <div style="text-align: center; margin-bottom: 2rem;">
            <a href="submit-project.php?project_id=<?= $project_id ?>" class="btn-primary-custom" style="background: #28a745;">✅ Submit Project for Approval</a>
        </div>
    <?php endif; ?>

    <!-- إضافة ميليستون جديد -->
    <div class="milestone-card">
        <h2 class="milestone-title">➕ Add New Milestone</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-grid">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" name="description" class="form-control" placeholder="Optional">
                </div>
                <div class="form-group">
                    <label>Amount ($)</label>
                    <input type="number" name="amount" step="0.01" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Order</label>
                    <input type="number" name="order" class="form-control" required>
                </div>
                <div>
                    <button type="submit" name="add" class="btn-primary-custom">Add Milestone</button>
                </div>
            </div>
        </form>
    </div>

    <!-- قائمة الميليستونات الموجودة -->
    <div class="milestone-card">
        <h2 class="milestone-title">📋 Existing Milestones</h2>
        <?php if (empty($milestones)): ?>
            <div class="alert alert-info">No milestones added yet. Add your first milestone above.</div>
        <?php else: ?>
            <?php foreach ($milestones as $m): ?>
    <div class="milestone-item">
        <div class="milestone-header">
            <h5><?= htmlspecialchars($m['title']) ?> (Order <?= (int)$m['sequence_order'] ?>)</h5>
            <span class="milestone-status <?= htmlspecialchars($m['status']) ?>"><?= ucfirst(htmlspecialchars($m['status'])) ?></span>
        </div>
        <p><?= nl2br(htmlspecialchars($m['description'])) ?></p>
        <div class="milestone-amount"><strong>Allocated:</strong> $<?= number_format($m['allocated_amount'], 2) ?></div>

        <!-- عرض رابط الدليل إذا موجود -->
        <?php if (!empty($m['evidence'])): ?>
            <div style="margin-top: 8px;">
                <a href="../uploads/evidence/<?= urlencode($m['evidence']) ?>" target="_blank" class="btn-sm" style="background:#6c757d; color:white; padding:4px 12px; border-radius:30px; text-decoration:none; font-size:0.7rem;">📎 View Evidence</a>
            </div>
        <?php endif; ?>

        <!-- زر حذف الميليستون (يظهر فقط في حالة draft) -->
        <?php if ($project->status == 'draft'): ?>
            <div style="margin-top: 8px;">
                <a href="delete-milestone.php?id=<?= $m['id'] ?>&project=<?= $project_id ?>" class="btn-danger-custom" style="background:#dc3545; color:white; padding:4px 12px; border-radius:30px; text-decoration:none; font-size:0.7rem;" onclick="return confirm('Delete this milestone?')">🗑️ Delete</a>
            </div>
        <?php endif; ?>

        <!-- باقي الكود (رفع الأدلة والتصويت) يبقى كما هو -->
        <?php if ($m['status'] == 'in_progress'): ?>
            <form method="POST" enctype="multipart/form-data" class="evidence-form">
                <input type="hidden" name="milestone_id" value="<?= $m['id'] ?>">
                <input type="file" name="evidence" class="form-control" required>
                <input type="text" name="evidence_desc" class="form-control" placeholder="Evidence description">
                <button type="submit" name="submit_evidence" class="btn-warning-custom">📎 Submit Evidence</button>
            </form>
        
            <?php elseif ($m['status'] == 'submitted'): ?>
                <?php
                // التحقق من أن المستخدم داعم (يمكنك إعادة استخدام نفس منطق التحقق)
                $donorCheck = $db->prepare("SELECT COUNT(*) FROM donations WHERE user_id = ? AND project_id = ? AND status IN ('escrow', 'released')");
                $donorCheck->execute([$currentUser->id, $project->id]);
                $isBacker = $donorCheck->fetchColumn() > 0;
                if ($isBacker && $currentUser->id != $project->project_lead_id): ?>
                    <div class="btn-group">
                        <a href="vote-milestone.php?milestone=<?= $m['id'] ?>&vote=approve" class="btn-success-custom">👍 Approve</a>
                        <a href="vote-milestone.php?milestone=<?= $m['id'] ?>&vote=reject" class="btn-danger-custom">👎 Reject</a>
                    </div>
                <?php elseif ($currentUser->id == $project->project_lead_id): ?>
                    <div class="alert alert-info">You cannot vote on your own project's milestones.</div>
                <?php else: ?>
                    <div class="alert alert-info">Only backers can vote on this milestone.</div>
                <?php endif; ?>

        <?php endif; ?>
    </div>
<?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>