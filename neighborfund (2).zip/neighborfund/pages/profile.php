<?php
$pageTitle = 'My Profile';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = Database::getInstance();
$error = '';
$success = '';



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $region = trim($_POST['region'] ?? '');

    if (empty($full_name)) {
        $error = 'Full name is required.';
    } else {
        try {
            $stmt = $db->prepare("UPDATE users SET full_name = ?, phone = ?, address = ?, region = ? WHERE id = ?");
            $stmt->execute([$full_name, $phone, $address, $region, $currentUser->id]);
            $success = 'Profile updated successfully!';
            
            
            $currentUser->full_name = $full_name;
            $currentUser->phone = $phone;
            $currentUser->address = $address;
            $currentUser->region = $region;
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

if (!empty($_POST['new_password'])) {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$currentUser->id]);
    $hash = $stmt->fetchColumn();
    if (!password_verify($current, $hash)) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $newHash = password_hash($new, PASSWORD_BCRYPT);
        $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([$newHash, $currentUser->id]);
        $success = 'Password updated successfully.';
    }
}



$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$currentUser->id]);
$user = $stmt->fetch();
?>

<style>
    .profile-container {
        max-width: 700px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }
    .profile-card {
        background: white;
        border-radius: 28px;
        padding: 2rem;
        box-shadow: 0 8px 24px rgba(0,0,0,0.05);
    }
    .profile-title {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 0.25rem;
        color: #1e2a3e;
    }
    .profile-subtitle {
        color: #4a5568;
        margin-bottom: 1.8rem;
        font-size: 0.9rem;
        border-bottom: 1px solid #e2e8f0;
        padding-bottom: 0.75rem;
    }
    .form-group {
        margin-bottom: 1.2rem;
    }
    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 0.4rem;
        color: #2c3e50;
        font-size: 0.85rem;
    }
    .form-control {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 20px;
        font-size: 0.9rem;
        transition: 0.2s;
    }
    .form-control:focus {
        outline: none;
        border-color: #1D6E6F;
        box-shadow: 0 0 0 3px rgba(29,110,111,0.2);
    }
    .btn-save {
        background: #1D6E6F;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s;
        width: 100%;
    }
    .btn-save:hover {
        background: #0e4f50;
    }
    .alert {
        padding: 0.75rem 1.2rem;
        border-radius: 20px;
        margin-bottom: 1.2rem;
    }
    .alert-success {
        background: #d4edda;
        color: #155724;
    }
    .alert-danger {
        background: #f8d7da;
        color: #721c24;
    }
    hr {
        margin: 1.5rem 0;
        border: none;
        border-top: 1px solid #e2e8f0;
    }
    .info-text {
        font-size: 0.8rem;
        color: #6c757d;
        margin-top: 1rem;
        text-align: center;
    }
</style>

<div class="hero" style="padding: 80px 5% 30px;">
    <div class="hero-content" style="text-align: left;">
        <h1 style="font-size: 2rem;">My Profile</h1>
        <p>Update your personal information</p>
    </div>
</div>

<div class="profile-container">
    <div class="profile-card">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($user['full_name']) ?>" required>
            </div>
            <div class="form-group">
                <label>Email (cannot be changed)</label>
                <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled>
            </div>
            <hr>
            <h4>Change Password</h4>
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" name="current_password" class="form-control">
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" class="form-control">
            </div>
            <div class="form-group">
                <label>Confirm New Password</label>
                <input type="password" name="confirm_password" class="form-control">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>Region / Municipality</label>
                <input type="text" name="region" class="form-control" value="<?= htmlspecialchars($user['region'] ?? '') ?>" placeholder="e.g., Cairo, Alexandria">
            </div>
            <button type="submit" class="btn-save">Save Changes</button>
        </form>
        <hr>
        <div class="info-text">
            <i class="fas fa-shield-alt"></i> Your data is secure and will not be shared.
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>