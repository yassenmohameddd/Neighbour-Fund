<?php
$pageTitle = 'Donate';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = Database::getInstance();

// دعم كلاً من project و project_id
$project_id = (int)($_GET['project_id'] ?? $_GET['project'] ?? 0);
if ($project_id <= 0) {
    echo '<div class="alert alert-danger">Invalid project ID.</div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$projectObj = new Project();
$project = $projectObj->getProjectById($project_id);

if (!$project) {
    echo '<div class="alert alert-danger">Project not found.</div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}
$displayGoal = $project->stretch_goal ?: $project->funding_goal;

// =====================
// تحديد الـ display goal
// =====================
$displayGoal = (!empty($project->stretch_goal) && $project->current_amount >= $project->funding_goal)
    ? $project->stretch_goal
    : $project->funding_goal;


// =====================
// تحديث الحالة لو اتفولت فعلاً
// =====================
if (!empty($project->stretch_goal) && $project->current_amount >= $project->stretch_goal) {

    $project->status = 'funded';

    $db->prepare("UPDATE projects SET status = 'funded' WHERE id = ?")
       ->execute([$project_id]);
}


// =====================
// السماح بالدونيشن
// (مهم: ما تقفلش stretch هنا)
// =====================
// السماح بالدونيشن طالما المشروع مش مقفول فعليًا
if ($project->status === 'funded') {
    echo '<div class="alert alert-danger">
            This project is fully funded and closed.
          </div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (float)($_POST['amount'] ?? 0);
    $is_anonymous = isset($_POST['is_anonymous']) ? 1 : 0;
    $reward_id = !empty($_POST['reward_id']) ? (int)$_POST['reward_id'] : null;
    $min_pledge = $project->min_pledge ?? 5;
    $max_pledge = $project->max_pledge ?? 10000;

    if ($amount < $min_pledge || $amount > $max_pledge) {
        $error = "Amount must be between $min_pledge and $max_pledge.";
    } else {
        try {
            
            $platform_fee = $amount * 0.03; // 3% رسوم منصة
            $stmt = $db->prepare("INSERT INTO donations (user_id, project_id, amount, platform_fee, is_anonymous, reward_id, status) VALUES (?, ?, ?, ?, ?, ?, 'escrow')");
            $stmt->execute([$currentUser->id, $project_id, $amount, $platform_fee, $is_anonymous, $reward_id]);

            // 2. تحديث رصيد المشروع والمستخدم
            $db->prepare("UPDATE projects SET current_amount = current_amount + ? WHERE id = ?")->execute([$amount, $project_id]);


$project = $projectObj->getProjectById($project_id);

$goalReached = false;

// لو فيه stretch
if (!empty($project->stretch_goal)) {
    $goalReached = $project->current_amount >= $project->stretch_goal;
} else {
    $goalReached = $project->current_amount >= $project->funding_goal;
}

if ($goalReached) {
    $db->prepare("UPDATE projects SET status = 'funded' WHERE id = ?")
       ->execute([$project_id]);
}


            $project = $projectObj->getProjectById($project_id);
            $project->checkFundingDeadline();
            $project = $projectObj->getProjectById($project_id);
            $db->prepare("UPDATE users SET total_donated = total_donated + ? WHERE id = ?")->execute([$amount, $currentUser->id]);
            $db->prepare("UPDATE users SET karma_score = karma_score + ? WHERE id = ?")->execute([floor($amount / 10), $currentUser->id]);

            // 3. تحديث عدد المستحقين للمكافأة
            if ($reward_id) {
                $db->prepare("UPDATE rewards SET claimed_count = claimed_count + 1 WHERE id = ?")->execute([$reward_id]);
            }

            $success = "Thank you for your donation!";

            // 4. التحقق من الوصول للهدف
            $checkStmt = $db->prepare("SELECT current_amount, funding_goal, status, project_lead_id FROM projects WHERE id = ?");
            $checkStmt->execute([$project_id]);
            $projData = $checkStmt->fetch();

          
        } catch (Exception $e) {
            $error = "Donation failed: " . $e->getMessage();
        }
    }
}

// جلب المكافآت والمرحلة النشطة
$rewards = [];
$stmt = $db->prepare("SELECT * FROM rewards WHERE project_id = ? ORDER BY min_donation ASC");
$stmt->execute([$project_id]);
$rewards = $stmt->fetchAll();

$activeMilestone = $project->getActiveMilestone();
$remainingForMilestone = $activeMilestone ? $project->getRemainingForCurrentMilestone() : 0;
?>
<?php
$displayGoal = $project->stretch_goal ?: $project->funding_goal;
?>

<div class="hero" style="padding:80px 5% 30px;">
    <div class="hero-content">
        <h1>Donate to <?= htmlspecialchars($project->title) ?></h1>
    </div>
</div>

<div class="section" style="max-width:600px; margin:0 auto;">

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- 🟢 Stretch Active -->
    <?php if (!empty($project->stretch_goal) && $project->current_amount >= $project->funding_goal && $project->current_amount < $project->stretch_goal): ?>
        <div class="alert alert-warning mb-4">
            🎯 <strong>Stretch Goal Active!</strong><br>
            New target: <strong>$<?= number_format($project->stretch_goal, 2) ?></strong><br>
            Remaining: <strong>$<?= number_format($project->stretch_goal - $project->current_amount, 2) ?></strong>
        </div>
    <?php endif; ?>

    <!-- 🔵 Fundraising Phase -->
    <?php if ($project->current_amount < $project->funding_goal): ?>
        <div class="alert alert-primary mb-4">
            <h5><i class="fas fa-boxes"></i> Fundraising Phase</h5>
            <p>
                This project needs 
                <strong>$<?= number_format($project->funding_goal - $project->current_amount, 2) ?></strong> 
                more to reach its base goal of 
                <strong>$<?= number_format($project->funding_goal, 2) ?></strong>.
            </p>
        </div>

    <!-- 🟣 Stretch Phase -->
    <?php elseif (!empty($project->stretch_goal) && $project->current_amount < $project->stretch_goal): ?>
        <div class="alert alert-warning mb-4">
            <h5>🚀 Stretch Phase</h5>
            <p>
                The main goal has been reached! 🎉<br>
                Now aiming for the stretch goal of 
                <strong>$<?= number_format($project->stretch_goal, 2) ?></strong>.
            </p>
        </div>

    <!-- 🟡 Milestone Phase -->
   <?php elseif ($project->status !== 'live' && $activeMilestone): ?>
        <div class="alert alert-info mb-4">
            <h5><i class="fas fa-flag-checkered"></i> Current Milestone: <?= htmlspecialchars($activeMilestone['title']) ?></h5>
            <p>
                Amount needed: 
                <strong>$<?= number_format($remainingForMilestone, 2) ?></strong>
            </p>
        </div>
    <?php endif; ?>

  <!-- 💰 Donate Form -->
<form method="POST">

    <?php
        $min = $project->min_pledge ?? 5;
        $max = $project->max_pledge ?? 10000;
    ?>

    <div class="form-group">
        <label>Amount ($)</label>

        <input 
            type="number"
            name="amount"
            class="form-control"
            min="<?= $min ?>"
            max="<?= $max ?>"
            step="1"
            required
            placeholder="Enter amount between <?= $min ?> - <?= $max ?>"
        >

        <small style="color:#666;">
            Minimum: $<?= $min ?> — Maximum: $<?= number_format($max) ?>
        </small>
    </div>

    <div class="form-group" style="margin-top:10px;">
        <label style="display:flex; gap:8px; align-items:center;">
            <input type="checkbox" name="is_anonymous">
            <span>Donate anonymously</span>
        </label>
    </div>

    <?php if (!empty($rewards)): ?>
        <div class="form-group" style="margin-top:15px;">
            <label>Select a reward</label>

            <select name="reward_id" class="form-select">
                <option value="">No reward</option>

                <?php foreach ($rewards as $r): ?>
                    <option value="<?= (int)$r['id'] ?>">
                        <?= htmlspecialchars($r['tier_name']) ?>
                        — min $<?= number_format($r['min_donation'], 2) ?>
                    </option>
                <?php endforeach; ?>

            </select>

            <small style="color:#666;">
                Choose a reward based on your donation amount
            </small>
        </div>
    <?php endif; ?>

    <div style="margin-top:20px;">
        <button type="submit" class="btn-primary" style="width:100%;">
            Donate Now
        </button>

        <a 
            href="project.php?slug=<?= urlencode($project->slug) ?>" 
            class="btn-secondary"
            style="display:block; text-align:center; margin-top:10px;"
        >
            Cancel
        </a>
    </div>

</form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>