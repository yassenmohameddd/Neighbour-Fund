<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth_check.php';

$id = (int)$_GET['id'];
$project_id = (int)$_GET['project'];

// تأكد من أن المستخدم هو قائد المشروع وأن المشروع في حالة draft
$db = Database::getInstance();
$check = $db->prepare("SELECT project_id FROM milestones WHERE id = ?");
$check->execute([$id]);
$milestone = $check->fetch();
if ($milestone) {
    $proj = $db->prepare("SELECT project_lead_id, status FROM projects WHERE id = ?");
    $proj->execute([$milestone['project_id']]);
    $project = $proj->fetch();
    if ($project && $project['project_lead_id'] == $currentUser->id && $project['status'] == 'draft') {
        $db->prepare("DELETE FROM milestones WHERE id = ?")->execute([$id]);
        $_SESSION['success'] = "Milestone deleted.";
    } else {
        $_SESSION['error'] = "Not authorized.";
    }
}
header("Location: milestones.php?project=" . $project_id);
exit;
?>