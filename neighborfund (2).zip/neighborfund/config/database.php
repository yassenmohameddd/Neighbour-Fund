<?php
class Database {
    private static ?PDO $instance = null;
    private const HOST = 'localhost';
    private const DB_NAME = 'neighborfund';
    private const USER = 'root';
    private const PASS = 'root';
    private const CHARSET = 'utf8mb4';

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            try {
                $dsn = "mysql:host=" . self::HOST . ";dbname=" . self::DB_NAME . ";charset=" . self::CHARSET;
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,//لو حصل خطأ في Queryحوّله إلى Exception
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,//بيانات تيجي arr
                    // PDO::ATTR_EMULATE_PREPARES => false,//
                ];
                self::$instance = new PDO($dsn, self::USER, self::PASS, $options);//PDO($dsn, $username, $password);
            } catch (PDOException $e) {
                die("Database connection failed: " . $e->getMessage());//توقف تنفيذ البرنامج , تطلع رساله
            }
        }
        return self::$instance;
    }
}
?>