<?php
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentUser = $currentUser ?? null;
?>
<nav class="navbar-glass">
    <div class="navbar-container">
        <a href="<?= BASE_URL ?>/pages/index.php" class="logo">Neighbor<span>Fund</span></a>
        <button class="navbar-toggler" id="navToggler"><span></span><span></span><span></span></button>
        <div class="nav-links" id="navLinks">
            <a href="<?= BASE_URL ?>/pages/index.php" class="<?= $currentPage == 'index' ? 'active' : '' ?>">Home</a>
            <a href="<?= BASE_URL ?>/pages/projects.php" class="<?= $currentPage == 'projects' ? 'active' : '' ?>">Projects</a>
            <a href="<?= BASE_URL ?>/pages/how-it-works.php" class="<?= $currentPage == 'how-it-works' ? 'active' : '' ?>">How It Works</a>

            <?php if ($currentUser): ?>
                
                <div class="dropdown">
                    <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown" role="button">My Stuff ▼</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/create-project.php">Create Project</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/volunteers.php">Volunteer</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/disputes.php">My Disputes</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/organization.php">Organization</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/community_analytics.php">community analytics</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/fiscal_report.php">Fiscal Report</a></li>
                    </ul>
                </div>

                <a href="<?= BASE_URL ?>/pages/dashboard.php" class="<?= $currentPage == 'dashboard' ? 'active' : '' ?>">Dashboard</a>

                <a href="<?= BASE_URL ?>/pages/impact.php" class="nav-link">Global Impact</a>

                <?php if ($currentUser->role == 'admin'): ?>
                    <a href="<?= BASE_URL ?>/pages/admin.php" class="<?= $currentPage == 'admin' ? 'active' : '' ?>">Admin Panel</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="nav-buttons">
            <?php if ($currentUser): ?>
                <div class="dropdown">
                    <i class="fas fa-bell" style="font-size:1.2rem;cursor:pointer" data-bs-toggle="dropdown"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="badge-notif"><?= $unreadCount ?></span>
                    <?php endif; ?>
                    <ul class="dropdown-menu">
                        <?php $notifs = $currentUser->getUnreadNotifications();
                        if (empty($notifs)) echo '<li><span class="dropdown-item">No notifications</span></li>';
                        else foreach (array_slice($notifs, 0, 5) as $n): ?>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/project.php?slug=<?= urlencode($n['related_project_id']) ?>"><?= htmlspecialchars($n['title']) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="dropdown">
                    <button class="btn-outline-nav dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i> 
                        <?php 
                        $fullName = htmlspecialchars($currentUser->full_name);
                        if (mb_strlen($fullName) > 20) {
                            $fullName = mb_substr($fullName, 0, 18) . '…';
                        }
                        echo $fullName;
                        ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/profile.php">Profile</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/pages/dashboard.php">Dashboard</a></li>
                        <li><hr class="dropdown-divider"></li>  
                        <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/pages/logout.php">Logout</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="<?= BASE_URL ?>/pages/login.php" class="btn-outline-nav">Login</a>
                <a href="<?= BASE_URL ?>/pages/register.php" class="btn-solid-nav">Join</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<script>
    document.getElementById('navToggler')?.addEventListener('click', () => {
        document.getElementById('navLinks').classList.toggle('show');
    });
</script>