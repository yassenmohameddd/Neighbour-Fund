<?php
session_start();

if (!defined('BASE_URL')) {
    define('BASE_URL', '/neighborfund');
}
if (!defined('BASE_PATH')) {
    define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'] . BASE_URL);
}

require_once BASE_PATH . '/config/database.php';



$classes = [
    'Database',
    'Model', 'User', 'Auth', 'Project', 'Donation', 'Milestone', 'Audit',
    'Notification', 'CorporateSponsor', 'ChampionPledge', 'Volunteer', 'Newsletter',
    'DatabaseIntegrity', 'ProjectShadow', 'FinancialReport', 'PaymentBridge',
    'BlockchainReputation', 'Evidence', 'Organization', 'Comment',
    'Karma', 'Reward', 'Dispute', 'Revision', 'Update', 'Vote',
    'Report'   
];
foreach ($classes as $class) {
    $file = BASE_PATH . "/classes/{$class}.php";
    if (file_exists($file)) require_once $file;
}



if (!class_exists('Database')) {
    $dbFile = BASE_PATH . '/classes/Database.php';
    if (file_exists($dbFile)) require_once $dbFile;
}


if (!isset($_SESSION['last_cron']) || time() - $_SESSION['last_cron'] > 86400) {
    if (file_exists(__DIR__ . '/../cron/check_projects.php')) {
        include_once __DIR__ . '/../cron/check_projects.php';
    }
    $_SESSION['last_cron'] = time();
}


$currentUser = Auth::user();
$unreadCount = $currentUser ? Notification::unreadCount($currentUser->id) : 0;
$pageTitle = $pageTitle ?? 'NeighborFund';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <!-- تم إزالة Bootstrap JS من هنا (سيبقى فقط في footer.php) -->
</head>
<body>
<?php include __DIR__ . '/navbar.php'; ?>
<main>