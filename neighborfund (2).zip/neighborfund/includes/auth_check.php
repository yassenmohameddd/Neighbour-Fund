<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/User.php';

$currentUser = Auth::user();
if (!$currentUser && !in_array(basename($_SERVER['PHP_SELF']), ['login.php', 'register.php'])) {
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}