</main>
<footer class="footer">
    <div class="footer-container">
        <div class="footer-col"><h4>NeighborFund</h4><p>Empowering neighborhoods.</p></div>
        <div class="footer-col"><h4>Explore</h4><a href="<?= BASE_URL ?>/pages/projects.php">Projects</a><a href="<?= BASE_URL ?>/pages/create-project.php">Start a Project</a></div>
        <div class="footer-col"><h4>Legal</h4><a href="#">Terms</a><a href="#">Privacy</a></div>
    </div>
    <div class="footer-bottom">&copy; <?= date('Y') ?> NeighborFund</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>