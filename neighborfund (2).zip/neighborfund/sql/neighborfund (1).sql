-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 02, 2026 at 12:08 PM
-- Server version: 5.7.24
-- PHP Version: 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `neighborfund`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `old_values`, `new_values`, `ip_address`, `created_at`) VALUES
(1, 9, 'project_approved', 'project', 5, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-26 18:34:06'),
(2, 9, 'project_live', 'project', 5, '{\"status\": \"approved\"}', '{\"status\": \"live\"}', '::1', '2026-04-26 20:18:10'),
(3, 9, 'project_approved', 'project', 4, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-26 20:36:28'),
(4, 9, 'sustainability_assessed', 'project', 4, '[]', '{\"notes\": \"\", \"score\": 3}', '::1', '2026-04-26 20:39:03'),
(5, 9, 'project_live', 'project', 4, '{\"status\": \"approved\"}', '{\"status\": \"live\"}', '::1', '2026-04-27 14:48:57'),
(6, 9, 'organization_verified', 'organization', 1, '{\"verified\": 0}', '{\"verified\": 1}', '::1', '2026-04-27 15:32:47'),
(7, 9, 'project_approved', 'project', 6, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-27 19:56:01'),
(8, 9, 'project_approved', 'project', 7, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-27 20:02:13'),
(9, 9, 'project_forced_live', 'project', 7, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-27 20:02:20'),
(10, 9, 'project_forced_live', 'project', 6, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-27 20:18:59'),
(11, 9, 'project_approved', 'project', 8, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-27 23:12:01'),
(12, 9, 'project_forced_live', 'project', 8, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-27 23:12:08'),
(13, 9, 'project_approved', 'project', 9, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-27 23:42:09'),
(14, 9, 'project_forced_live', 'project', 9, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-27 23:42:12'),
(15, 9, 'project_approved', 'project', 10, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-27 23:58:52'),
(16, 9, 'project_forced_live', 'project', 10, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-27 23:58:55'),
(17, 9, 'project_approved', 'project', 11, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-28 00:03:45'),
(18, 9, 'project_forced_live', 'project', 11, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-28 00:03:49'),
(19, 9, 'project_approved', 'project', 12, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-28 00:13:09'),
(20, 9, 'project_forced_live', 'project', 12, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-28 00:13:11'),
(21, 9, 'project_approved', 'project', 13, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-28 00:14:10'),
(22, 9, 'project_forced_live', 'project', 13, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-28 00:14:12'),
(23, 9, 'organization_verified', 'organization', 2, '{\"verified\": 0}', '{\"verified\": 1}', '::1', '2026-04-28 20:57:05'),
(24, 9, 'project_approved', 'project', 14, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-28 21:35:04'),
(25, 9, 'project_forced_live', 'project', 14, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-28 21:35:07'),
(26, 9, 'project_approved', 'project', 15, '{\"status\": \"pending\"}', '{\"status\": \"approved\"}', '::1', '2026-04-28 21:44:19'),
(27, 9, 'project_forced_live', 'project', 15, '{\"status\": \"unknown\"}', '{\"status\": \"live\"}', '::1', '2026-04-28 21:44:24');

-- --------------------------------------------------------

--
-- Table structure for table `budget_items`
--

CREATE TABLE `budget_items` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `estimated_cost` decimal(12,2) NOT NULL,
  `vendor_name` varchar(200) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `is_answered` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `project_id`, `user_id`, `parent_id`, `content`, `is_answered`, `created_at`, `updated_at`) VALUES
(1, 13, 9, NULL, 'اااا', 0, '2026-04-28 16:20:33', NULL),
(2, 13, 9, NULL, 'اااا', 0, '2026-04-28 16:21:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `disputes`
--

CREATE TABLE `disputes` (
  `id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `reported_by` int(11) NOT NULL,
  `reason` text NOT NULL,
  `status` enum('pending','resolved','dismissed') NOT NULL DEFAULT 'pending',
  `resolved_by` int(11) DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `disputes`
--

INSERT INTO `disputes` (`id`, `comment_id`, `reported_by`, `reason`, `status`, `resolved_by`, `resolved_at`, `created_at`) VALUES
(1, 2, 8, 'not true', 'pending', NULL, NULL, '2026-04-28 16:24:47');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `milestone_id` int(11) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `platform_fee` decimal(12,2) DEFAULT '0.00',
  `transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('escrow','released','refunded','completed') NOT NULL DEFAULT 'escrow',
  `is_anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `reward_id` int(11) DEFAULT NULL,
  `refunded_at` datetime DEFAULT NULL,
  `refund_reason` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `user_id`, `project_id`, `milestone_id`, `amount`, `platform_fee`, `transaction_id`, `status`, `is_anonymous`, `reward_id`, `refunded_at`, `refund_reason`, `created_at`) VALUES
(38, 9, 10, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-27 23:59:09'),
(39, 9, 10, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-27 23:59:27'),
(40, 9, 11, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:03:59'),
(41, 9, 11, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:04:18'),
(42, 9, 11, NULL, '500.00', '15.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:07:04'),
(43, 9, 11, NULL, '100.00', '3.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:12:17'),
(44, 9, 12, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:13:23'),
(45, 9, 13, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:14:20'),
(46, 9, 13, NULL, '10000.00', '300.00', NULL, 'escrow', 0, NULL, NULL, NULL, '2026-04-28 00:14:44');

-- --------------------------------------------------------

--
-- Table structure for table `kyc_documents`
--

CREATE TABLE `kyc_documents` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_path` varchar(255) NOT NULL,
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `milestones`
--

CREATE TABLE `milestones` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text,
  `allocated_amount` decimal(12,2) NOT NULL,
  `sequence_order` int(11) NOT NULL,
  `started_at` datetime DEFAULT NULL,
  `status` enum('pending','in_progress','submitted','approved','rejected','delayed') NOT NULL DEFAULT 'pending',
  `evidence_file` varchar(255) DEFAULT NULL,
  `evidence_description` text,
  `submitted_at` datetime DEFAULT NULL,
  `voting_deadline` datetime DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `milestones`
--

INSERT INTO `milestones` (`id`, `project_id`, `title`, `description`, `allocated_amount`, `sequence_order`, `started_at`, `status`, `evidence_file`, `evidence_description`, `submitted_at`, `voting_deadline`, `approved_at`) VALUES
(12, 10, '1', '1', '10000.00', 1, NULL, 'pending', NULL, NULL, NULL, NULL, NULL),
(13, 11, '1', '1', '10000.00', 1, NULL, 'pending', NULL, NULL, NULL, NULL, NULL),
(14, 12, '1', '1', '10000.00', 1, NULL, 'pending', NULL, NULL, NULL, NULL, NULL),
(15, 13, '1', '1', '10000.00', 1, NULL, 'pending', NULL, NULL, NULL, NULL, NULL),
(16, 14, '1', '1', '10000.00', 1, NULL, 'pending', NULL, NULL, NULL, NULL, NULL),
(17, 15, '1', '1', '10000.00', 1, NULL, 'pending', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `municipalities`
--

CREATE TABLE `municipalities` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `municipalities`
--

INSERT INTO `municipalities` (`id`, `name`) VALUES
(1, 'Default Municipality'),
(2, 'rehab');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `related_project_id` int(11) DEFAULT NULL,
  `related_milestone_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `message`, `related_project_id`, `related_milestone_id`, `is_read`, `created_at`) VALUES
(1, 8, 'project_funded', 'Project Fully Funded!', 'Your project has reached its goal. The first milestone is now active.', NULL, NULL, 0, '2026-04-27 17:31:35'),
(2, 8, 'project_funded', 'Project Fully Funded!', 'Your project has reached its goal. The first milestone is now active.', NULL, NULL, 0, '2026-04-27 20:03:53'),
(3, 8, 'project_funded', 'Project Fully Funded!', 'Your project has reached its goal. The first milestone is now active.', NULL, NULL, 0, '2026-04-27 20:12:59');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `user_id`, `name`, `registration_number`, `logo_url`, `verified`, `verified_by`, `verified_at`, `created_at`) VALUES
(1, 8, 'bmx', '1', NULL, 1, 9, '2026-04-27 15:32:47', '2026-04-27 15:32:16'),
(2, 9, 'ibm', '4', NULL, 1, 9, '2026-04-28 20:57:05', '2026-04-28 20:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `organization_members`
--

CREATE TABLE `organization_members` (
  `id` int(11) NOT NULL,
  `organization_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` enum('member','admin') DEFAULT 'member',
  `joined_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organization_members`
--

INSERT INTO `organization_members` (`id`, `organization_id`, `user_id`, `role`, `joined_at`) VALUES
(1, 1, 10, 'member', '2026-04-28 20:48:03'),
(2, 2, 11, 'member', '2026-04-28 20:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `short_description` varchar(500) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `project_lead_id` int(11) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `funding_goal` decimal(12,2) NOT NULL,
  `current_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `region` varchar(100) DEFAULT NULL,
  `deadline` date NOT NULL,
  `status` enum('draft','pending','approved','live','funded','failed','cancelled','completed') NOT NULL DEFAULT 'draft',
  `min_pledge` decimal(10,2) DEFAULT '5.00',
  `max_pledge` decimal(10,2) DEFAULT '10000.00',
  `vetting_notes` text,
  `submitted_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `sustainability_score` int(11) DEFAULT '0',
  `sustainability_notes` text,
  `municipality_id` int(11) DEFAULT NULL,
  `stretch_goal` decimal(10,2) DEFAULT NULL,
  `final_goal` decimal(10,2) DEFAULT NULL,
  `allow_stretch` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `slug`, `description`, `short_description`, `category`, `project_lead_id`, `organization_id`, `funding_goal`, `current_amount`, `region`, `deadline`, `status`, `min_pledge`, `max_pledge`, `vetting_notes`, `submitted_at`, `completed_at`, `created_at`, `updated_at`, `sustainability_score`, `sustainability_notes`, `municipality_id`, `stretch_goal`, `final_goal`, `allow_stretch`) VALUES
(10, 'off', 'off', 'off', 'off', 'education', 8, NULL, '10000.00', '20000.00', 'General', '2030-01-02', 'funded', '5.00', '10000.00', NULL, '2026-04-27 23:58:33', NULL, '2026-04-27 23:58:22', '2026-04-27 23:59:36', 0, NULL, 2, '20000.00', NULL, 0),
(11, '1', '1', '111', '111', 'park', 9, NULL, '10000.00', '20600.00', 'General', '2050-01-01', 'funded', '5.00', '10000.00', NULL, '2026-04-28 00:03:38', NULL, '2026-04-28 00:03:30', '2026-04-28 00:12:17', 0, NULL, 2, NULL, NULL, 0),
(12, '23', '23', '23', '23', 'other', 9, NULL, '10000.00', '10000.00', 'General', '2030-01-01', 'funded', '5.00', '10000.00', NULL, '2026-04-28 00:13:05', NULL, '2026-04-28 00:12:57', '2026-04-28 00:13:23', 0, NULL, 2, NULL, NULL, 0),
(13, '55', '55', '55', '55', 'park', 9, NULL, '10000.00', '20000.00', 'General', '2030-01-01', 'funded', '5.00', '10000.00', NULL, '2026-04-28 00:14:05', NULL, '2026-04-28 00:13:57', '2026-04-28 00:14:44', 0, NULL, 2, '20000.00', NULL, 0),
(14, 'qq', 'qq', 'qqq', 'qqq', 'education', 9, 2, '10000.00', '0.00', 'General', '2030-01-01', 'live', '5.00', '10000.00', NULL, '2026-04-28 21:14:58', NULL, '2026-04-28 21:14:46', '2026-04-28 21:35:07', 0, NULL, 2, NULL, NULL, 0),
(15, 'lm', 'lm', 'lm', 'lm', 'education', 9, 2, '10000.00', '0.00', 'General', '2030-01-02', 'live', '5.00', '10000.00', NULL, '2026-04-28 21:44:14', NULL, '2026-04-28 21:44:06', '2026-04-28 21:44:24', 0, NULL, 2, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `project_revisions`
--

CREATE TABLE `project_revisions` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `version_number` int(11) NOT NULL,
  `snapshot` json NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `project_updates`
--

CREATE TABLE `project_updates` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rate_limits`
--

CREATE TABLE `rate_limits` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `route` varchar(100) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT '1',
  `reset_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `generated_by` int(11) NOT NULL,
  `report_data` json NOT NULL,
  `generated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rewards`
--

CREATE TABLE `rewards` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `tier_name` varchar(100) NOT NULL,
  `min_donation` decimal(12,2) NOT NULL,
  `description` text,
  `quantity_available` int(11) DEFAULT NULL,
  `claimed_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`) VALUES
('milestone_approval_percentage_of_backers', '50'),
('milestone_vote_min_total_votes', '2');

-- --------------------------------------------------------

--
-- Table structure for table `site_verifications`
--

CREATE TABLE `site_verifications` (
  `id` int(11) NOT NULL,
  `milestone_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `municipality_id` int(11) DEFAULT NULL,
  `role` enum('user','admin','auditor') NOT NULL DEFAULT 'user',
  `id_verified` tinyint(1) NOT NULL DEFAULT '0',
  `id_document_path` varchar(255) DEFAULT NULL,
  `karma_score` int(11) NOT NULL DEFAULT '0',
  `total_donated` decimal(12,2) NOT NULL DEFAULT '0.00',
  `volunteer_hours` int(11) NOT NULL DEFAULT '0',
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_project_lead` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `phone`, `address`, `city`, `region`, `municipality_id`, `role`, `id_verified`, `id_document_path`, `karma_score`, `total_donated`, `volunteer_hours`, `is_banned`, `ban_reason`, `is_active`, `created_at`, `updated_at`, `is_project_lead`) VALUES
(8, 'youswef', 'yousef222@gmail.com', '$2y$10$WvX43g46eRjVEsPu6HVHP.FpkPTzfWWx2EjdjyLXfJEai10j5yzmm', 'Yousif Nour', '01009652913', 'cairo rehab', NULL, NULL, 2, 'user', 0, NULL, 4238, '42344.00', 0, 0, NULL, 1, '2026-04-26 16:38:33', '2026-04-27 19:57:14', 1),
(9, 'mona', 'yousef333@gmail.com', '$2y$10$zXYVpzz9zwGrAF9TApsZm.VqlNBlMTtL2zTL77CTbidLhq2tM7ava', 'mona mehrz', '01009652912', 'cairo rehab', NULL, NULL, 2, 'admin', 0, NULL, 25843, '258400.00', 0, 0, NULL, 1, '2026-04-26 16:39:29', '2026-04-28 00:14:44', 1),
(10, 'nour', 'yousifnour2004@gmail.com', '$2y$10$XFN6XzjVeD6YMpqW35VebeVsAzjPnfyy5.LfXspuUrBv9LQvw42Ey', 'nour glal', '01001668555', 'cairo rehab', NULL, NULL, 2, 'user', 0, NULL, 1012, '10100.00', 0, 0, NULL, 1, '2026-04-26 18:37:39', '2026-04-27 14:48:12', 1),
(11, 'marmiam', 'yousifnour20044@gmail.com', '$2y$10$lY13HaVsqUoBoa1OEQtISeOPh0c8EOCLgPMx/D4YeYTTAbfAPe0Du', 'mariam nour', '01009652913', 'cairo rehab', NULL, NULL, 2, 'user', 0, NULL, 0, '0.00', 0, 0, NULL, 1, '2026-04-26 20:40:58', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_rewards`
--

CREATE TABLE `user_rewards` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reward_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `task_description` text NOT NULL,
  `hours_committed` int(11) NOT NULL,
  `hours_completed` int(11) NOT NULL DEFAULT '0',
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_type` enum('project','milestone') NOT NULL,
  `item_id` int(11) NOT NULL,
  `vote_value` tinyint(1) NOT NULL COMMENT '1=approve, -1=reject',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `user_id`, `item_type`, `item_id`, `vote_value`, `created_at`) VALUES
(5, 8, 'project', 5, 1, '2026-04-26 17:31:17'),
(6, 10, 'project', 5, 1, '2026-04-26 18:38:03'),
(7, 9, 'project', 5, 1, '2026-04-26 20:09:02'),
(8, 8, 'project', 4, 1, '2026-04-27 14:47:51'),
(9, 10, 'project', 4, 1, '2026-04-27 14:48:12'),
(10, 9, 'project', 4, 1, '2026-04-27 19:56:18'),
(11, 8, 'project', 7, 1, '2026-04-27 19:57:14'),
(12, 9, 'project', 7, 1, '2026-04-27 20:04:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `budget_items`
--
ALTER TABLE `budget_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `disputes`
--
ALTER TABLE `disputes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `reported_by` (`reported_by`),
  ADD KEY `resolved_by` (`resolved_by`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `milestone_id` (`milestone_id`),
  ADD KEY `reward_id` (`reward_id`);

--
-- Indexes for table `kyc_documents`
--
ALTER TABLE `kyc_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `milestones`
--
ALTER TABLE `milestones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `municipalities`
--
ALTER TABLE `municipalities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `related_project_id` (`related_project_id`),
  ADD KEY `related_milestone_id` (`related_milestone_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `verified_by` (`verified_by`);

--
-- Indexes for table `organization_members`
--
ALTER TABLE `organization_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `org_user` (`organization_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `project_lead_id` (`project_lead_id`),
  ADD KEY `organization_id` (`organization_id`),
  ADD KEY `fk_projects_municipality` (`municipality_id`);

--
-- Indexes for table `project_revisions`
--
ALTER TABLE `project_revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `project_updates`
--
ALTER TABLE `project_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip_route_reset` (`ip_address`,`route`,`reset_at`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `site_verifications`
--
ALTER TABLE `site_verifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `milestone_id` (`milestone_id`),
  ADD KEY `verified_by` (`verified_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_rewards`
--
ALTER TABLE `user_rewards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `reward_id` (`reward_id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_vote` (`user_id`,`item_type`,`item_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `budget_items`
--
ALTER TABLE `budget_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `disputes`
--
ALTER TABLE `disputes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `kyc_documents`
--
ALTER TABLE `kyc_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `milestones`
--
ALTER TABLE `milestones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `municipalities`
--
ALTER TABLE `municipalities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `organization_members`
--
ALTER TABLE `organization_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `project_revisions`
--
ALTER TABLE `project_revisions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_updates`
--
ALTER TABLE `project_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rate_limits`
--
ALTER TABLE `rate_limits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_verifications`
--
ALTER TABLE `site_verifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_rewards`
--
ALTER TABLE `user_rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `budget_items`
--
ALTER TABLE `budget_items`
  ADD CONSTRAINT `budget_items_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `disputes`
--
ALTER TABLE `disputes`
  ADD CONSTRAINT `disputes_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `disputes_ibfk_2` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `disputes_ibfk_3` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `donations`
--
ALTER TABLE `donations`
  ADD CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `donations_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `donations_ibfk_3` FOREIGN KEY (`milestone_id`) REFERENCES `milestones` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `donations_ibfk_4` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `kyc_documents`
--
ALTER TABLE `kyc_documents`
  ADD CONSTRAINT `kyc_documents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `milestones`
--
ALTER TABLE `milestones`
  ADD CONSTRAINT `milestones_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`related_project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`related_milestone_id`) REFERENCES `milestones` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `organizations`
--
ALTER TABLE `organizations`
  ADD CONSTRAINT `organizations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `organizations_ibfk_2` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `organization_members`
--
ALTER TABLE `organization_members`
  ADD CONSTRAINT `organization_members_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `organization_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fk_projects_municipality` FOREIGN KEY (`municipality_id`) REFERENCES `municipalities` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`project_lead_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `projects_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_revisions`
--
ALTER TABLE `project_revisions`
  ADD CONSTRAINT `project_revisions_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_revisions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_updates`
--
ALTER TABLE `project_updates`
  ADD CONSTRAINT `project_updates_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_updates_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rewards`
--
ALTER TABLE `rewards`
  ADD CONSTRAINT `rewards_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `site_verifications`
--
ALTER TABLE `site_verifications`
  ADD CONSTRAINT `site_verifications_ibfk_1` FOREIGN KEY (`milestone_id`) REFERENCES `milestones` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `site_verifications_ibfk_2` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_rewards`
--
ALTER TABLE `user_rewards`
  ADD CONSTRAINT `user_rewards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_rewards_ibfk_2` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `volunteers_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
