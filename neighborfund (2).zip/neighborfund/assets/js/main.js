document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            if (alert && alert.parentNode) alert.remove();
        }, 5000);
    });

    const confirmBtns = document.querySelectorAll('[data-confirm]');
    confirmBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            if (!confirm(btn.getAttribute('data-confirm') || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });

    const toggler = document.getElementById('navToggler');
    const navLinks = document.getElementById('navLinks');
    if (toggler && navLinks) {
        toggler.addEventListener('click', function() {
            navLinks.classList.toggle('show');
        });
    }

    const budgetContainer = document.getElementById('budgetItems');
    if (budgetContainer) {
        const updateBudget = function() {
            let total = 0;
            document.querySelectorAll('.budget-cost').forEach(function(inp) {
                total += parseFloat(inp.value) || 0;
            });
            const goal = document.querySelector('input[name="funding_goal"]');
            if (goal) {
                let indicator = document.getElementById('budgetIndicator');
                if (!indicator) {
                    indicator = document.createElement('div');
                    indicator.id = 'budgetIndicator';
                    indicator.className = 'alert mt-3';
                    budgetContainer.parentNode.insertBefore(indicator, budgetContainer.nextSibling);
                }
                const diff = parseFloat(goal.value) - total;
                if (Math.abs(diff) < 0.01) {
                    indicator.className = 'alert alert-success mt-3';
                    indicator.innerHTML = '<i class="fas fa-check-circle"></i> Budget matches goal!';
                } else if (diff > 0) {
                    indicator.className = 'alert alert-warning mt-3';
                    indicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i> You are $' + diff.toFixed(2) + ' under goal.';
                } else {
                    indicator.className = 'alert alert-danger mt-3';
                    indicator.innerHTML = '<i class="fas fa-times-circle"></i> You are $' + Math.abs(diff).toFixed(2) + ' over goal!';
                }
            }
        };
        budgetContainer.addEventListener('input', updateBudget);
        document.querySelector('input[name="funding_goal"]')?.addEventListener('input', updateBudget);
    }

    

    budgetContainer?.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-row') || e.target.closest('.remove-row')) {
            e.target.closest('.budget-row').remove();
            const event = new Event('input');
            document.querySelectorAll('.budget-cost').forEach(inp => inp.dispatchEvent(event));
        }
    });

    window.copyLink = function(url) {
        const link = url || window.location.href;
        navigator.clipboard.writeText(link).then(() => alert('Link copied!')).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = link;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            alert('Link copied!');
        });
    };
});