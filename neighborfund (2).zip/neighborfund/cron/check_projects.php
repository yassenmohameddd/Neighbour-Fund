<?php


$root = dirname(__DIR__); // يصل إلى مجلد neighborfund



$dbFile = $root . '/config/Database.php';
if (!file_exists($dbFile)) {
    die("Database class not found at: $dbFile");
}
require_once $dbFile;
require_once $root . '/classes/Project.php';
require_once $root . '/classes/Donation.php';

$db = Database::getInstance();

// تحديث المشاريع التي وصلت للهدف
$db->query("UPDATE projects SET status = 'funded' WHERE current_amount >= funding_goal AND status = 'live'");

// جلب المشاريع الفاشلة
$failed = $db->query("SELECT id FROM projects WHERE deadline < NOW() AND current_amount < funding_goal AND status = 'live'")->fetchAll();
foreach ($failed as $p) {
    $db->prepare("UPDATE projects SET status = 'failed', completed_at = NOW() WHERE id = ?")->execute([$p['id']]);
    $donationObj = new Donation();
    $donationObj->refund($p['id']);
    $db->prepare("UPDATE donations SET status = 'refunded' WHERE project_id = ? AND status = 'pending'")->execute([$p['id']]);
}
?>