<?php
class Revision {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function saveVersion($project_id, $data): int {
        $stmt = $this->db->prepare("SELECT MAX(version_number) as max_v FROM project_revisions WHERE project_id = ?");
        $stmt->execute([$project_id]);
        $next = $stmt->fetch()['max_v'] + 1;
        $stmt = $this->db->prepare("INSERT INTO project_revisions (project_id, version_number, snapshot, created_by) VALUES (?,?,?,?)");
        $stmt->execute([$project_id, $next, json_encode($data), $_SESSION['user_id']]);
        return $next;
    }

    public function getHistory($project_id): array {
        $stmt = $this->db->prepare("SELECT * FROM project_revisions WHERE project_id = ? ORDER BY version_number DESC");
        $stmt->execute([$project_id]);
        return $stmt->fetchAll();
    }

    public function compareVersions($v1, $v2): array {
        $stmt = $this->db->prepare("SELECT snapshot FROM project_revisions WHERE id = ?");
        $stmt->execute([$v1]);
        $snap1 = json_decode($stmt->fetch()['snapshot'], true);
        $stmt->execute([$v2]);
        $snap2 = json_decode($stmt->fetch()['snapshot'], true);
        return ['version1' => $snap1, 'version2' => $snap2];
    }

    public function restoreVersion($version_id): bool {
        $stmt = $this->db->prepare("SELECT snapshot, project_id FROM project_revisions WHERE id = ?");
        $stmt->execute([$version_id]);
        $rev = $stmt->fetch();
        $data = json_decode($rev['snapshot'], true);
        $proj = new Project();
        return $proj->updateProject($rev['project_id'], $data);
    }
}
?>