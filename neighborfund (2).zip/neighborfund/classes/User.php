<?php
require_once __DIR__ . '/../config/database.php';
class User {
    private PDO $db;
    public $id, $username, $email, $full_name, $role, $karma_score, $credibility_rating, $volunteer_hours, $total_donated, $id_verified;

    public function __construct($data = null) {//$this->name = $data['name']$this->age = $data['age']; الميثود دي بتعمل زي كده

        $this->db = Database::getInstance();
        if ($data) {
            foreach ($data as $key => $value) {
                if (property_exists($this, $key)) $this->$key = $value;
            }
        }
    }

    public function register($name, $email, $password, $region = null): bool {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $username = strtolower(str_replace(' ', '_', $name)) . rand(100, 999);
        $stmt = $this->db->prepare("INSERT INTO users (full_name, email, password_hash, username, region) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$name, $email, $hash, $username, $region]);
    }

    public function login($email, $password): ?User {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ? AND is_banned = 0");
        $stmt->execute([$email]);
        $data = $stmt->fetch();
        if ($data && password_verify($password, $data['password_hash'])) {
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['user_role'] = $data['role'];
            return new User($data);
        }
        return null;
    }

    public function updateProfile($data): bool {
        $fields = [];
        $values = [];
        $allowed = ['full_name', 'phone', 'address', 'city', 'region'];
        foreach ($data as $k => $v) {
            if (in_array($k, $allowed)) {
                $fields[] = "$k = ?";
                $values[] = $v;
            }
        }
        if (empty($fields)) return false;
        $values[] = $this->id;
        $sql = "UPDATE users SET " . implode(',', $fields) . " WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }

    public function calculateKarma($user_id): int {
        $stmt = $this->db->prepare("SELECT total_donated, volunteer_hours FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $u = $stmt->fetch();
        $karma = ($u['total_donated'] / 10) + ($u['volunteer_hours'] * 2);
        $this->db->prepare("UPDATE users SET karma_score = ? WHERE id = ?")->execute([$karma, $user_id]);
        return $karma;
    }

    public function verifyKYC($user_id, $document_path): bool {
        $stmt = $this->db->prepare("UPDATE users SET id_verified = 1, id_document_path = ? WHERE id = ?");
        return $stmt->execute([$document_path, $user_id]);
    }

    public function getUserById($id): ?User {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        if ($data) return new User($data);
        return null;
    }
    
    public function isProjectLead(): bool {
    $stmt = $this->db->prepare("SELECT COUNT(*) FROM projects WHERE project_lead_id = ?");
    $stmt->execute([$this->id]);
    return $stmt->fetchColumn() > 0;
    }

    public function getUserProjects(): array {
        $stmt = $this->db->prepare("SELECT * FROM projects WHERE project_lead_id = ? ORDER BY created_at DESC");
        $stmt->execute([$this->id]);
        return $stmt->fetchAll();
    }

    public function getUnreadNotifications(): array {
    $stmt = $this->db->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? AND is_read = FALSE 
        ORDER BY created_at DESC 
        LIMIT 20
    ");
    $stmt->execute([$this->id]);
    return $stmt->fetchAll();
}

    
    public function getAllUsers($limit = 100): array {
        $stmt = $this->db->prepare("SELECT * FROM users ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }

    public function getProjects() {
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT * FROM projects WHERE project_lead_id = ? ORDER BY created_at DESC");
    $stmt->execute([$this->id]);
    return $stmt->fetchAll();
    }

    public function getDonations() {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT d.*, p.title, p.slug FROM donations d JOIN projects p ON d.project_id = p.id WHERE d.user_id = ? ORDER BY d.created_at DESC");
        $stmt->execute([$this->id]);
        return $stmt->fetchAll();
    }
    
}
?>