<?php
class Comment {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function addComment($user_id, $project_id, $text): int {
        $stmt = $this->db->prepare("INSERT INTO comments (user_id, project_id, content) VALUES (?,?,?)");
        $stmt->execute([$user_id, $project_id, $text]);
        return $this->db->lastInsertId();
    }

    public function editComment($id, $text): bool {
        $stmt = $this->db->prepare("UPDATE comments SET content = ? WHERE id = ?");
        return $stmt->execute([$text, $id]);
    }

    public function deleteComment($id): bool {
        $stmt = $this->db->prepare("DELETE FROM comments WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getComments($project_id): array {
        $stmt = $this->db->prepare("SELECT c.*, u.full_name FROM comments c JOIN users u ON c.user_id = u.id WHERE c.project_id = ? ORDER BY c.created_at DESC");
        $stmt->execute([$project_id]);
        return $stmt->fetchAll();
    }

    
    
   public function getAllComments($limit = 100): array {
    $limit = (int)$limit;
    $stmt = $this->db->prepare("
        SELECT c.*, u.full_name, p.title as project_title 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        JOIN projects p ON c.project_id = p.id 
        ORDER BY c.created_at DESC 
        LIMIT $limit
    ");
    $stmt->execute();
    return $stmt->fetchAll();
}
}
?>