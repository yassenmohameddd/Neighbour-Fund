<?php
class Notification extends Model {
    protected string $table = 'notifications';
    protected array $fillable = ['user_id', 'type', 'title', 'message', 'related_project_id', 'related_milestone_id', 'is_read'];

    public static function notify(int $userId, string $type, string $title, string $message, array $related = []): self {
        return self::create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'related_project_id' => $related['project_id'] ?? null,
            'related_milestone_id' => $related['milestone_id'] ?? null
        ]);
    }

    public function markRead(): void {
        $this->update(['is_read' => true]);
    }

    public static function markAllRead(int $userId): void {
        $db = Database::getInstance();
        $db->prepare("UPDATE notifications SET is_read = TRUE WHERE user_id = ? AND is_read = FALSE")->execute([$userId]);
    }

    public static function unreadCount(int $userId): int {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = FALSE");
        $stmt->execute([$userId]);
        return (int)$stmt->fetch()['count'];
    }
}
?>