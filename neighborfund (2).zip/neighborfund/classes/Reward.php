<?php
class Reward {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    
    
    public function createReward($project_id, $data): int {
        $stmt = $this->db->prepare("INSERT INTO rewards (project_id, tier_name, min_donation, description, quantity_available) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $project_id,
            $data['tier_name'],
            $data['min_donation'],
            $data['description'],
            $data['quantity_available'] ?? null
        ]);
        return $this->db->lastInsertId();
    }

    /**
     * تعيين مكافأة لمستخدم بعد التبرع
     */
    public function assignReward($user_id, $reward_id): bool {
        $stmt = $this->db->prepare("INSERT INTO user_rewards (user_id, reward_id) VALUES (?, ?)");
        return $stmt->execute([$user_id, $reward_id]);
    }

   
    
    public function getRewards($project_id): array {
        $stmt = $this->db->prepare("SELECT * FROM rewards WHERE project_id = ? ORDER BY min_donation ASC");
        $stmt->execute([$project_id]);
        return $stmt->fetchAll();
    }

    
    
    public function getByProject($project_id): array {
        return $this->getRewards($project_id);
    }

    
    public function manageTiers($project_id, $tiers): bool {
        // حذف المكافآت القديمة
        $this->db->prepare("DELETE FROM rewards WHERE project_id = ?")->execute([$project_id]);
        
        
        foreach ($tiers as $t) {
            $this->createReward($project_id, $t);
        }
        return true;
    }

    
    
    public function deleteReward($reward_id): bool {
        $stmt = $this->db->prepare("DELETE FROM rewards WHERE id = ?");
        return $stmt->execute([$reward_id]);
    }
}
?>