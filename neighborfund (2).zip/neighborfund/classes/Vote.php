<?php
class Vote {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function castVote($user_id, $item_id, $type) {
    $stmt = $this->db->prepare("INSERT INTO votes (user_id, item_type, item_id, vote_value) VALUES (?, ?, ?, 1) ON DUPLICATE KEY UPDATE vote_value = 1");
    return $stmt->execute([$user_id, $type, $item_id]);
    }
    public function getVotes($item_id, $type) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as cnt FROM votes WHERE item_type = ? AND item_id = ? AND vote_value = 1");
        $stmt->execute([$type, $item_id]);
        return $stmt->fetch()['cnt'];
    }
    public function heatMapScore($project_id) {
        return $this->getVotes($project_id, 'project');
    }

    

    
    public function countMilestoneVotes($milestone_id): int {
    $stmt = $this->db->prepare("SELECT COUNT(*) as cnt FROM votes WHERE item_type = 'milestone' AND item_id = ? AND vote_value = 1");
    $stmt->execute([$milestone_id]);
    return $stmt->fetch()['cnt'];
    }
    public function hasUserVoted($user_id, $item_id, $type): bool {
    $stmt = $this->db->prepare("SELECT COUNT(*) FROM votes WHERE user_id = ? AND item_type = ? AND item_id = ? AND vote_value = 1");
    $stmt->execute([$user_id, $type, $item_id]);
    return $stmt->fetchColumn() > 0;
    }

}
?>