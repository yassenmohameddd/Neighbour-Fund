<?php
class Donation {
    private PDO $db;
    public $id, $user_id, $project_id, $milestone_id, $amount, $platform_fee, $transaction_id, $status, $is_anonymous, $reward_id, $refunded_at, $refund_reason, $created_at;

    
    public function __construct($data = null) {
        $this->db = Database::getInstance();
        if ($data) {
            foreach ($data as $key => $value) {
                if (property_exists($this, $key)) {
                    $this->$key = $value;
                }
            }
        }
    }

  public function donate($user_id, $project_id, $amount): bool {
    $fee = $amount * 0.03;
    $txn = 'TXN' . time() . rand(100, 999);

    $stmt = $this->db->prepare("
        INSERT INTO donations 
        (user_id, project_id, amount, platform_fee, transaction_id, status) 
        VALUES (?,?,?,?,?,'escrow')
    ");

    $result = $stmt->execute([$user_id, $project_id, $amount, $fee, $txn]);

    if ($result) {
        // تحديث المشروع
        $this->db->prepare("
            UPDATE projects 
            SET current_amount = current_amount + ? 
            WHERE id = ?
        ")->execute([$amount, $project_id]);

        // تحديث المستخدم
        $this->db->prepare("
            UPDATE users 
            SET total_donated = total_donated + ? 
            WHERE id = ?
        ")->execute([$amount, $user_id]);

        // 🔥 الجديد هنا بقى
        $projectObj = new Project();
        $project = $projectObj->getProjectById($project_id);

        if ($project) {
            $project->checkFundingDeadline(); // يشغل stretch أو يقفل لو لازم
        }

        $user = new User();
        $user->calculateKarma($user_id);
    }

    return $result;
}

    public function refund($project_id): bool {
        
        $stmt = $this->db->prepare("SELECT id, amount, user_id FROM donations WHERE project_id = ? AND status = 'escrow'");
        $stmt->execute([$project_id]);
        $donations = $stmt->fetchAll();
        foreach ($donations as $d) {
            $this->db->prepare("UPDATE donations SET status = 'refunded', refunded_at = NOW(), refund_reason = 'Project failed' WHERE id = ?")->execute([$d['id']]);
            $this->db->prepare("UPDATE projects SET current_amount = current_amount - ? WHERE id = ?")->execute([$d['amount'], $project_id]);
            $this->db->prepare("UPDATE users SET total_donated = total_donated - ? WHERE id = ?")->execute([$d['amount'], $d['user_id']]);
        }
        return true;
    }

    public function getDonationsByProject($project_id): array {
        $stmt = $this->db->prepare("SELECT d.*, u.full_name FROM donations d JOIN users u ON d.user_id = u.id WHERE d.project_id = ? ORDER BY d.created_at DESC");
        $stmt->execute([$project_id]);
        return $stmt->fetchAll();
    }

    public function getUserDonations($user_id): array {
        $stmt = $this->db->prepare("SELECT d.*, p.title FROM donations d JOIN projects p ON d.project_id = p.id WHERE d.user_id = ? ORDER BY d.created_at DESC");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll();
    }

    public function refundByProject($project_id) {
        
        $stmt = $this->db->prepare("UPDATE donations SET status = 'refunded' WHERE project_id = ? AND status IN ('escrow', 'released')");
        $stmt->execute([$project_id]);
    }

    public function releaseMilestoneFunds($milestone_id): bool {
    
        $stmt = $this->db->prepare("UPDATE donations SET status = 'released' WHERE milestone_id = ? AND status = 'escrow'");
        return $stmt->execute([$milestone_id]);
    }

    public static function find($id): ?self {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM donations WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        if (!$data) return null;
        return new self($data);
    }
}
?>