<?php
require_once __DIR__ . '/../config/database.php';
class Auth {
    private static ?User $currentUser = null;
    private static PDO $db;

    public static function init() {
        self::$db = Database::getInstance();
    }

    public static function login($username_or_email, $password): ?User {
        $stmt = self::$db->prepare("SELECT * FROM users WHERE (email = ? OR username = ?) AND is_banned = 0");
        $stmt->execute([$username_or_email, $username_or_email]);
        $data = $stmt->fetch();
        
        if ($data && password_verify($password, $data['password_hash'])) {
            $_SESSION['user_id'] = $data['id'];
            
            $_SESSION['user_role'] = $data['role'];
            self::$currentUser = new User($data);
            return self::$currentUser;
        }
        return null;
    }

    public static function logout(): void {
        session_destroy();
        
        self::$currentUser = null;
    }
    
    
    public static function checkRole($role): bool {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }

    public static function isLoggedIn(): bool {
        return isset($_SESSION['user_id']);
    }

    public static function requireAuth(): void {
        if (!self::isLoggedIn()) {
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            
            echo '<script>window.location.href = "login.php";</script>';
            echo '<script>window.location.href = "login.php";</script>';
            exit;
        }
    }

    public static function user(): ?User {
        if (self::$currentUser) return self::$currentUser;
        if (self::isLoggedIn()) {
            $user = new User();
            $data = $user->getUserById($_SESSION['user_id']);
            self::$currentUser = $data;
            return $data;
        }
        return null;
    }
}
Auth::init();
?>