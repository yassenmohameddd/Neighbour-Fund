<?php
class Report {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function generateReport($type = 'general'): array {
        $data = [
            'total_donations' => $this->getTotalDonations(),
            'total_projects' => $this->getTotalProjects(),
            'total_users' => $this->db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
            'generated_at' => date('Y-m-d H:i:s')
        ];
        $stmt = $this->db->prepare("INSERT INTO reports (type, generated_by, report_data) VALUES (?, ?, ?)");
        $stmt->execute([$type, $_SESSION['user_id'], json_encode($data)]);
        return $data;
    }

    public function getTotalDonations(): float {
        return $this->db->query("SELECT SUM(amount) FROM donations WHERE status='completed'")->fetchColumn();
    }

    public function getTotalProjects(): int {
        return $this->db->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    }

    public function yearlyReport($year): array {
        $start = "$year-01-01 00:00:00";
        $end = "$year-12-31 23:59:59";
        $stmt = $this->db->prepare("SELECT SUM(amount) as total, COUNT(*) as count FROM donations WHERE created_at BETWEEN ? AND ? AND status='completed'");
        $stmt->execute([$start, $end]);
        $donations = $stmt->fetch();
        $stmt = $this->db->prepare("SELECT COUNT(*) as projects FROM projects WHERE created_at BETWEEN ? AND ?");
        $stmt->execute([$start, $end]);
        $projects = $stmt->fetch();
        return ['year' => $year, 'total_donations' => $donations['total'] ?? 0, 'total_projects' => $projects['projects']];
    }

    public function communityAnalytics(): array {
        $stmt = $this->db->query("SELECT region, COUNT(*) as projects, SUM(current_amount) as raised FROM projects WHERE status IN ('approved','completed') GROUP BY region");
        $regions = $stmt->fetchAll();
        $stmt = $this->db->query("SELECT COUNT(DISTINCT user_id) as active_donors FROM donations WHERE status='completed'");
        $activeDonors = $stmt->fetch()['active_donors'];
        return ['regions' => $regions, 'active_donors' => $activeDonors];
    }
}
?>