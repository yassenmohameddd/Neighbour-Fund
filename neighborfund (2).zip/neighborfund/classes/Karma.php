<?php
class Karma {
    private ?PDO $db;

    public function __construct() {
        try {
            $this->db = Database::getInstance();
        } catch (Exception $e) {
            $this->db = null;
            error_log("Karma: Database connection failed - " . $e->getMessage());
        }
    }

   
    
    public function addPoints($user_id, $points, $reason = ''): bool {
        if (!$this->db) return false;
        if ($points == 0) return true;
        if (empty($user_id) || !is_numeric($user_id)) return false;
        
        try {
            $stmt = $this->db->prepare("UPDATE users SET karma_score = karma_score + ? WHERE id = ?");
            $result = $stmt->execute([$points, $user_id]);
            
            
            
            
            return $result;
        } catch (PDOException $e) {
            error_log("Karma addPoints error: " . $e->getMessage());
            return false;
        }
    }

    
    public function deductPoints($user_id, $points, $reason = ''): bool {
        return $this->addPoints($user_id, -abs($points), $reason);
    }

    
    
    public function getPoints($user_id): int {
        if (!$this->db || empty($user_id)) return 0;
        try {
            $stmt = $this->db->prepare("SELECT karma_score FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return isset($row['karma_score']) ? (int)$row['karma_score'] : 0;
        } catch (PDOException $e) {
            error_log("Karma getPoints error: " . $e->getMessage());
            return 0;
        }
    }

    
    
    public function getLeaderboard($limit = 10): array {
        if (!$this->db) return [];
        try {
            $stmt = $this->db->prepare("SELECT id, full_name, username, karma_score FROM users ORDER BY karma_score DESC LIMIT ?");
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Karma getLeaderboard error: " . $e->getMessage());
            return [];
        }
    }

    
    
    public function handleEvent($event_type, $user_id, $entity_id = null): void {
        $pointsMap = [
            'donation'       => 5,
            'comment'        => 2,
            'upvote'         => 1,
            'volunteer_hour' => 1,
            'project_created'=> 10,
            'project_funded' => 20,
        ];
        $points = $pointsMap[$event_type] ?? 0;
        if ($points > 0 && !empty($user_id)) {
            $this->addPoints($user_id, $points, "Event: $event_type");
        }
    }

    
    public function hasMinKarma($user_id, $required_points): bool {
        return $this->getPoints($user_id) >= $required_points;
    }
}
?>