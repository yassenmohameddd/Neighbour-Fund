<?php
class Volunteer {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function assignVolunteer($user_id, $project_id, $task, $hours): int {
        $stmt = $this->db->prepare("INSERT INTO volunteers (user_id, project_id, task_description, hours_committed) VALUES (?,?,?,?)");
        $stmt->execute([$user_id, $project_id, $task, $hours]);
        return $this->db->lastInsertId();
    }

    public function trackHours($user_id, $project_id, $hours): bool {
        $stmt = $this->db->prepare("UPDATE volunteers SET hours_completed = hours_completed + ? WHERE user_id = ? AND project_id = ? AND status = 'approved'");
        $result = $stmt->execute([$hours, $user_id, $project_id]);
        if ($result) {
            $stmt = $this->db->prepare("UPDATE users SET volunteer_hours = volunteer_hours + ? WHERE id = ?");
            $stmt->execute([$hours, $user_id]);
            $user = new User();
            $user->calculateKarma($user_id);
            $karma = new Karma();
            $karma->handleEvent('volunteer_hour', $user_id);
        }
        return $result;
    }

    
    public function getUserVolunteer($user_id): array {
    $stmt = $this->db->prepare("
        SELECT v.*, p.title 
        FROM volunteers v 
        JOIN projects p ON v.project_id = p.id 
        WHERE v.user_id = ? 
        ORDER BY v.created_at DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
    }

    public function verifyVisit($project_id): bool {
        
        return true;
    }

    public function balanceWorkload(): array {
        $stmt = $this->db->query("
            SELECT v.user_id, u.full_name, 
                SUM(v.hours_committed) as total_committed,
                SUM(v.hours_completed) as total_completed,
                (SUM(v.hours_committed) - SUM(v.hours_completed)) as remaining
            FROM volunteers v
            JOIN users u ON v.user_id = u.id
            WHERE v.status = 'approved'
            GROUP BY v.user_id
            ORDER BY remaining ASC
        ");
        return $stmt->fetchAll();
    }
}
?>