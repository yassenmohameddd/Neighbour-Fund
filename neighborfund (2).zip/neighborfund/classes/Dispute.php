<?php
class Dispute {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    
    
    public function createDispute($user_id, $comment_id, $reason): int {
        $stmt = $this->db->prepare("INSERT INTO disputes (comment_id, reported_by, reason) VALUES (?, ?, ?)");
        $stmt->execute([$comment_id, $user_id, $reason]);
        return $this->db->lastInsertId();
    }

    
    
    public function resolveDispute($id, $admin_id): bool {
        $stmt = $this->db->prepare("UPDATE disputes SET status = 'resolved', resolved_by = ?, resolved_at = NOW() WHERE id = ?");
        return $stmt->execute([$admin_id, $id]);
    }

    
    
    public function dismissDispute($id): bool {
        $stmt = $this->db->prepare("UPDATE disputes SET status = 'dismissed', resolved_at = NOW() WHERE id = ?");
        return $stmt->execute([$id]);
    }

    
    
    public function getDisputes($status = 'pending'): array {
        $stmt = $this->db->prepare("
            SELECT d.*, c.content, u.full_name as reporter, p.title as project_title, p.slug
            FROM disputes d
            JOIN comments c ON d.comment_id = c.id
            JOIN users u ON d.reported_by = u.id
            JOIN projects p ON c.project_id = p.id
            WHERE d.status = ?
            ORDER BY d.created_at DESC
        ");
        $stmt->execute([$status]);
        return $stmt->fetchAll();
    }

    
    
    public function getUserDisputes($user_id): array {
        $stmt = $this->db->prepare("
            SELECT d.*, c.content, p.title as project_title
            FROM disputes d
            JOIN comments c ON d.comment_id = c.id
            JOIN projects p ON c.project_id = p.id
            WHERE d.reported_by = ?
            ORDER BY d.created_at DESC
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll();
    }

    
    public function getDisputeById($id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM disputes WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        return $data ?: null;
    }

    
    
    public function closeDispute($id): bool {
        return $this->dismissDispute($id);
    }
}
?>