<?php
class Audit {
    private static PDO $db;

    public static function init() {
        self::$db = Database::getInstance();
    }

    public static function logAction($user_id, $action, $entity_type = null, $entity_id = null, $old = [], $new = []): void {
        $stmt = self::$db->prepare("INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([
            $user_id, $action, $entity_type, $entity_id,
            json_encode($old), json_encode($new),
            $_SERVER['REMOTE_ADDR'] ?? ''
        ]);
    }

    public static function getLogs($limit = 100): array {
        $stmt = self::$db->prepare("SELECT al.*, u.username FROM audit_log al LEFT JOIN users u ON al.user_id = u.id ORDER BY al.created_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }

    public static function getUserLogs($user_id): array {
        $stmt = self::$db->prepare("SELECT * FROM audit_log WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll();
    }

    public static function trackChanges($entity_id, $entity_type): array {
        $stmt = self::$db->prepare("SELECT * FROM audit_log WHERE entity_type = ? AND entity_id = ? ORDER BY created_at DESC");
        $stmt->execute([$entity_type, $entity_id]);
        return $stmt->fetchAll();
    }
}
Audit::init();
?>