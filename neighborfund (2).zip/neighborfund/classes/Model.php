<?php
abstract class Model {
    protected PDO $db;
    protected string $table;
    protected string $primaryKey = 'id';
    protected array $fillable = [];
    protected array $attributes = [];
    protected bool $exists = false;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getDb(): PDO { return $this->db; }
    public function getTable(): string { return $this->table; }
    public function getAttributes(): array { return $this->attributes; }
    public function setAttributes(array $attrs): void { $this->attributes = $attrs; }
    public function setExists(bool $exists): void { $this->exists = $exists; }

    public function __get(string $name) {
        return $this->attributes[$name] ?? null;
    }

    public function __set(string $name, $value) {
        if (empty($this->fillable) || in_array($name, $this->fillable)) {
            $this->attributes[$name] = $value;
        }
    }

    public static function find(int $id): ?static {
        $instance = new static();
        $stmt = $instance->db->prepare("SELECT * FROM {$instance->table} WHERE {$instance->primaryKey} = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        if (!$data) return null;
        $instance->attributes = $data;
        $instance->exists = true;
        return $instance;
    }

    public static function create(array $data): static {
        $instance = new static();
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');
        $sql = "INSERT INTO {$instance->table} (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
        $stmt = $instance->db->prepare($sql);
        $stmt->execute(array_values($data));
        $instance->attributes = $data;
        $instance->attributes[$instance->primaryKey] = (int)$instance->db->lastInsertId();
        $instance->exists = true;
        return $instance;
    }

    public function update(array $data = []): bool {
        if (!$this->exists) return false;
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $this->attributes[$key] = $value;
            }
        }
        $fields = [];
        $values = [];
        foreach ($this->attributes as $key => $value) {
            if ($key !== $this->primaryKey) {
                $fields[] = "$key = ?";
                $values[] = $value;
            }
        }
        $values[] = $this->attributes[$this->primaryKey];
        $sql = "UPDATE {$this->table} SET " . implode(', ', $fields) . " WHERE {$this->primaryKey} = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }

    public function delete(): bool {
        if (!$this->exists) return false;
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?");
        return $stmt->execute([$this->attributes[$this->primaryKey]]);
    }

    public static function where(string $column, string $operator, $value): QueryBuilder {
        return (new QueryBuilder(static::class))->where($column, $operator, $value);
    }

    public static function all(): array {
        $instance = new static();
        $stmt = $instance->db->query("SELECT * FROM {$instance->table}");
        return $stmt->fetchAll();
    }
}

class QueryBuilder {
    private Model $model;
    private array $wheres = [];
    private array $bindings = [];
    private ?string $orderBy = null;
    private ?int $limit = null;
    private ?int $offset = null;

    public function __construct(string $modelClass) {
        $this->model = new $modelClass();
    }

    public function where(string $column, string $operator, $value): self {
        $this->wheres[] = "$column $operator ?";
        $this->bindings[] = $value;
        return $this;
    }

    public function orderBy(string $column, string $direction = 'ASC'): self {
        $this->orderBy = "$column $direction";
        return $this;
    }

    public function limit(int $limit, ?int $offset = null): self {
        $this->limit = $limit;
        $this->offset = $offset;
        return $this;
    }

    public function get(): array {
        $sql = "SELECT * FROM {$this->model->getTable()}";
        if (!empty($this->wheres)) {
            $sql .= " WHERE " . implode(' AND ', $this->wheres);
        }
        if ($this->orderBy) {
            $sql .= " ORDER BY {$this->orderBy}";
        }
        if ($this->limit) {
            $sql .= " LIMIT {$this->limit}";
            if ($this->offset) {
                $sql .= " OFFSET {$this->offset}";
            }
        }
        $stmt = $this->model->getDb()->prepare($sql);
        $stmt->execute($this->bindings);
        $results = [];
        $class = get_class($this->model);
        while ($row = $stmt->fetch()) {
            $instance = new $class();
            $instance->setAttributes($row);
            $instance->setExists(true);
            $results[] = $instance;
        }
        return $results;
    }

    public function first(): ?Model {
        $this->limit = 1;
        $results = $this->get();
        return $results[0] ?? null;
    }

    public function count(): int {
        $sql = "SELECT COUNT(*) FROM {$this->model->getTable()}";
        if (!empty($this->wheres)) {
            $sql .= " WHERE " . implode(' AND ', $this->wheres);
        }
        $stmt = $this->model->getDb()->prepare($sql);
        $stmt->execute($this->bindings);
        return (int)$stmt->fetchColumn();
    }
}