<?php

require_once __DIR__ . '/Audit.php';
class Milestone {
    private PDO $db;
    public $id, $project_id, $title, $description, $allocated_amount, $sequence_order, $status, $started_at;
    public function __construct($data = null) {
        $this->db = Database::getInstance();
        if ($data) {
            foreach ($data as $key => $value) {
                if (property_exists($this, $key)) {
                    $this->$key = $value;
                }
            }
        }
    }

    public function addMilestone($project_id, $data): int {
        $stmt = $this->db->prepare("INSERT INTO milestones (project_id, title, description, allocated_amount, sequence_order) VALUES (?,?,?,?,?)");
        $stmt->execute([$project_id, $data['title'], $data['description'], $data['amount'], $data['order']]);
        return $this->db->lastInsertId();
    }

    public function updateMilestone($id, $data): bool {
        $fields = [];
        $values = [];
        $allowed = ['title', 'description', 'allocated_amount', 'sequence_order'];
        foreach ($data as $k => $v) {
            if (in_array($k, $allowed)) {
                $fields[] = "$k = ?";
                $values[] = $v;
            }
        }
        if (empty($fields)) return false;
        $values[] = $id;
        $sql = "UPDATE milestones SET " . implode(',', $fields) . " WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }

    public function submitEvidence($id, $file, $description): bool {
        $stmt = $this->db->prepare("SELECT status FROM milestones WHERE id = ?");
        $stmt->execute([$id]);
        $status = $stmt->fetchColumn();
        if ($status !== 'in_progress') {
            return false; // أو قم برمي استثناء
        }
        // منع رفع الأدلة إذا المشروع لسه ما وصلش للهدف
        $stmt = $this->db->prepare("
            SELECT p.status FROM projects p 
            JOIN milestones m ON m.project_id = p.id 
            WHERE m.id = ?
        ");
        $stmt->execute([$id]);
        $projectStatus = $stmt->fetchColumn();
        if ($projectStatus != 'funded' && $projectStatus != 'live') {
            return false; // أو throw new Exception("لا يمكن رفع الأدلة قبل اكتمال التمويل");
        }
        
        // باقي الكود القديم
        $stmt = $this->db->prepare("UPDATE milestones SET status = 'submitted', evidence_file = ?, evidence_description = ?, submitted_at = NOW(), voting_deadline = DATE_ADD(NOW(), INTERVAL 7 DAY) WHERE id = ?");
        return $stmt->execute([$file, $description, $id]);
    }

    public function approveMilestone($id): bool {
        $stmt = $this->db->prepare("UPDATE milestones SET status = 'approved', approved_at = NOW() WHERE id = ?");
        $result = $stmt->execute([$id]);
        if ($result) {
            $this->releaseFunds($id);               
            $this->activateNextMilestone();       
        }
        // إشعار لقائد المشروع
        $stmt = $this->db->prepare("SELECT p.project_lead_id FROM projects p JOIN milestones m ON m.project_id = p.id WHERE m.id = ?");
        $stmt->execute([$id]);
        $lead_id = $stmt->fetchColumn();
        if ($lead_id && class_exists('Notification')) {
            Notification::notify($lead_id, 'milestone_approved', 'Milestone Approved', 'Your milestone has been approved and funds released.');
        }
        return $result;
    }

    public function rejectMilestone($id): bool {
        $stmt = $this->db->prepare("UPDATE milestones SET status = 'rejected' WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function releaseFunds($id): bool {
        // جلب المبلغ المخصص لهذه المرحلة
        $stmt = $this->db->prepare("SELECT allocated_amount, project_id FROM milestones WHERE id = ?");
        $stmt->execute([$id]);
        $m = $stmt->fetch();
        if (!$m) return false;

        // تحرير التبرعات المرتبطة بهذه المرحلة فقط
        $stmt = $this->db->prepare("UPDATE donations SET status = 'released' WHERE milestone_id = ? AND status = 'escrow'");
        $stmt->execute([$id]);

        // تسجيل في audit_log
        Audit::logAction($_SESSION['user_id'], 'milestone_funds_released', 'milestone', $id, [], ['amount' => $m['allocated_amount']]);
        return true;
    }

    public function getMilestones($project_id): array {
        $stmt = $this->db->prepare("SELECT * FROM milestones WHERE project_id = ? ORDER BY sequence_order");
        $stmt->execute([$project_id]);
        return $stmt->fetchAll();
    }

    public static function find($id): ?self {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM milestones WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        if (!$data) return null;
        return new self($data);
    }

    
    
    public function activate(): bool {
        $stmt = $this->db->prepare("UPDATE milestones SET status = 'in_progress', started_at = NOW() WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
    private function activateNextMilestone(): void {
        if (!$this->project_id || !$this->sequence_order) return;
        $stmt = $this->db->prepare("
            SELECT * FROM milestones 
            WHERE project_id = ? AND sequence_order = ? AND status = 'pending'
        ");
        $nextOrder = $this->sequence_order + 1;
        $stmt->execute([$this->project_id, $nextOrder]);
        $next = $stmt->fetch();
        if ($next) {
            $nextMilestone = Milestone::find($next['id']);
            if ($nextMilestone) $nextMilestone->activate();  // تغيير الحالة إلى 'in_progress'
        } else {
            // لا توجد مراحل تالية، ننهي المشروع
            $this->db->prepare("UPDATE projects SET status = 'completed' ...");
        }
    }
    public function checkForDelay(): void {
    if ($this->status == 'in_progress') {
        // استخدام started_at كتاريخ بدء، وإذا كان NULL نستخدم submitted_at أو الوقت الحالي
        $startDate = $this->started_at ? strtotime($this->started_at) : time();
        $deadline = $startDate + (14 * 86400); // 14 يوم
        if (time() > $deadline) {
            // إشعار لقائد المشروع
            $leadStmt = $this->db->prepare("SELECT project_lead_id FROM projects WHERE id = ?");
            $leadStmt->execute([$this->project_id]);
            $leadId = $leadStmt->fetchColumn();
            if ($leadId && class_exists('Notification')) {
                Notification::notify($leadId, 'milestone_delay', 'Milestone Overdue', "Milestone '{$this->title}' is delayed. Please submit evidence.");
            }
            // إشعار للمانحين
            $backersStmt = $this->db->prepare("SELECT DISTINCT user_id FROM donations WHERE project_id = ? AND status IN ('escrow','released')");
            $backersStmt->execute([$this->project_id]);
            while ($backer = $backersStmt->fetch()) {
                if (class_exists('Notification')) {
                    Notification::notify($backer['user_id'], 'milestone_delay', 'Project Delayed', "Milestone '{$this->title}' is overdue.");
                }
            }
            // تحديث الحالة إلى 'delayed' (تأكد من أن الجدول يقبل هذه القيمة)
            $this->db->prepare("UPDATE milestones SET status = 'delayed' WHERE id = ?")->execute([$this->id]);
        }
    }

}   
    
}
