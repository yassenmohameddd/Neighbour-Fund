<?php
class Organization {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function createOrganization($user_id, $data): int {
        $stmt = $this->db->prepare("INSERT INTO organizations (user_id, name, registration_number, logo_url) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $data['name'], $data['reg_number'], $data['logo'] ?? null]);
        return $this->db->lastInsertId();
    }

    public function verifyOrganization($org_id, $admin_id): bool {
        $stmt = $this->db->prepare("UPDATE organizations SET verified = 1, verified_by = ?, verified_at = NOW() WHERE id = ?");
        return $stmt->execute([$admin_id, $org_id]);
    }

    public function linkProject($org_id, $project_id): bool {
        $stmt = $this->db->prepare("UPDATE projects SET organization_id = ? WHERE id = ?");
        return $stmt->execute([$org_id, $project_id]);
    }

    public function getOrganization($id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM organizations WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function checkEligibility($location): bool {
        return !empty($location);
    }
    public function addMember($org_id, $user_id, $role = 'member'): bool {
        $stmt = $this->db->prepare("INSERT INTO organization_members (organization_id, user_id, role) VALUES (?, ?, ?)");
        return $stmt->execute([$org_id, $user_id, $role]);
    }

    public function removeMember($org_id, $user_id): bool {
        $stmt = $this->db->prepare("DELETE FROM organization_members WHERE organization_id = ? AND user_id = ?");
        return $stmt->execute([$org_id, $user_id]);
    }

    public function getMembers($org_id): array {
        $stmt = $this->db->prepare("
            SELECT u.id, u.username, u.full_name, u.email, om.role, om.joined_at
            FROM organization_members om
            JOIN users u ON om.user_id = u.id
            WHERE om.organization_id = ?
            ORDER BY om.role DESC, om.joined_at ASC
        ");
        $stmt->execute([$org_id]);
        return $stmt->fetchAll();
    }

    public function isMember($org_id, $user_id): bool {
        $stmt = $this->db->prepare("SELECT id FROM organization_members WHERE organization_id = ? AND user_id = ?");
        $stmt->execute([$org_id, $user_id]);
        return $stmt->fetch() !== false;
    }

    public function isAdmin($org_id, $user_id): bool {
        $stmt = $this->db->prepare("SELECT id FROM organization_members WHERE organization_id = ? AND user_id = ? AND role = 'admin'");
        $stmt->execute([$org_id, $user_id]);
        return $stmt->fetch() !== false;
    }
}
?>