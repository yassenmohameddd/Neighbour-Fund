<?php

class Project {
    private PDO $db;
    public $id, $title, $slug, $status, $funding_goal, $current_amount, $region, $project_lead_id, $deadline ;
    public $min_pledge, $max_pledge;
    public $description, $short_description, $category, $created_at, $updated_at, $sustainability_score, $sustainability_notes;
    public $lead_name;
    public $organization_id;
    public $stretch_goal;
    public $allow_stretch = false;
    public $final_goal;
    public function __construct($data = null) {
        $this->db = Database::getInstance();
        if ($data) {
            foreach ($data as $k => $v) {//loop
                if (property_exists($this, $k)) $this->$k = $v;
            }
        }
    }

    
    public function createProject($data): int {
        $slug = $this->generateSlug($data['title']);
      $stmt = $this->db->prepare("
INSERT INTO projects 
(title, slug, description, short_description, category, project_lead_id,
funding_goal, stretch_goal, region, deadline)
VALUES (?,?,?,?,?,?,?,?,?,?)
");
     $stmt->execute([
    $data['title'],
    $slug,
    $data['description'],
    substr($data['description'],0,500),
    $data['category'],
    $data['project_lead_id'],
    $data['funding_goal'],

    // ✅ NEW
    $data['stretch_goal'] ?? null,

    $data['region'],
    $data['deadline']
]);
        $id = $this->db->lastInsertId();
        if (isset($data['budget_items'])) {
            foreach ($data['budget_items'] as $item) {
                $this->addBudgetItem($id, $item['name'], $item['cost'], $item['vendor'] ?? '', $item['category'] ?? 'other');
            }
        }
        return $id;
    }

    private function addBudgetItem($projectId, $name, $cost, $vendor, $category) {
        $stmt = $this->db->prepare("INSERT INTO budget_items (project_id, item_name, estimated_cost, vendor_name, category) VALUES (?,?,?,?,?)");
        $stmt->execute([$projectId, $name, $cost, $vendor, $category]);
    }

    public function update(array $data): bool {
        $fields = [];
        $values = [];
        $allowed = [
 'title','description','category','funding_goal',
 'deadline','region','status','current_amount',
 'stretch_goal','final_goal'
];
        foreach ($data as $k => $v) {
            if (in_array($k, $allowed)) {
                $fields[] = "$k = ?";
                $values[] = $v;
            }
        }
        if (empty($fields)) return false;
        $values[] = $this->id;
        $sql = "UPDATE projects SET " . implode(',', $fields) . " WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute($values);
        if ($result) {
            foreach ($data as $k => $v) {
                if (property_exists($this, $k)) $this->$k = $v;
            }
        }
        return $result;
    }

    public function changeStatus($id, $status): bool {
        $stmt = $this->db->prepare("UPDATE projects SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }

    
    public function getProjectById($id): ?Project {
        if (empty($id) || !is_numeric($id)) return null;
        $stmt = $this->db->prepare("SELECT * FROM projects WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        if ($data) return new Project($data);
        return null;
    }

   public function getProjectBySlug($slug): ?Project {
    $stmt = $this->db->prepare("
        SELECT p.*, u.full_name AS lead_name
        FROM projects p
        JOIN users u ON p.project_lead_id = u.id
        WHERE p.slug = ?
    ");
    $stmt->execute([$slug]);
    $data = $stmt->fetch();
    if ($data) return new Project($data);
    return null;
}



    public function getAllProjects($status = null): array {
        if ($status) {
            $stmt = $this->db->prepare("SELECT * FROM projects WHERE status = ? ORDER BY created_at DESC");
            $stmt->execute([$status]);
        } else {
            $stmt = $this->db->query("SELECT * FROM projects ORDER BY created_at DESC");
        }
        return $stmt->fetchAll();
    }




    
public function checkFundingDeadline(): void
{
    if ($this->status !== 'live') return;

    $now = time();
    $deadline = strtotime($this->deadline);

    // 🟢 قبل الديدلاين → مفيش حسم
    if ($deadline > $now) {
        return;
    }

    // 🔴 بعد الديدلاين

    // لو فيه stretch goal
    if (!empty($this->stretch_goal)) {

        // لو وصل للـ stretch
        if ($this->current_amount >= $this->stretch_goal) {

            $this->update([
                'status' => 'funded',
                'final_goal' => $this->stretch_goal
            ]);

            $this->releaseEscrow();
            return;
        }

        // لو وصل للـ funding بس → لسه live (مايتقفلش)
        if ($this->current_amount >= $this->funding_goal) {
            return;
        }

    } else {
        // مفيش stretch → funded عادي
        if ($this->current_amount >= $this->funding_goal) {

            $this->update([
                'status' => 'funded',
                'final_goal' => $this->funding_goal
            ]);

            $this->releaseEscrow();
            return;
        }
    }

    // فشل
    $this->update(['status' => 'failed']);
    $this->processRefunds();
}

    private function releaseEscrow(): void {
        $stmt = $this->db->prepare("SELECT * FROM milestones WHERE project_id = ? AND sequence_order = 1");
        $stmt->execute([$this->id]);
        $firstMilestone = $stmt->fetch();
        if ($firstMilestone && !empty($firstMilestone['id'])) {
            $milestone = Milestone::find($firstMilestone['id']);
            if ($milestone) $milestone->activate();
        }
    }

    private function processRefunds(): void {
        
        $stmt = $this->db->prepare("SELECT id, amount, user_id FROM donations WHERE project_id = ? AND status = 'escrow'");
        $stmt->execute([$this->id]);
        $donations = $stmt->fetchAll();
        
        foreach ($donations as $d) {
            // تحديث حالة التبرع إلى refunded
            $this->db->prepare("UPDATE donations SET status = 'refunded', refunded_at = NOW(), refund_reason = 'Project failed to reach goal by deadline' WHERE id = ?")->execute([$d['id']]);
            
            // إنقاص رصيد المشروع (current_amount)
            $this->db->prepare("UPDATE projects SET current_amount = current_amount - ? WHERE id = ?")->execute([$d['amount'], $this->id]);
            
            // إنقاص total_donated للمستخدم
            $this->db->prepare("UPDATE users SET total_donated = total_donated - ? WHERE id = ?")->execute([$d['amount'], $d['user_id']]);
        }
    }

    public function getActiveMilestone(): ?array {
        // أول مرحلة غير مكتملة (ليست approved)
        $stmt = $this->db->prepare("
            SELECT * FROM milestones 
            WHERE project_id = ? AND status NOT IN ('approved', 'rejected')
            ORDER BY sequence_order ASC 
            LIMIT 1
        ");
        $stmt->execute([$this->id]);
        $milestone = $stmt->fetch();
        return $milestone ?: null;
    }

    public function getCompletedMilestonesTotal(): float {
        $stmt = $this->db->prepare("SELECT SUM(allocated_amount) as total FROM milestones WHERE project_id = ? AND status = 'approved'");
        $stmt->execute([$this->id]);
        return (float)$stmt->fetch()['total'];
    }

    public function getRemainingForCurrentMilestone(): float {
        $active = $this->getActiveMilestone();
        if (!$active) return 0;
        $completed = $this->getCompletedMilestonesTotal();
        $raisedForCurrent = $this->current_amount - $completed;
        return max(0, $active['allocated_amount'] - $raisedForCurrent);
    }

    // ========== دوال مساعدة ==========
    public function calculateProgress(): float {
        if ($this->funding_goal == 0) return 0;
        return round(($this->current_amount / $this->funding_goal) * 100, 2);
    }

    private function generateSlug($title): string {
        $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($title));
        $slug = trim($slug, '-');
        $original = $slug;
        $counter = 1;
        while (true) {
            $stmt = $this->db->prepare("SELECT id FROM projects WHERE slug = ?");
            $stmt->execute([$slug]);
            if (!$stmt->fetch()) break;
            $slug = $original . '-' . $counter++;
        }
        return $slug;
    }
   
public function updateProject($id, $data): bool {
    $fields = [];
    $values = [];
    $allowed = ['title', 'description', 'category', 'funding_goal', 'deadline', 'region', 'status', 'current_amount'];
    foreach ($data as $k => $v) {
        if (in_array($k, $allowed)) {
            $fields[] = "$k = ?";
            $values[] = $v;
        }
    }
    if (empty($fields)) return false;
    $values[] = $id;
    $sql = "UPDATE projects SET " . implode(',', $fields) . " WHERE id = ?";
    $stmt = $this->db->prepare($sql);
    return $stmt->execute($values);
    }
    public function getLeadCompletionRate(): float {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as completed
            FROM milestones WHERE project_id = ?
        ");
        $stmt->execute([$this->id]);
        $res = $stmt->fetch();
        if ($res['total'] == 0) return 0;
        return round(($res['completed'] / $res['total']) * 100);
    }
    
}
?>