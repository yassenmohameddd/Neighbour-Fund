<?php
class Update {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function postUpdate($project_id, $data): int {
        $stmt = $this->db->prepare("INSERT INTO project_updates (project_id, user_id, title, content) VALUES (?,?,?,?)");
        $stmt->execute([$project_id, $_SESSION['user_id'], $data['title'], $data['content']]);
        $this->notifyUsers($project_id);
        return $this->db->lastInsertId();
    }

    public function getUpdates($project_id): array {
        $stmt = $this->db->prepare("SELECT * FROM project_updates WHERE project_id = ? ORDER BY created_at DESC");
        $stmt->execute([$project_id]);
        return $stmt->fetchAll();
    }

    public function deleteUpdate($id): bool {
        $stmt = $this->db->prepare("DELETE FROM project_updates WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function notifyUsers($project_id): void {
        
    }
}
?>